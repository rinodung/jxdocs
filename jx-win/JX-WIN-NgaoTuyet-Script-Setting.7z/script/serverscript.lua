
Include("\\script\\library\\worldlibrary.lua");
Include("\\script\\startgame\\khoitaoserver.lua");

function StartGame()
	khoidongtoanserver()
end;
