--========================================================================================================--
--Author: T�o Card.
--Script By Carot.
--========================================================================================================--
Include("\\script\\library\\worldlibrary.lua");Include("\\script\\donate\\danhsachcard.lua");

--========================================================================================================--

function taocard()
menhgia = 0
for i=1,1000 do
if i <= 200  then
menhgia = 10
elseif i <= 500 then
menhgia = 20
elseif i <= 750 then
menhgia = 50
elseif i <= 900 then
menhgia = 100
elseif i <= 950 then
menhgia = 200
elseif i <= 980 then
menhgia = 300
elseif i <= 1000 then
menhgia = 500
end
seri = random(888888,999999)
card = random(444444,666666)
logWrite1(seri)
logWrite2(card)
NAP_CARD[getn(NAP_CARD)+1] = {i,seri,card,menhgia}
danhsach = TaoBang(NAP_CARD,"NAP_CARD","")
SaveData("script/donate/danhsachcard.lua",danhsach)
end
end

function logWrite1(str)
local gm_Log = "script/card/card.txt"
local fs_log = openfile(gm_Log, "a+");
write(fs_log,""..str.."\n");
closefile(fs_log);
end

function logWrite2(str)
local gm_Log = "script/card/seri.txt"
local fs_log = openfile(gm_Log, "a+");
write(fs_log,""..str.."\n");
closefile(fs_log);
end
