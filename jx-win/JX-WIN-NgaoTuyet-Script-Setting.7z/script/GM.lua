-------------------------------------------------Script*By* ThongHOnPro-----------------------------------------
---------------------------------------------------GM--------------------------------------------
Include("\\Script\\source\\sourcejx49.lua")
Include("\\script\\ohishu\\NPC\\monphai\\manguon.lua")
Include("\\script\\global\\sourceatn.lua")
Include("\\script\\global\\tasklist.lua")
--Include("\\Script\\global\\ban.lua")

wel="L�a ch�n ID Nh�n V�t mu�n thao t�c :"
wel1="L�a ch�n ID Nh�n V�t mu�n thao t�c:"
fir="1-10/first"
sec="11-20/second"
thr="21-30/third"
fou="31-40/forth"
fif="41-50/fifth"
six1="51-60/sixth"
sev="61-70/seventh"
eig="71-80/eighth"
nin="81-90/ninth"
ten="91-100/tenth"
------------------
fir10="101-110/first10"
sec10="111-120/second10"
thr10="121-130/third10"
fou10="131-140/forth10"
fif10="141-150/fifth10"
six10="151-160/sixth10"
sev10="161-170/seventh10"
eig10="171-180/eighth10"
nin10="181-190/ninth10"
ten10="191-200/tenth10"
------------------
fir20="201-210/first20"
sec20="211-220/second20"
thr20="221-230/third20"
fou20="231-240/forth20"
fif20="241-250/fifth20"
six20="251-260/sixth20"
sev20="261-270/seventh20"
eig20="271-280/eighth20"
nin20="281-290/ninth20"
ten20="291-300/tenth20"
------------------
can="Thoat/no"
on="1/one"
tw="2/two"
th="3/three"
fo="4/four"
fi="5/five"
si="6/six"
se="7/seven"
ei="8/eight"
ni="9/nine"
ze="0/zero"
sk="Giam v�o t�/giamlong"
it="Th� T�/nogiamlong"
mov="Di chuy�n v� BLH/move"
kic="Kick nh�n v�t./kick"
exppp="Th�m c�p./exp"
bufftp="Buff th�n ph�p./thoigian"
buffskills="Buff Donate./buffskillsgm"
inv="Th�ng Tin Nh�n V�t./invest"
nex="Next/next"
nex2="Next/next2"
cscs="Them Chuyen Sinh/chuyensinh"
-----------------------------------------------

function system()
Say("Admin <color=red>"..GetName().."<color> �i........!  \n��u ti�n b�n c�n  l�y<bclr=blue> ID Gamer<bclr> tr��c nh�..!\nSau �� m�i v�o ph�n <bclr=blue>Qu�n l� Gamer<bclr>",15,
					"1-L�y ID Gamer - L�y ID nh�n v�t/chaozuo",
					"2-Qu�n l� Gamer - Thao t�c l�n nh�n v�t/thonghon",
					"3-X�a ID- Thao t�c l�n ID �� ch�n/kick",
					"Xem Th�ng Tin Gamer to�n b� Server/Show",
					"Xem Th�ng Tin Gamer (1~100)/Show100",
					"Xem Th�ng Tin Gamer (101~200)/Show200",
					"Xem Th�ng Tin Gamer (201~300)/Show300",
					"Kick ra ch�ng Rollback  - Kick to�n b� acc/kickall",	
					
					"Tho�t kh�i ��y/no")
end

function adminnnn()
	Say("Xin ch�o ��i hi�p <color=wood>"..GetName().."<color>....!  \nM�i ��i Hi�p ch�n ch�c n�ng <bclr=blue>Admin <bclr>d��i ��y..!",10,
		"Gioi Han Chuyen Sinh 20/tangchuyensinhsv",
		"Gioi Han Chuyen Sinh 40/tangchuyensinhsv",
		"Gioi Han Chuyen Sinh 60/tangchuyensinhsv",
		"Gioi Han Chuyen Sinh 80/tangchuyensinhsv",
		"Gioi Han Chuyen Sinh 100/tangchuyensinhsv",
		"Gia Tang CS Them 10/tangchuyensinhsv",
		"Thoat/Exit")
end

function tangchuyensinhsv(sel)
id = sel + 1
	if id == 1 then
SetGlbMissionV(50,20)
AddGlobalCountNews("Gioi Han Chuyen Sinh Server Hien Tai La "..GetGlbMissionV(50).." !",3)
	elseif id == 2 then
SetGlbMissionV(50,40)
AddGlobalCountNews("Gioi Han Chuyen Sinh Server Hien Tai La "..GetGlbMissionV(50).." !",3)
	elseif id == 3 then
SetGlbMissionV(50,60)
AddGlobalCountNews("Gioi Han Chuyen Sinh Server Hien Tai La "..GetGlbMissionV(50).." !",3)
	elseif id == 4 then
SetGlbMissionV(50,80)
AddGlobalCountNews("Gioi Han Chuyen Sinh Server Hien Tai La "..GetGlbMissionV(50).." !",3)
	elseif id == 5 then
SetGlbMissionV(50,100)
AddGlobalCountNews("Gioi Han Chuyen Sinh Server Hien Tai La "..GetGlbMissionV(50).." !",3)
	elseif id == 6 then
SetGlbMissionV(50,GetGlbMissionV(50)+10)
AddGlobalCountNews("Gioi Han Chuyen Sinh Server Hien Tai La "..GetGlbMissionV(50).." !",3)
	end
end

function Show()
for i=1,GetPlayerCount() do
	gmidx=PlayerIndex
	PlayerIndex=i
	TarName=GetName()
	PlayerIndex=gmidx
	Msg2Player("ID <color=green>"..i.."<color> t�n l�:<color=yellow> "..TarName.."");
end
end;

function Show100()
for i=1,100 do
	gmidx=PlayerIndex
	PlayerIndex=i
	TarName=GetName()
	PlayerIndex=gmidx
	Msg2Player("ID <color=green>"..i.."<color> t�n l�:<color=yellow> "..TarName.."");
end
end;

function Show200()
for i=101,200 do
	gmidx=PlayerIndex
	PlayerIndex=i
	TarName=GetName()
	PlayerIndex=gmidx
	Msg2Player("ID <color=green>"..i.."<color> t�n l�:<color=yellow> "..TarName.."");
end
end;

function Show300()
for i=201,300 do
	gmidx=PlayerIndex
	PlayerIndex=i
	TarName=GetName()
	PlayerIndex=gmidx
	Msg2Player("ID <color=green>"..i.."<color> t�n l�:<color=yellow> "..TarName.."");
end
end;
------------------------------------------------------------------------------------------------------------------------------------------

function chaozuo()
Say(wel,12,fir,sec,thr,fou,fif,six1,sev,eig,nin,ten,nex,can)
end;

function next()
Say(wel,14,fir10,sec10,thr10,fou10,fif10,six10,sev10,eig10,nin10,ten10,nex2,can)
end;

function next2()
Say(wel,11,fir20,sec20,thr20,fou20,fif20,six20,sev20,eig20,nin20,ten20,can)
end;
------------------------------------------------------------------------------------------------------------------------------------------

function first()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,0)
end;

function second()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,1)
end;

function third()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,2)
end;

function forth()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,3)
end;

function fifth()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,4)
end;

function sixth()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,5)
end;

function seventh()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,6)
end;

function eighth()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,7)
end;

function ninth()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,8)
end;

function tenth()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,9)
end;

function nextinfo()
	SayEx({wel,fir10,sec10,thr10,fou10,fif10,six10,sev10,eig10,nin10,ten10,nex2,can})
end

function first10()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,10)
end;

function second10()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,11)
end;

function third10()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,12)
end;

function forth10()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,13)
end;

function fifth10()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,14)
end;

function sixth10()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,15)
end;

function seventh10()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,16)
end;

function eighth10()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,17)
end;

function ninth10()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,18)
end;

function tenth10()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,19)
end;

function nextinfo2()
	SayEx({wel,fir20,sec20,thr20,fou20,fif20,six20,sev20,eig20,nin20,ten20,can})
end

function first20()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,20)
end;

function second20()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,21)
end;

function third20()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,22)
end;

function forth20()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,23)
end;

function fifth20()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,24)
end;

function sixth20()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,25)
end;

function seventh20()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,26)
end;

function eighth20()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,27)
end;

function ninth20()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,28)
end;

function tenth20()
	Say(wel, 11, on, tw, th, fo, fi, si, se, ei, ni, ze, can);
	SetTaskTemp(TaskTempGM,29)
end;

--- Them ADMIN vao ham--------------admin
function one()
	n=GetTaskTemp(TaskTempGM)
	if ((n*10+1)>GetPlayerCount()) then
		Msg2Player("Kh�ng c� nh�n v�t n�y, xin ki�m tra l�i");
	else
		SetTaskTemp(TaskTempGM,n*10+1)
		gmName=GetName()
		gmidx=PlayerIndex
		PlayerIndex=GetTaskTemp(TaskTempGM)
		ObjName=GetName()
		PlayerIndex=gmidx
		Msg2Player("T�n Nh�n V�t: : <color=yellow>"..ObjName.."<color>");
		if((GetName() == "ThongHonPro") and (GetPlayerAccount() == "ThongHon")) or ((GetName() == "ThongHon123") and (GetPlayerAccount() == "quyngo")) then
			Say(wel1, 7, it, sk,pas, mov, ban, inv, can);
		else
			return
		end
	end
end;

function two()
	n=GetTaskTemp(TaskTempGM)
	if ((n*10+2)>GetPlayerCount()) then
		Msg2Player("Kh�ng c� nh�n v�t n�y, xin ki�m tra l�i");
	else
		SetTaskTemp(TaskTempGM,n*10+2)
		gmName=GetName()
		gmidx=PlayerIndex
		PlayerIndex=GetTaskTemp(TaskTempGM)
		ObjName=GetName()
		PlayerIndex=gmidx
		Msg2Player("T�n Nh�n V�t: <color=yellow>"..ObjName.."");
	if((GetName() == "ThongHonPro") and (GetPlayerAccount() == "ThongHon")) or ((GetName() == "ThongHon123") and (GetPlayerAccount() == "quyngo")) then
			Say(wel1, 7, it, sk,pas, mov, ban, inv, can);
		else
			return
		end
	end
end;

function three()
	n=GetTaskTemp(TaskTempGM)
	if ((n*10+3)>GetPlayerCount()) then
		Msg2Player("Kh�ng c� nh�n v�t n�y, xin ki�m tra l�i");
	else
		SetTaskTemp(TaskTempGM,n*10+3)
		gmName=GetName()
		gmidx=PlayerIndex
		PlayerIndex=GetTaskTemp(TaskTempGM)
		ObjName=GetName()
		PlayerIndex=gmidx
		Msg2Player("T�n Nh�n V�t: <color=yellow> "..ObjName.."");
		if((GetName() == "ThongHonPro") and (GetPlayerAccount() == "ThongHon")) or ((GetName() == "ThongHon123") and (GetPlayerAccount() == "quyngo")) then
			Say(wel1, 7, it, sk,pas, mov, ban, inv, can);
		else
			return
		end
	end
end;

function four()
	n=GetTaskTemp(TaskTempGM)
	if ((n*10+4)>GetPlayerCount()) then
		Msg2Player("Kh�ng c� nh�n v�t n�y, xin ki�m tra l�i");
	else
		SetTaskTemp(TaskTempGM,n*10+4)
		gmName=GetName()
		gmidx=PlayerIndex
		PlayerIndex=GetTaskTemp(TaskTempGM)
		ObjName=GetName()
		PlayerIndex=gmidx
		Msg2Player("T�n Nh�n V�t: <color=yellow> "..ObjName.."");
		if((GetName() == "ThongHonPro") and (GetPlayerAccount() == "ThongHon")) or ((GetName() == "ThongHon123") and (GetPlayerAccount() == "quyngo")) then
			Say(wel1, 7, it, sk,pas, mov, ban, inv, can);
		else
			return
		end
	end
end;

function five()
	n=GetTaskTemp(TaskTempGM)
	if ((n*10+5)>GetPlayerCount()) then
		Msg2Player("Kh�ng c� nh�n v�t n�y, xin ki�m tra l�i");
	else
		SetTaskTemp(TaskTempGM,n*10+5)
		gmName=GetName()
		gmidx=PlayerIndex
		PlayerIndex=GetTaskTemp(TaskTempGM)
		ObjName=GetName()
		PlayerIndex=gmidx
		Msg2Player("T�n Nh�n V�t: <color=yellow>"..ObjName.."");
		if((GetName() == "ThongHonPro") and (GetPlayerAccount() == "ThongHon")) or ((GetName() == "ThongHon123") and (GetPlayerAccount() == "quyngo")) then
			Say(wel1, 7, it, sk,pas, mov, ban, inv, can);
		else
			return
		end
	end
end;

function six()
	n=GetTaskTemp(TaskTempGM)
	if ((n*10+6)>GetPlayerCount()) then
		Msg2Player("Kh�ng c� nh�n v�t n�y, xin ki�m tra l�i");
	else
		SetTaskTemp(TaskTempGM,n*10+6)
		gmName=GetName()
		gmidx=PlayerIndex
		PlayerIndex=GetTaskTemp(TaskTempGM)
		ObjName=GetName()
		PlayerIndex=gmidx
		Msg2Player("T�n Nh�n V�t: <color=yellow> "..ObjName.."");
		if((GetName() == "ThongHonPro") and (GetPlayerAccount() == "ThongHon")) or ((GetName() == "ThongHon123") and (GetPlayerAccount() == "quyngo")) then
			Say(wel1, 7, it, sk,pas, mov, ban, inv, can);
		else
			return
		end
	end
end;

function seven()
	n=GetTaskTemp(TaskTempGM)
	if ((n*10+7)>GetPlayerCount()) then
		Msg2Player("Kh�ng c� nh�n v�t n�y, xin ki�m tra l�i");
	else
		SetTaskTemp(TaskTempGM,n*10+7)
		gmName=GetName()
		gmidx=PlayerIndex
		PlayerIndex=GetTaskTemp(TaskTempGM)
		ObjName=GetName()
		PlayerIndex=gmidx
		Msg2Player("T�n Nh�n V�t: <color=yellow> "..ObjName.."");
		if((GetName() == "ThongHonPro") and (GetPlayerAccount() == "ThongHon")) or ((GetName() == "ThongHon123") and (GetPlayerAccount() == "quyngo")) then
			Say(wel1, 7, it, sk,pas, mov, ban, inv, can);
		else
			return
		end
	end
end;

function eight()
	n=GetTaskTemp(TaskTempGM)
	if ((n*10+8)>GetPlayerCount()) then
		Msg2Player("Kh�ng c� nh�n v�t n�y, xin ki�m tra l�i");
	else
		SetTaskTemp(TaskTempGM,n*10+8)
		gmName=GetName()
		gmidx=PlayerIndex
		PlayerIndex=GetTaskTemp(TaskTempGM)
		ObjName=GetName()
		PlayerIndex=gmidx
		Msg2Player("T�n Nh�n V�t: <color=yellow> "..ObjName.."");
		if((GetName() == "ThongHonPro") and (GetPlayerAccount() == "ThongHon")) or ((GetName() == "ThongHon123") and (GetPlayerAccount() == "quyngo")) then
			Say(wel1, 7, it, sk,pas, mov, ban, inv, can);
		else
			return
		end
	end
end;

function nine()
	n=GetTaskTemp(TaskTempGM)
	if ((n*10+9)>GetPlayerCount()) then
		Msg2Player("Kh�ng c� nh�n v�t n�y, xin ki�m tra l�i");
	else
		SetTaskTemp(TaskTempGM,n*10+9)
		gmName=GetName()
		gmidx=PlayerIndex
		PlayerIndex=GetTaskTemp(TaskTempGM)
		ObjName=GetName()
		PlayerIndex=gmidx
		Msg2Player("T�n Nh�n V�t: <color=yellow> "..ObjName.."");
		if((GetName() == "ThongHonPro") and (GetPlayerAccount() == "ThongHon")) or ((GetName() == "ThongHon123") and (GetPlayerAccount() == "quyngo")) then
			Say(wel1, 7, it, sk,pas, mov, ban, inv, can);
		else
			return
		end
	end
end;

function zero()
	n=GetTaskTemp(TaskTempGM)
	if ((n*10+10)>GetPlayerCount()) then
		Msg2Player("Kh�ng c� nh�n v�t n�y, xin ki�m tra l�i");
	else
		SetTaskTemp(TaskTempGM,n*10+10)
		gmName=GetName()
		gmidx=PlayerIndex
		PlayerIndex=GetTaskTemp(TaskTempGM)
		ObjName=GetName()
		PlayerIndex=gmidx
		Msg2Player("T�n Nh�n V�t: <color=yellow> "..ObjName.."");
		if((GetName() == "ThongHonPro") and (GetPlayerAccount() == "ThongHon")) or ((GetName() == "ThongHon123") and (GetPlayerAccount() == "quyngo")) then
			Say(wel1, 7, it, sk,pas, mov, ban, inv, can);
		else
			return
		end
	end
end;

------------------Khac SV ----------------

function kick()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
--Msg2Player("GM  Admin  Nhan vat Nhan vat ??!");
KickOutSelf()
PlayerIndex=gmidx
Msg2Player("Nhan vat "..ObjName.."Nhan vat Nhan vat Nhan vat !");
end;
function kickall()
	for i=1,GetPlayerCount() do
		gmidx=PlayerIndex
		PlayerIndex=i
		KickOutSelf()
		PlayerIndex=gmidx
	end
end;

function xoaadmin()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
	for i=1,9999 do
	DelItem(i)
	end
end;

function no()
end;