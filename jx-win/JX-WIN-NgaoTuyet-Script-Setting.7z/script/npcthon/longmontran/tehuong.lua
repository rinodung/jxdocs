
function main(NpcIndex)
		Talk(1,"",12085)
end;
