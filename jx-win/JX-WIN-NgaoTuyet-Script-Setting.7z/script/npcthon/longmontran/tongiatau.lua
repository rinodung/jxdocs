
function main(NpcIndex)
		Talk(1,"",12072)
end;
