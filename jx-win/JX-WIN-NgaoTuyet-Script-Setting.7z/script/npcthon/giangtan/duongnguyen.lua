
function main()
	Talk(1,"",13007)
end
