Include("\\script\\header\\monphaiheader.lua");
Include("\\script\\library\\worldlibrary.lua");

function main(sel)
	if(GetTongName() ~= "") then
	Talk(1,"",10305) --
	return end
	local C = GetCamp()
	if (C == nguoimoi) then
		Talk(2,"xulynguoimoi",10308,10309) --khoe
	return end
	xulymonphai()
end;

function xulymonphai()
	local nCamp = GetCamp()
	if(nCamp == xuatsu) then
	Say(10390,2,
	"Tr�ng ph�n s� m�n/trungphan",
	ENDTALK)
	else
	Say(10383,4,
	WANNA_GO,
	WANNA_90,
	WANNA_CHANGE,
	ENDTALK)
	end
end;

function trungphan()
	local nMoney = GetCash()
	if( nMoney < 60000) then
		Talk(1,"",15464)
	return end
	Pay(60000)
	LeaveTeam()
	SetCamp(chinhphai)
	SetCurCamp(chinhphai)
	Talk(1,"","Ch�o m�ng ng��i quay tr� l�i b�n m�n!");
end;

function xulynguoimoi()
	local S = GetSeries()
	if( S ~= hethuy) then
	return end
	Say("Gia nh�p Hoa S�n ph�i! H�a ph�c c�ng h��ng!",2,
	"Gia nh�p Hoa S�n ph�i/gianhap",
	"Ta ch�a mu�n/khong")
end;

function gianhap()
	local L = GetLevel()
	if (L < 10) then
	Talk(1,"",10215)
	return end
	--SetFactionEx("HS")
	SetCamp(chinhphai)
	SetCurCamp(chinhphai)
	SetRank(82)
	Msg2Player("B�n �� gia nh�p Hoa S�n Ph�i")
	addskill_thuong(11)
end;

function kynang90()
	show_kynang90(11)
end;

function khong()
	Talk(1,"",10213)
end;

function chuyenphai()
	local curfac = GetFactionNo();
	if(curfac < 0 or curfac > 9 or curfac == 4) then
	return end;
	common_change(4,8,74,chinhphai,curfac);
end;

function no()
end;
