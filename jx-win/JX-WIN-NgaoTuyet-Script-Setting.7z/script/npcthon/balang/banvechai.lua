-- Action
-- npc Ve Chai

function main(NpcIndex)
	Say2("bclr=white><color=red>D�o n�y Ve Chai c�ng � �m qu� ng��i mu�n b�n th� g�",2,1,"",
        "Ta Mu�n B�n Ve Chai!/banvechai",
        "Th�i!H�ng C�n X�i ���c!/no")
end
CHUABAN = "<bclr=white><color=red>Ch�m ch�t b� b�y gi� �inh l�a ��o �!"
LUCBAN = "<bclr=white><color=red>Nhi�u qu� ta kh�ng �� ti�n mua!"

function banvechai()
PutItem("<bclr=white><color=red>Ve Chai d�o n�y xu�ng gi� r�,   S�t 10k/1kg , T�i Nilon 5k/1kg ng��i c� mu�n b�n kh�ng ?","y/vutbo","n/no")
end
function vutbo()
	local nTempIndex,Tkind,Tgenre,Tdetail,Tparti,Tlevel,Tseries,Trow;
	local count = 0;
	local nIndex = 0;
	local kind,genre,detail,parti,level,series,row;
	local i,j;
	for i=0,5 do
		for j=0,3 do
			nTempIndex,Tkind,Tgenre,Tdetail,Tparti,Tlevel,Tseries,Trow = GetItemParam(10,i,j);
			if (nTempIndex > 0) then
				count = count + 1;
				nIndex,kind,genre,detail,parti,level,series,row = nTempIndex,Tkind,Tgenre,Tdetail,Tparti,Tlevel,Tseries,Trow;
			end
		end
	end
	if(count < 1) then
		Talk(1,"",CHUABAN)
	return end
	if(count > 1) then
		Talk(1,"",LUCBAN)
	return end
	if count == 1 then
RemoveItem(nIndex,1)
	Msg2Player("<bclr=white><color=red>B�n thu ���c 15k nh� b�n 2kg s�t")
end
end

function no()
end;
