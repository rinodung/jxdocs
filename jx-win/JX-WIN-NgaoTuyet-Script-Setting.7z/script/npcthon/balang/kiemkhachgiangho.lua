Include("\\script\\library\\worldlibrary.lua");
Include("\\script\\header\\taskid.lua");
Include("\\script\\header\\khobau.lua");

MAIN_NV ={
"Nh�n b�n ��.",
"Truy t�m kho b�u.",
"H�y nhi�m v�.",
"T�m hi�u v� nhi�m v�."}
KETTHUC = "K�t th�c ��i tho�i/no"
function main()
local nSLan = GetNumber(GetTask(TASK_VINHLACTRAN),4)
local Lan = 3 - nSLan
	local count = 1;
	local StrTab = {};	
	for i=1,getn(MAIN_NV) do
		StrTab[count] = MAIN_NV[i].."/khobau1";
		count = count + 1;
	end	
	if(count == 1) then
	return end	
	StrTab[count] = KETTHUC;
	Say2("S� nhi�m v� trong ng�y: <color=red>"..Lan.."<color>.",count,1,"",StrTab)
end;
function no()
end
function khobau1(nsel)
local nSLan = GetNumber(GetTask(TASK_VINHLACTRAN),4)

if nsel == 0 then
	AddItem(0,2,88,0,0,5,0,0) -- cai nay la item ban do
return end
if nsel == 3 then
Say2("Vi�t n�i dung v�o ��y",2,1,"",
	KETTHUC)
return end
if nsel == 2 then
SetTask(TASK_VINHLACTRAN,SetNumber(GetTask(TASK_VINHLACTRAN),7,0))
	SetTask(TASK_TOADOX,0)
	SetTask(TASK_TOADOY,0)
	SetTask(TASK_MAP,0)
return end
if nsel == 1 then
if GetLevel() < 60 then
	Talk(1,"","<color=metal>Ki�m Kh�ch: <color>��ng c�p 60 tr� l�n m�i c� th� ti�p nh�n nhi�m v�")
	return end
if nSLan >= 3 then
	Talk(1,"","<color=metal>Ki�m Kh�ch: <color>M�i ng�y ch� c� th� nh�n nhi�m v� 3 l�n")
	return end
if GetLevel() >= 60 and nSLan < 3 then
	local i = RANDOM(1,getn(KHOBAU))
	SetTask(TASK_TOADOX,KHOBAU[i][1])
	SetTask(TASK_TOADOY,KHOBAU[i][2])
	SetTask(TASK_MAP,KHOBAU[i][3])
	SetTask(TASK_VINHLACTRAN,SetNumber(GetTask(TASK_VINHLACTRAN),4,GetNumber(GetTask(TASK_VINHLACTRAN),6) +1)) -- so lan trong ngay
	SetTask(TASK_VINHLACTRAN,SetNumber(GetTask(TASK_VINHLACTRAN),7,1))-- da nhan nhiem vu
	Talk(1,"","<color=metal>Ki�m Kh�ch: <color>Ng��i h�y ��n V�nh L�c Tr�n t�m <color=yellow>B�u v�t<color> v� cho ta.")
	return end
end
end