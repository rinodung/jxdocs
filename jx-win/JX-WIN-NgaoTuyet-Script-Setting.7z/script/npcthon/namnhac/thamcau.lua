

function main(NpcIndex)
	Say(10062,2,
	"Mua ng�a/giaodich",
	"Kh�ng mua/no")
end;

function giaodich()
	Sale(91)
end;

function no()
	Talk(1,"",10064)
end;