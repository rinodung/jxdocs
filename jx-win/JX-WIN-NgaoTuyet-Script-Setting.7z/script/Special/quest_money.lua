--Author: lzlsky301
--Date: 07/11/12
Include("\\script\\global\\sourceatn.lua")
Include("\\script\\global\\tasklist.lua")

MONEY = {
	{1,10000,30000},
	{2,10000,40000},
	{3,10000,50000},
	{4,10000,60000},
	{5,20000,70000},
	{6,20000,80000},
	{7,20000,90000},
	{8,30000,100000},
	{9,40000,110000},
	{10,40000,120000},
	{11,50000,130000},
	{12,50000,140000},
	{13,60000,150000},
	{14,70000,160000},
	{15,110000,170000},
	{16,120000,1080000},
	{17,130000,1080000},
}
function main()
	-- dofile("script/special/quest_money.lua")
	finish_money()
end

function finish_money()
	local a = GetTask(T_MayMan)
	if GetTask(T_MayMan) >= 1 then
		if a >= 1 then
			for i=1,17 do
				if MONEY[i][1] == a then
					local b = random(MONEY[i][2],MONEY[i][3])
					Earn(b)
					SetTask(T_MayMan,0)
					Talk(1,"no","<color=green>D� T�u:<color> <color=pink>Ho�n th�nh nhi�m v�, nh�n ���c "..b.." ng�n l��ng<color>")
					return
				end
			end
		else
			Talk(1,"no", 10072)
		end
	elseif GetTask(T_NVuHoangKim) == 9 then
		if GetTask(T_NhanThuongNVHK) == 0 then
			SetTask(T_NhanThuongNVHK,1)
			if GetTask(T_NhanThuongNVHK) == 1 then
				Earn(200000)
				AddSumExp(100000)
				Msg2Player(TAB_FINISHMONEY[2])
				return
			else
				return
			end
		end
	elseif	GetTask(T_NVuHoangKim) == 15 then
		if GetTask(T_NhanThuongNVHK) <= 1 then
			SetTask(T_NhanThuongNVHK,2)
			if GetTask(T_NhanThuongNVHK) == 2 then
				Earn(200000)
				AddSumExp(100000)
				Msg2Player(TAB_FINISHMONEY[2])
				return
			else
				return
			end
		end
	elseif GetTask(T_NVuHoangKim) == 25 and GetTask(T_NhanThuongNVHK) <= 2 then
		if GetTask(T_NhanThuongNVHK) <= 2 then
			SetTask(T_NhanThuongNVHK,3)
			if GetTask(T_NhanThuongNVHK) == 3 then
				Earn(200000)
				AddSumExp(100000)
				Msg2Player(TAB_FINISHMONEY[2])
				return
			else
				return
			end
		end
	-- elseif GetTask(T_NVuThienHoang) == 2 and GetTask(T_TienDoNVTHoang) == 1 then
		-- if GetTask(T_TienDoNVTHoang) == 1 then
				-- SetTask(T_NVuThienHoang,3)
				-- if GetTask(T_TienDoNVTHoang) == 1 and GetTask(T_NVuThienHoang) == 3 then
					-- for i=1,100 do AddEventItem(random(37,39)) end
						-- Msg2Player("Ho�n th�nh nhi�m v� Thi�n Ho�ng nh�n ���c 100 t�i m�ng xu�n ")
						-- Earn(300000)
						-- AddSumExp(1000000)
						-- SetTask(T_TienDoNVTHoang,0)
						-- Msg2Player("Ho�n th�nh nhi�m v� thi�n ho�ng nh�n ���c 30 v�n l��ng v� 1.000.000 kinh nghi�m ")
						-- return
					-- else
						-- return
					-- end
				-- else
					-- return
				-- end
		-- return
	-- elseif GetTask(T_NVuThienHoang) == 5 and GetTask(T_TienDoNVTHoang) == 1 then
		-- if GetTask(T_TienDoNVTHoang) == 1 then
				-- SetTask(T_NVuThienHoang,6)
				-- if GetTask(T_TienDoNVTHoang) == 1 and GetTask(T_NVuThienHoang) == 6 then
					-- for i=1,100 do AddEventItem(random(37,39)) end
						-- Msg2Player("Ho�n th�nh nhi�m v� Thi�n Ho�ng nh�n ���c 100 t�i m�ng xu�n ")
						-- Earn(400000)
						-- AddSumExp(1500000)
						-- SetTask(T_TienDoNVTHoang,0)
						-- Msg2Player("Ho�n th�nh nhi�m v� thi�n ho�ng nh�n ���c 40 v�n l��ng v� 1.500.000 kinh nghi�m ")
						-- return
					-- else
						-- return
					-- end
				-- else
					-- return
				-- end
		-- return
	-- elseif GetTask(T_NVuThienHoang) == 8 and GetTask(T_TienDoNVTHoang) == 1 then
		-- if GetTask(T_TienDoNVTHoang) == 1 then
				-- SetTask(T_NVuThienHoang,9)
				-- if GetTask(T_TienDoNVTHoang) == 1 and GetTask(T_NVuThienHoang) == 9 then
					-- for i=1,100 do AddEventItem(random(37,39)) end
						-- Msg2Player("Ho�n th�nh nhi�m v� Thi�n Ho�ng nh�n ���c 100 t�i m�ng xu�n ")
						-- Earn(400000)
						-- AddSumExp(1500000)
						-- SetTask(T_TienDoNVTHoang,0)
						-- Msg2Player("Ho�n th�nh nhi�m v� thi�n ho�ng nh�n ���c 40 v�n l��ng v� 1.500.000 kinh nghi�m ")
						-- return
					-- else
						-- return
					-- end
				-- else
					-- return
				-- end
		-- return
	-- elseif GetTask(T_NVuThienHoang) == 9 and GetTask(T_TienDoNVTHoang) == 1 then
		-- if GetTask(T_TienDoNVTHoang) == 1 then
				-- SetTask(T_NVuThienHoang,10)
				-- if GetTask(T_TienDoNVTHoang) == 1 and GetTask(T_NVuThienHoang) == 10 then
					-- for i=1,100 do AddEventItem(random(37,39)) end
						-- Msg2Player("Ho�n th�nh nhi�m v� Thi�n Ho�ng nh�n ���c 100 t�i m�ng xu�n ")
						-- Earn(600000)
						-- AddSumExp(2000000)
						-- SetTask(T_TienDoNVTHoang,0)
						-- Msg2Player("Ho�n th�nh nhi�m v� thi�n ho�ng nh�n ���c 60 v�n l��ng v� 2.000.000 kinh nghi�m ")
						-- return
					-- else
						-- return
					-- end
				-- else
					-- return
				-- end
		-- return
	else
		return
	end
end