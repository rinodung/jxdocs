--Author: lzlsky301
--Date: 07/11/12
Include("\\script\\quest\\datau\\lib_datau.lua")
Include("\\script\\global\\sourceatn.lua")
Include("\\script\\global\\tasklist.lua")

function main()
	local a = GetGenreItem(GetIndexGiveItem(nIndex))
	-- b check cot nDetailType
	local b = GetDetailItem(GetIndexGiveItem(nIndex))
	-- c check cot nParticurlaType
	local c = GetParticularItem(GetIndexGiveItem(nIndex))
	-- d check cot nLevel
	local d = GetLevelItem(GetIndexGiveItem(nIndex))
	-- e check cot nSeries
	local e = GetSeriesItem(GetIndexGiveItem(nIndex))
	-- Check dong 1 den an 6 tren trang bi xanh
	local f = GetOp1Item(GetIndexGiveItem(nIndex)) -- hien 1
	local g = GetOp3Item(GetIndexGiveItem(nIndex)) -- hien 2
	local h = GetOp5Item(GetIndexGiveItem(nIndex)) -- hien 3
	local i = GetOp2Item(GetIndexGiveItem(nIndex)) -- an 1
	local j = GetOp4Item(GetIndexGiveItem(nIndex)) -- an 2
	local k = GetOp6Item(GetIndexGiveItem(nIndex)) -- an 3
	local l = GetVOp1Item(GetIndexGiveItem(nIndex)) -- hien 1
	local m = GetVOp3Item(GetIndexGiveItem(nIndex)) -- hien 2
	local n = GetVOp5Item(GetIndexGiveItem(nIndex)) -- hien 3
	local o = GetVOp2Item(GetIndexGiveItem(nIndex)) -- an 1
	local p = GetVOp4Item(GetIndexGiveItem(nIndex)) -- an 2
	local q = GetVOp6Item(GetIndexGiveItem(nIndex)) -- an 3
	local TAB_MSG = {
					"<color=green>D� T�u:<color> V�t ph�m ng��i mang ��n kh�ng ��ng v�i y�u c�u c�a ta.",
					"<color=green>D� T�u:<color> Ng��i ch�a b� v�t ph�m c�n thi�t v�o.",
					"<color=green>D� T�u:<color> Ng��i �� ho�n th�nh r�i m� ",
				}
	if GetTask(T_TimVatPham) >= 1 then
		if GetIndexGiveItem(nIndex) ~= 0 then
					--=====================Nhiem vu tim do cho da tau========================---------------
			if GetTask(T_TimVatPham) >= 1 then
				if GetTask(T_TimVatPham) == 1 then
					if a == 0 and  b == 4 and c == 0 and d == 1 then -- day chuyen nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 2 then
					if a == 0 and  b == 4 and c == 0 and d == 2 then -- day chuyen nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 3 then
					if a == 0 and  b == 4 and c == 0 and d == 3 then -- day chuyen nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 4 then
					if a == 0 and  b == 4 and c == 0 and d == 4 then -- day chuyen nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 5 then
					if a == 0 and  b == 4 and c == 0 and d == 5 then -- day chuyen nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 6 then
					if a == 0 and  b == 4 and c == 0 and d == 6 then -- day chuyen nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 7 then
					if a == 0 and  b == 4 and c == 0 and d == 7 then -- day chuyen nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 8 then
					if a == 0 and  b == 4 and c == 0 and d == 8 then -- day chuyen nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 9 then
					if a == 0 and  b == 4 and c == 0 and d == 9 then -- day chuyen nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 10 then
					if a == 0 and  b == 4 and c == 0 and d == 10 then -- day chuyen nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 11 then
					if a == 0 and  b == 4 and c == 1 and d == 1 then -- day chuyen nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 12 then
					if a == 0 and  b == 4 and c == 1 and d == 2 then -- day chuyen nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 13 then
					if a == 0 and  b == 4 and c == 1 and d == 3 then -- day chuyen nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 14 then
					if a == 0 and  b == 4 and c == 1 and d == 4 then -- day chuyen nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 15 then
					if a == 0 and  b == 4 and c == 1 and d == 5 then -- day chuyen nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 16 then
					if a == 0 and  b == 4 and c == 1 and d == 6 then -- day chuyen nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 17 then
					if a == 0 and  b == 4 and c == 1 and d == 7 then -- day chuyen nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 18 then
					if a == 0 and  b == 4 and c == 1 and d == 8 then -- day chuyen nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 19 then
					if a == 0 and  b == 4 and c == 1 then -- day chuyen nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 20 then
					if a == 0 and  b == 4 and c == 1 and d == 10 then -- day chuyen nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 21 then
					if a == 0 and  b == 4 and c == 0 then -- day chuyen nu tang sinh luc
						if f == 85 or g == 85 or h == 85 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 22 then
					if a == 0 and  b == 4 and c == 0 then -- day chuyen nu tang noi luc
						if f == 89 or g == 89 or h == 89 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 23 then
					if a == 0 and  b == 4 and c == 0 then -- day chuyen nu tang the luc
						if f == 93 or g == 93 or h == 93 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 24 then
					if a == 0 and  b == 4 and c == 0 then -- day chuyen nu tang khang tat ca
						if f == 114 or g == 114 or h == 114 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 25 then
					if a == 0 and  b == 4 and c == 0 then -- day chuyen nu tang khang doc
						if i == 101 or j == 101 or k == 101 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 26 then
					if a == 0 and  b == 4 and c == 0 then -- day chuyen nu tang khang loi
						if i == 103 or j == 103 or k == 103 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 27 then
					if a == 0 and  b == 4 and c == 0 then -- day chuyen nu tang khang bang
						if i == 105 or j == 105 or k == 105 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 28 then
					if a == 0 and  b == 4 and c == 0 then -- day chuyen nu tang khang hoa
						if i == 102 or j == 102 or k == 102 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 29 then
					if a == 0 and  b == 4 and c == 0 then -- day chuyen nu tang phuc hoi the luc
						if f == 96 or g == 96 or h == 96 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 30 then
					if a == 0 and  b == 4 and c == 0 then -- day chuyen nu giam thoi gian choang
						if i == 110 or j == 110 or k == 110 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 31 then
					if a == 0 and  b == 4 and c == 1 then -- day chuyen nam tang sinh luc
						if f == 85 or g == 85 or h == 85 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 32 then
					if a == 0 and  b == 4 and c == 1 then -- day chuyen nam tang noi luc
						if f == 89 or g == 89 or h == 89 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 33 then
					if a == 0 and  b == 4 and c == 1 then -- day chuyen nam tang the luc
						if f == 93 or g == 93 or h == 93 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 34 then
					if a == 0 and  b == 4 and c == 1 then -- day chuyen nam tang khang tat ca
						if f == 114 or g == 114 or h == 114 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 35 then
					if a == 0 and  b == 4 and c == 1 then -- day chuyen nam tang khang doc
						if i == 101 or j == 101 or k == 101 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 36 then
					if a == 0 and  b == 4 and c == 1 then -- day chuyen nam tang khang loi
						if i == 103 or j == 103 or k == 103 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 37 then
					if a == 0 and  b == 4 and c == 1 then -- day chuyen nam tang khang bang
						if i == 105 or j == 105 or k == 105 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 38 then
					if a == 0 and  b == 4 and c == 1 then -- day chuyen nam tang khang hoa
						if i == 102 or j == 102 or k == 102 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 39 then
					if a == 0 and  b == 4 and c == 1 then -- day chuyen nam tang phuc hoi the luc
						if f == 96 or g == 96 or h == 96 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 40 then
					if a == 0 and  b == 4 and c == 1 then -- day chuyen nam giam thoi gian choang
						if i == 110 or j == 110 or k == 110 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 41 then
					if a == 0 and  b == 9 and c == 0 and d == 1 then -- huong nang nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 42 then
					if a == 0 and  b == 9 and c == 0 and d == 2 then -- huong nang nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 43 then
					if a == 0 and  b == 9 and c == 0 and d == 3 then -- huong nang nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 44 then
					if a == 0 and  b == 9 and c == 0 and d == 4 then -- huong nang nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 45 then
					if a == 0 and  b == 9 and c == 0 and d == 5 then -- huong nang nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 46 then
					if a == 0 and  b == 9 and c == 0 and d == 6 then -- huong nang nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 47 then
					if a == 0 and  b == 9 and c == 0 and d == 7 then -- huong nang nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 48 then
					if a == 0 and  b == 9 and c == 0 and d == 8 then -- huong nang nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 49 then
					if a == 0 and  b == 9 and c == 0 and d == 9 then -- huong nang nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 50 then
					if a == 0 and  b == 9 and c == 0 and d == 10 then -- huong nang nu cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 51 then
					if a == 0 and  b == 9 and c == 1 and d == 1 then -- ngoc boi nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 52 then
					if a == 0 and  b == 9 and c == 1 and d == 2 then -- ngoc boi nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 53 then
					if a == 0 and  b == 9 and c == 1 and d == 3 then -- ngoc boi nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 54 then
					if a == 0 and  b == 9 and c == 1 and d == 4 then -- ngoc boi nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 55 then
					if a == 0 and  b == 9 and c == 1 and d == 5 then -- ngoc boi nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 56 then
					if a == 0 and  b == 9 and c == 1 and d == 6 then -- ngoc boi nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 57 then
					if a == 0 and  b == 9 and c == 1 and d == 7 then -- ngoc boi nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 58 then
					if a == 0 and  b == 9 and c == 1 and d == 8 then -- ngoc boi nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 59 then
					if a == 0 and  b == 9 and c == 1 and d == 9 then -- ngoc boi nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 60 then
					if a == 0 and  b == 9 and c == 1 and d == 10 then -- ngoc boi nam cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 61 then
					if a == 0 and  b == 9 and c == 0 then -- huong nang nu tang sinh luc
						if f == 85 or g == 85 or h == 85 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 62 then
					if a == 0 and  b == 9 and c == 0 then -- huong nang nu tang noi luc
						if f == 89 or g == 89 or h == 89 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 63 then
					if a == 0 and  b == 9 and c == 0 then -- huong nang nu tang the luc
						if f == 93 or g == 93 or h == 93 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 64 then
					if a == 0 and  b == 9 and c == 0 then -- huong nang nu tang khang tat ca
						if f == 92 or g == 92 or h == 92 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 65 then
					if a == 0 and  b == 9 and c == 0 then -- huong nang nu tang khang doc
						if i == 101 or j == 101 or k == 101 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 66 then
					if a == 0 and  b == 9 and c == 0 then -- huong nang nu tang khang loi
						if i == 103 or j == 103 or k == 103 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 67 then
					if a == 0 and  b == 9 and c == 0 then -- huong nang nu tang khang bang
						if i == 105 or j == 105 or k == 105 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 68 then
					if a == 0 and  b == 9 and c == 0 then -- huong nang nu tang khang hoa
						if i == 102 or j == 102 or k == 102 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 69 then
					if a == 0 and  b == 9 and c == 0 then -- huong nang nu tang phuc hoi the luc
						if f == 92 or g == 92 or h == 92 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 70 then
					if a == 0 and  b == 9 and c == 0 then -- huong nang nu giam thoi gian choang
						if i == 110 or j == 110 or k == 110 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 71 then
					if a == 0 and  b == 9 and c == 1 then -- ngoc boi nam tang sinh luc
						if f == 85 or g == 85 or h == 85 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 72 then
					if a == 0 and  b == 9 and c == 1 then -- ngoc boi nam tang noi luc
						if f == 89 or g == 89 or h == 89 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 73 then
					if a == 0 and  b == 9 and c == 1 then -- ngoc boi nam tang the luc
						if f == 93 or g == 93 or h == 93 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 74 then
					if a == 0 and  b == 9 and c == 1 then -- ngoc boi nam tang khang tat ca
						if f == 92 or g == 92 or h == 92 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 75 then
					if a == 0 and  b == 9 and c == 1 then -- ngoc boi nam tang khang doc
						if i == 101 or j == 101 or k == 101 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 76 then
					if a == 0 and  b == 9 and c == 1 then -- ngoc boi nam tang khang loi
						if i == 103 or j == 103 or k == 103 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 77 then
					if a == 0 and  b == 9 and c == 1 then -- ngoc boi nam tang khang bang
						if i == 105 or j == 105 or k == 105 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 78 then
					if a == 0 and  b == 9 and c == 1 then -- ngoc boi nam tang khang hoa
						if i == 102 or j == 102 or k == 102 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 79 then
					if a == 0 and  b == 9 and c == 1 then -- ngoc boi nam tang phuc hoi the luc
						if f == 92 or g == 92 or h == 92 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 80 then
					if a == 0 and  b == 9 and c == 1 then -- ngoc boi nam giam thoi gian choang
						if i == 110 or j == 110 or k == 110 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 81 then
					if a == 0 and  b == 3 and c == 0 and d == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 82 then
					if a == 0 and  b == 3 and c == 0 and d == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 83 then
					if a == 0 and  b == 3 and c == 0 and d == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 84 then
					if a == 0 and  b == 3 and c == 0 and d == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 85 then
					if a == 0 and  b == 3 and c == 0 and d == 5 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 86 then
					if a == 0 and  b == 3 and c == 0 and d == 6 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 87 then
					if a == 0 and  b == 3 and c == 0 and d == 7 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 88 then
					if a == 0 and  b == 3 and c == 0 and d == 8 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 89 then
					if a == 0 and  b == 3 and c == 0 and d == 9 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 90 then
					if a == 0 and  b == 3 and c == 0 and d == 10 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 91 then
					if a == 0 and  b == 3 and c == 0 then -- nhan tang sinh luc
						if f == 85 or g == 85 or h == 85 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 92 then
					if a == 0 and  b == 3 and c == 0 then -- nhan tang noi luc
						if f == 89 or g == 89 or h == 89 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 93 then
					if a == 0 and  b == 3 and c == 0 then -- nhan tang the luc
						if f == 93 or g == 93 or h == 93 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 94 then
					if a == 0 and  b == 3 and c == 0 then -- nhan tang khang tat ca
						if f == 96 or g == 96 or h == 96 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
						return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 95 then
					if a == 0 and  b == 3 and c == 0 then -- nhan tang khang doc
						if i == 101 or j == 101 or k == 101 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 96 then
					if a == 0 and  b == 3 and c == 0 then -- nhan tang khang loi
						if i == 103 or j == 103 or k == 103 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 97 then
					if a == 0 and  b == 3 and c == 0 then -- nhan tang khang bang
						if i == 105 or j == 105 or k == 105 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 98 then
					if a == 0 and  b == 3 and c == 0 then -- nhan tang khang hoa
						if i == 102 or j == 102 or k == 102 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 99 then
					if a == 0 and  b == 3 and c == 0 then -- nhan tang phuc hoi the luc
						if f == 96 or g == 96 or h == 96 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 100 then
					if a == 0 and  b == 3 and c == 0 then -- nhan giam thoi gian choang
						if i == 110 or j == 110 or k == 110 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cac he
				-- nhan cap 1
				elseif GetTask(T_TimVatPham) == 101 then
					if a == 0 and  b == 3 and c == 0 and d == 1 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 102 then
					if a == 0 and  b == 3 and c == 0 and d == 1 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 103 then
					if a == 0 and  b == 3 and c == 0 and d == 1 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 104 then
					if a == 0 and  b == 3 and c == 0 and d == 1 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 105 then
					if a == 0 and  b == 3 and c == 0 and d == 1 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 2
				elseif GetTask(T_TimVatPham) == 106 then
					if a == 0 and  b == 3 and c == 0 and d == 2 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 107 then
					if a == 0 and  b == 3 and c == 0 and d == 2 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 108 then
					if a == 0 and  b == 3 and c == 0 and d == 2 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 109 then
					if a == 0 and  b == 3 and c == 0 and d == 2 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 110 then
					if a == 0 and  b == 3 and c == 0 and d == 2 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 3
				elseif GetTask(T_TimVatPham) == 111 then
					if a == 0 and  b == 3 and c == 0 and d == 3 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 112 then
					if a == 0 and  b == 3 and c == 0 and d == 3 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 113 then
					if a == 0 and  b == 3 and c == 0 and d == 3 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 114 then
					if a == 0 and  b == 3 and c == 0 and d == 3 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 115 then
					if a == 0 and  b == 3 and c == 0 and d == 3 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 4
				elseif GetTask(T_TimVatPham) == 116 then
					if a == 0 and  b == 3 and c == 0 and d == 4 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 117 then
					if a == 0 and  b == 3 and c == 0 and d == 4 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 118 then
					if a == 0 and  b == 3 and c == 0 and d == 4 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 119 then
					if a == 0 and  b == 3 and c == 0 and d == 4 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 120 then
					if a == 0 and  b == 3 and c == 0 and d == 4 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 5
				elseif GetTask(T_TimVatPham) == 121 then
					if a == 0 and  b == 3 and c == 0 and d == 5 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 122 then
					if a == 0 and  b == 3 and c == 0 and d == 5 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 123 then
					if a == 0 and  b == 3 and c == 0 and d == 5 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 124 then
					if a == 0 and  b == 3 and c == 0 and d == 5 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 125 then
					if a == 0 and  b == 3 and c == 0 and d == 5 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 6
				elseif GetTask(T_TimVatPham) == 126 then
					if a == 0 and  b == 3 and c == 0 and d == 6 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 127 then
					if a == 0 and  b == 3 and c == 0 and d == 6 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 128 then
					if a == 0 and  b == 3 and c == 0 and d == 6 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 129 then
					if a == 0 and  b == 3 and c == 0 and d == 6 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 130 then
					if a == 0 and  b == 3 and c == 0 and d == 6 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 7
				elseif GetTask(T_TimVatPham) == 131 then
					if a == 0 and  b == 3 and c == 0 and d == 7 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 132 then
					if a == 0 and  b == 3 and c == 0 and d == 7 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 133 then
					if a == 0 and  b == 3 and c == 0 and d == 7 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 134 then
					if a == 0 and  b == 3 and c == 0 and d == 7 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 135 then
					if a == 0 and  b == 3 and c == 0 and d == 7 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 8
				elseif GetTask(T_TimVatPham) == 136 then
					if a == 0 and  b == 3 and c == 0 and d == 8 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 137 then
					if a == 0 and  b == 3 and c == 0 and d == 8 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 138 then
					if a == 0 and  b == 3 and c == 0 and d == 8 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 139 then
					if a == 0 and  b == 3 and c == 0 and d == 8 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 140 then
					if a == 0 and  b == 3 and c == 0 and d == 8 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 9
				elseif GetTask(T_TimVatPham) == 141 then
					if a == 0 and  b == 3 and c == 0 and d == 9 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 142 then
					if a == 0 and  b == 3 and c == 0 and d == 9 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 143 then
					if a == 0 and  b == 3 and c == 0 and d == 9 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 144 then
					if a == 0 and  b == 3 and c == 0 and d == 9 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 145 then
					if a == 0 and  b == 3 and c == 0 and d == 9 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 10
				elseif GetTask(T_TimVatPham) == 146 then
					if a == 0 and  b == 3 and c == 0 and d == 10 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 147 then
					if a == 0 and  b == 3 and c == 0 and d == 10 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 148 then
					if a == 0 and  b == 3 and c == 0 and d == 10 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 149 then
					if a == 0 and  b == 3 and c == 0 and d == 10 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 150 then
					if a == 0 and  b == 3 and c == 0 and d == 10 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- ngoc boi cac he
				-- ngoc boi cap 1
				elseif GetTask(T_TimVatPham) == 151 then
					if a == 0 and  b == 9 and c == 1 and d == 1 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 152 then
					if a == 0 and  b == 9 and c == 1 and d == 1 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 153 then
					if a == 0 and  b == 9 and c == 1 and d == 1 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 154 then
					if a == 0 and  b == 9 and c == 1 and d == 1 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 155 then
					if a == 0 and  b == 9 and c == 1 and d == 1 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 2
				elseif GetTask(T_TimVatPham) == 156 then
					if a == 0 and  b == 9 and c == 1 and d == 2 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 157 then
					if a == 0 and  b == 9 and c == 1 and d == 2 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 158 then
					if a == 0 and  b == 9 and c == 1 and d == 2 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 159 then
					if a == 0 and  b == 9 and c == 1 and d == 2 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 160 then
					if a == 0 and  b == 9 and c == 1 and d == 2 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 3
				elseif GetTask(T_TimVatPham) == 161 then
					if a == 0 and  b == 9 and c == 1 and d == 3 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 162 then
					if a == 0 and  b == 9 and c == 1 and d == 3 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 163 then
					if a == 0 and  b == 9 and c == 1 and d == 3 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 164 then
					if a == 0 and  b == 9 and c == 1 and d == 3 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 165 then
					if a == 0 and  b == 9 and c == 1 and d == 3 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 4
				elseif GetTask(T_TimVatPham) == 166 then
					if a == 0 and  b == 9 and c == 1 and d == 4 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 167 then
					if a == 0 and  b == 9 and c == 1 and d == 4 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 168 then
					if a == 0 and  b == 9 and c == 1 and d == 4 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 169 then
					if a == 0 and  b == 9 and c == 1 and d == 4 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 170 then
					if a == 0 and  b == 9 and c == 1 and d == 4 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 5
				elseif GetTask(T_TimVatPham) == 171 then
					if a == 0 and  b == 9 and c == 1 and d == 5 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 172 then
					if a == 0 and  b == 9 and c == 1 and d == 5 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 173 then
					if a == 0 and  b == 9 and c == 1 and d == 5 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 174 then
					if a == 0 and  b == 9 and c == 1 and d == 5 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 175 then
					if a == 0 and  b == 9 and c == 1 and d == 5 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 6
				elseif GetTask(T_TimVatPham) == 176 then
					if a == 0 and  b == 9 and c == 1 and d == 6 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 177 then
					if a == 0 and  b == 9 and c == 1 and d == 6 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 178 then
					if a == 0 and  b == 9 and c == 1 and d == 6 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 179 then
					if a == 0 and  b == 9 and c == 1 and d == 6 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 180 then
					if a == 0 and  b == 9 and c == 1 and d == 6 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 7
				elseif GetTask(T_TimVatPham) == 181 then
					if a == 0 and  b == 9 and c == 1 and d == 7 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 182 then
					if a == 0 and  b == 9 and c == 1 and d == 7 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 183 then
					if a == 0 and  b == 9 and c == 1 and d == 7 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 184 then
					if a == 0 and  b == 9 and c == 1 and d == 7 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 185 then
					if a == 0 and  b == 9 and c == 1 and d == 7 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 8
				elseif GetTask(T_TimVatPham) == 186 then
					if a == 0 and  b == 9 and c == 1 and d == 8 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 187 then
					if a == 0 and  b == 9 and c == 1 and d == 8 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 188 then
					if a == 0 and  b == 9 and c == 1 and d == 8 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 189 then
					if a == 0 and  b == 9 and c == 1 and d == 8 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 190 then
					if a == 0 and  b == 9 and c == 1 and d == 8 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 9
				elseif GetTask(T_TimVatPham) == 191 then
					if a == 0 and  b == 9 and c == 1 and d == 9 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 192 then
					if a == 0 and  b == 9 and c == 1 and d == 9 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 193 then
					if a == 0 and  b == 9 and c == 1 and d == 9 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 194 then
					if a == 0 and  b == 9 and c == 1 and d == 9 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 195 then
					if a == 0 and  b == 9 and c == 1 and d == 9 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 10
				elseif GetTask(T_TimVatPham) == 196 then
					if a == 0 and  b == 9 and c == 1 and d == 10 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 197 then
					if a == 0 and  b == 9 and c == 1 and d == 10 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 198 then
					if a == 0 and  b == 9 and c == 1 and d == 10 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 199 then
					if a == 0 and  b == 9 and c == 1 and d == 10 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 200 then
					if a == 0 and  b == 9 and c == 1 and d == 10 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				--huong nang cac he
				elseif GetTask(T_TimVatPham) == 201 then
					if a == 0 and  b == 9 and c == 0 and d == 1 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 202 then
					if a == 0 and  b == 9 and c == 0 and d == 1 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 203 then
					if a == 0 and  b == 9 and c == 0 and d == 1 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 204 then
					if a == 0 and  b == 9 and c == 0 and d == 1 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 205 then
					if a == 0 and  b == 9 and c == 0 and d == 1 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 2
				elseif GetTask(T_TimVatPham) == 206 then
					if a == 0 and  b == 9 and c == 0 and d == 2 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 207 then
					if a == 0 and  b == 9 and c == 0 and d == 2 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 208 then
					if a == 0 and  b == 9 and c == 0 and d == 2 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 209 then
					if a == 0 and  b == 9 and c == 0 and d == 2 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 210 then
					if a == 0 and  b == 9 and c == 0 and d == 2 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 3
				elseif GetTask(T_TimVatPham) == 211 then
					if a == 0 and  b == 9 and c == 0 and d == 3 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 212 then
					if a == 0 and  b == 9 and c == 0 and d == 3 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 213 then
					if a == 0 and  b == 9 and c == 0 and d == 3 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 214 then
					if a == 0 and  b == 9 and c == 0 and d == 3 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 215 then
					if a == 0 and  b == 9 and c == 0 and d == 3 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 4
				elseif GetTask(T_TimVatPham) == 216 then
					if a == 0 and  b == 9 and c == 0 and d == 4 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 217 then
					if a == 0 and  b == 9 and c == 0 and d == 4 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 218 then
					if a == 0 and  b == 9 and c == 0 and d == 4 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 219 then
					if a == 0 and  b == 9 and c == 0 and d == 4 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 220 then
					if a == 0 and  b == 9 and c == 0 and d == 4 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 5
				elseif GetTask(T_TimVatPham) == 221 then
					if a == 0 and  b == 9 and c == 0 and d == 5 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 222 then
					if a == 0 and  b == 9 and c == 0 and d == 5 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 223 then
					if a == 0 and  b == 9 and c == 0 and d == 5 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 224 then
					if a == 0 and  b == 9 and c == 0 and d == 5 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 225 then
					if a == 0 and  b == 9 and c == 0 and d == 5 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 6
				elseif GetTask(T_TimVatPham) == 226 then
					if a == 0 and  b == 9 and c == 0 and d == 6 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 227 then
					if a == 0 and  b == 9 and c == 0 and d == 6 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 228 then
					if a == 0 and  b == 9 and c == 0 and d == 6 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 229 then
					if a == 0 and  b == 9 and c == 0 and d == 6 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 230 then
					if a == 0 and  b == 9 and c == 0 and d == 6 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 7
				elseif GetTask(T_TimVatPham) == 231 then
					if a == 0 and  b == 9 and c == 0 and d == 7 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 232 then
					if a == 0 and  b == 9 and c == 0 and d == 7 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 233 then
					if a == 0 and  b == 9 and c == 0 and d == 7 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 234 then
					if a == 0 and  b == 9 and c == 0 and d == 7 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 235 then
					if a == 0 and  b == 9 and c == 0 and d == 7 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 8
				elseif GetTask(T_TimVatPham) == 236 then
					if a == 0 and  b == 9 and c == 0 and d == 8 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 237 then
					if a == 0 and  b == 9 and c == 0 and d == 8 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 238 then
					if a == 0 and  b == 9 and c == 0 and d == 8 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 239 then
					if a == 0 and  b == 9 and c == 0 and d == 8 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 240 then
					if a == 0 and  b == 9 and c == 0 and d == 8 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 9
				elseif GetTask(T_TimVatPham) == 241 then
					if a == 0 and  b == 9 and c == 0 and d == 9 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 242 then
					if a == 0 and  b == 9 and c == 0 and d == 9 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 243 then
					if a == 0 and  b == 9 and c == 0 and d == 9 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 244 then
					if a == 0 and  b == 9 and c == 0 and d == 9 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 245 then
					if a == 0 and  b == 9 and c == 0 and d == 9 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 10
				elseif GetTask(T_TimVatPham) == 246 then
					if a == 0 and  b == 9 and c == 0 and d == 10 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 247 then
					if a == 0 and  b == 9 and c == 0 and d == 10 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 248 then
					if a == 0 and  b == 9 and c == 0 and d == 10 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 249 then
					if a == 0 and  b == 9 and c == 0 and d == 10 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 250 then
					if a == 0 and  b == 9 and c == 0 and d == 10 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- ngoc boi cac he
				-- ngoc boi cap 1
				elseif GetTask(T_TimVatPham) == 251 then
					if a == 0 and  b == 4 and c == 0 and d == 1 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 252 then
					if a == 0 and  b == 4 and c == 0 and d == 1 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 253 then
					if a == 0 and  b == 4 and c == 0 and d == 1 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 254 then
					if a == 0 and  b == 4 and c == 0 and d == 1 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 255 then
					if a == 0 and  b == 4 and c == 0 and d == 1 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 2
				elseif GetTask(T_TimVatPham) == 256 then
					if a == 0 and  b == 4 and c == 0 and d == 2 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 257 then
					if a == 0 and  b == 4 and c == 0 and d == 2 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 258 then
					if a == 0 and  b == 4 and c == 0 and d == 2 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 259 then
					if a == 0 and  b == 4 and c == 0 and d == 2 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 260 then
					if a == 0 and  b == 4 and c == 0 and d == 2 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 3
				elseif GetTask(T_TimVatPham) == 261 then
					if a == 0 and  b == 4 and c == 0 and d == 3 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 262 then
					if a == 0 and  b == 4 and c == 0 and d == 3 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 263 then
					if a == 0 and  b == 4 and c == 0 and d == 3 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 264 then
					if a == 0 and  b == 4 and c == 0 and d == 3 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 265 then
					if a == 0 and  b == 4 and c == 0 and d == 3 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 4
				elseif GetTask(T_TimVatPham) == 266 then
					if a == 0 and  b == 4 and c == 0 and d == 4 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 267 then
					if a == 0 and  b == 4 and c == 0 and d == 4 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 268 then
					if a == 0 and  b == 4 and c == 0 and d == 4 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 269 then
					if a == 0 and  b == 4 and c == 0 and d == 4 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 270 then
					if a == 0 and  b == 4 and c == 0 and d == 4 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 5
				elseif GetTask(T_TimVatPham) == 271 then
					if a == 0 and  b == 4 and c == 0 and d == 5 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 272 then
					if a == 0 and  b == 4 and c == 0 and d == 5 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 273 then
					if a == 0 and  b == 4 and c == 0 and d == 5 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 274 then
					if a == 0 and  b == 4 and c == 0 and d == 5 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 275 then
					if a == 0 and  b == 4 and c == 0 and d == 5 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 6
				elseif GetTask(T_TimVatPham) == 276 then
					if a == 0 and  b == 4 and c == 0 and d == 6 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 277 then
					if a == 0 and  b == 4 and c == 0 and d == 6 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 278 then
					if a == 0 and  b == 4 and c == 0 and d == 6 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 279 then
					if a == 0 and  b == 4 and c == 0 and d == 6 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 280 then
					if a == 0 and  b == 4 and c == 0 and d == 6 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 7
				elseif GetTask(T_TimVatPham) == 281 then
					if a == 0 and  b == 4 and c == 0 and d == 7 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 282 then
					if a == 0 and  b == 4 and c == 0 and d == 7 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 283 then
					if a == 0 and  b == 4 and c == 0 and d == 7 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 284 then
					if a == 0 and  b == 4 and c == 0 and d == 7 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 285 then
					if a == 0 and  b == 4 and c == 0 and d == 7 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 8
				elseif GetTask(T_TimVatPham) == 286 then
					if a == 0 and  b == 4 and c == 0 and d == 8 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 287 then
					if a == 0 and  b == 4 and c == 0 and d == 8 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 288 then
					if a == 0 and  b == 4 and c == 0 and d == 8 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 289 then
					if a == 0 and  b == 4 and c == 0 and d == 8 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 290 then
					if a == 0 and  b == 4 and c == 0 and d == 8 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 9
				elseif GetTask(T_TimVatPham) == 291 then
					if a == 0 and  b == 4 and c == 0 and d == 9 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 292 then
					if a == 0 and  b == 4 and c == 0 and d == 9 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 293 then
					if a == 0 and  b == 4 and c == 0 and d == 9 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 294 then
					if a == 0 and  b == 4 and c == 0 and d == 9 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 295 then
					if a == 0 and  b == 4 and c == 0 and d == 9 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 10
				elseif GetTask(T_TimVatPham) == 296 then
					if a == 0 and  b == 4 and c == 0 and d == 10 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 297 then
					if a == 0 and  b == 4 and c == 0 and d == 10 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 298 then
					if a == 0 and  b == 4 and c == 0 and d == 10 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 299 then
					if a == 0 and  b == 4 and c == 0 and d == 10 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 300 then
					if a == 0 and  b == 4 and c == 0 and d == 10 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				--ho than phu cac he
				elseif GetTask(T_TimVatPham) == 301 then
					if a == 0 and  b == 4 and c == 1 and d == 1 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 302 then
					if a == 0 and  b == 4 and c == 1 and d == 1 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 303 then
					if a == 0 and  b == 4 and c == 1 and d == 1 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 304 then
					if a == 0 and  b == 4 and c == 1 and d == 1 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 305 then
					if a == 0 and  b == 4 and c == 1 and d == 1 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 2
				elseif GetTask(T_TimVatPham) == 306 then
					if a == 0 and  b == 4 and c == 1 and d == 2 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 307 then
					if a == 0 and  b == 4 and c == 1 and d == 2 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 308 then
					if a == 0 and  b == 4 and c == 1 and d == 2 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 309 then
					if a == 0 and  b == 4 and c == 1 and d == 2 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 310 then
					if a == 0 and  b == 4 and c == 1 and d == 2 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 3
				elseif GetTask(T_TimVatPham) == 311 then
					if a == 0 and  b == 4 and c == 1 and d == 3 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 312 then
					if a == 0 and  b == 4 and c == 1 and d == 3 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 313 then
					if a == 0 and  b == 4 and c == 1 and d == 3 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 314 then
					if a == 0 and  b == 4 and c == 1 and d == 3 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 315 then
					if a == 0 and  b == 4 and c == 1 and d == 3 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 4
				elseif GetTask(T_TimVatPham) == 316 then
					if a == 0 and  b == 4 and c == 1 and d == 4 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 317 then
					if a == 0 and  b == 4 and c == 1 and d == 4 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 318 then
					if a == 0 and  b == 4 and c == 1 and d == 4 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 319 then
					if a == 0 and  b == 4 and c == 1 and d == 4 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 320 then
					if a == 0 and  b == 4 and c == 1 and d == 4 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 5
				elseif GetTask(T_TimVatPham) == 321 then
					if a == 0 and  b == 4 and c == 1 and d == 5 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 322 then
					if a == 0 and  b == 4 and c == 1 and d == 5 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 323 then
					if a == 0 and  b == 4 and c == 1 and d == 5 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 324 then
					if a == 0 and  b == 4 and c == 1 and d == 5 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 325 then
					if a == 0 and  b == 4 and c == 1 and d == 5 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 6
				elseif GetTask(T_TimVatPham) == 326 then
					if a == 0 and  b == 4 and c == 1 and d == 6 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 327 then
					if a == 0 and  b == 4 and c == 1 and d == 6 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 328 then
					if a == 0 and  b == 4 and c == 1 and d == 6 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 329 then
					if a == 0 and  b == 4 and c == 1 and d == 6 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 330 then
					if a == 0 and  b == 4 and c == 1 and d == 6 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 7
				elseif GetTask(T_TimVatPham) == 331 then
					if a == 0 and  b == 4 and c == 1 and d == 7 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 332 then
					if a == 0 and  b == 4 and c == 1 and d == 7 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 333 then
					if a == 0 and  b == 4 and c == 1 and d == 7 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 334 then
					if a == 0 and  b == 4 and c == 1 and d == 7 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 335 then
					if a == 0 and  b == 4 and c == 1 and d == 7 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 8
				elseif GetTask(T_TimVatPham) == 336 then
					if a == 0 and  b == 4 and c == 1 and d == 8 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 337 then
					if a == 0 and  b == 4 and c == 1 and d == 8 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 338 then
					if a == 0 and  b == 4 and c == 1 and d == 8 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 339 then
					if a == 0 and  b == 4 and c == 1 and d == 8 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 340 then
					if a == 0 and  b == 4 and c == 1 and d == 8 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 9
				elseif GetTask(T_TimVatPham) == 341 then
					if a == 0 and  b == 4 and c == 1 and d == 9 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 342 then
					if a == 0 and  b == 4 and c == 1 and d == 9 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 343 then
					if a == 0 and  b == 4 and c == 1 and d == 9 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 344 then
					if a == 0 and  b == 4 and c == 1 and d == 9 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 345 then
					if a == 0 and  b == 4 and c == 1 and d == 9 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				-- nhan cap 10
				elseif GetTask(T_TimVatPham) == 346 then
					if a == 0 and  b == 4 and c == 1 and d == 10 and e == 0 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 347 then
					if a == 0 and  b == 4 and c == 1 and d == 10 and e == 1 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 348 then
					if a == 0 and  b == 4 and c == 1 and d == 10 and e == 2 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 349 then
					if a == 0 and  b == 4 and c == 1 and d == 10 and e == 3 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				elseif GetTask(T_TimVatPham) == 350 then
					if a == 0 and  b == 4 and c == 1 and d == 10 and e == 4 then -- nhan cap == d
						DelItem(GetIndexGiveItem(nIndex))
						finishquest()
						return
					else
						Talk(1,"no", TAB_MSG[1])
					end
				end
				elseif GetTask(T_TimVatPham) == 351 then
						if a == 0 and  b == 4 and c == 0 then -- nhan cap == d
							if l >= 1 and l <= 5 or n >= 1 and n <= 5 or m >= 1 and m <= 5 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
							else
								Talk(1,"no", TAB_MSG[1])
							end
						end
				elseif GetTask(T_TimVatPham) == 352 then
						Msg2Player("OK ma")
						-- if a == 0 and  b == 4 and c == 0 then -- nhan cap == d
							-- if l >= 6 and l <= 10 or n >= 6 and n <= 10 or m >= 6 and m <= 10 then
							-- DelItem(GetIndexGiveItem(nIndex))
							-- finishquest()
							-- return
						-- else
							-- Talk(1,"no", TAB_MSG[1])
						-- end
						-- end
				elseif GetTask(T_TimVatPham) == 353 then
						if a == 0 and  b == 4 and c == 0 then -- nhan cap == d
							if l >= 11 and l <= 15 or n >= 11 and n <= 15 or m >= 11 and m <= 15 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					end
				elseif GetTask(T_TimVatPham) == 354 then
						if a == 0 and  b == 4 and c == 0 then -- nhan cap == d
							if l >= 16 and l <= 20 or n >= 16 and n <= 20 or m >= 16 and m <= 20 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					end
				elseif GetTask(T_TimVatPham) == 355 then
						if a == 0 and  b == 4 and c == 0 then -- nhan cap == d
							if l >= 9 and l <= 11 or n >= 9 and n <= 11 or m >= 9 and m <= 11 then
							DelItem(GetIndexGiveItem(nIndex))
							finishquest()
							return
						else
							Talk(1,"no", TAB_MSG[1])
						end
					end
				end
		else
			Talk(1,"no", TAB_MSG[2])
		end	
	else
		Talk(1,"no", TAB_MSG[3])
	end	
end

