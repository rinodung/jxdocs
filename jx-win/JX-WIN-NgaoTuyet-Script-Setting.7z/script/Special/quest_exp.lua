--Author: lzlsky301
--Date: 07/11/12
Include("\\script\\global\\sourceatn.lua")
Include("\\script\\global\\tasklist.lua")

EXP = {
	{1,5000,20000},
	{2,10000,30000},
	{3,15000,40000},
	{4,20000,50000},
	{5,25000,80000},
	{6,35000,90000},
	{7,45000,120000},
	{8,45000,130000},
	{9,45000,170000},
	{10,70000,250000},
	{11,70000,390000},
	{12,70000,530000},
	{13,90000,780000},
	{14,90000,2600000},
	{15,90000,3500000},
	{16,100000,5000000},
	{17,100000,10800000},
}
function main()
	-- dofile("script/special/quest_exp.lua")
	finish_exp()
end

function finish_exp()
	aHeo = GetTask(T_MayMan)
	if aHeo >= 1 then
		for i=1,17 do
			if EXP[i][1] == aHeo then
			b = random(EXP[i][2],EXP[i][3])
			AddSumExp(b)
			SetTask(T_MayMan,0)
			Talk(1,"no","<color=pink>Ho�n th�nh nhi�m v�, nh�n ���c <color=green>"..b.."<color> kinh nghi�m.")
			return
			end
		end
	elseif ((GetTask(T_NVuHoangKim) == 9) and (GetTask(T_NhanThuongNVHK) == 0)) then
		SetTask(T_NhanThuongNVHK,1)
		AddSumExp(1000000)
		Msg2Player("Ho�n th�nh nhi�m v� ho�ng kim nh�n ���c 1.000.000 �i�m kinh nghi�m ")
		Msg2SubWorld(" "..GetName().." Ho�n th�nh nhi�m v� ho�ng kim nh�n ���c 1.000.000 �i�m kinh nghi�m ",1)
		return
	elseif ((GetTask(T_NVuHoangKim) == 15) and (GetTask(T_NhanThuongNVHK) == 1)) then
			SetTask(T_NhanThuongNVHK,2)
			AddSumExp(1500000)
			Msg2Player("Ho�n th�nh nhi�m v� ho�ng kim nh�n ���c 1.500.000 �i�m kinh nghi�m ")
			Msg2SubWorld(""..GetName().." Ho�n th�nh nhi�m v� ho�ng kim nh�n ���c 1.500.000 �i�m kinh nghi�m ",1)
			return
	elseif ((GetTask(T_NVuHoangKim) == 25) and (GetTask(T_NhanThuongNVHK) == 2)) then
			SetTask(T_NhanThuongNVHK,3)
			AddSumExp(2000000)
			Msg2Player("Ho�n th�nh nhi�m v� ho�ng kim nh�n ���c 2.000.000 �i�m kinh nghi�m ")
			Msg2SubWorld(""..GetName().." Ho�n th�nh nhi�m v� ho�ng kim nh�n ���c 2.000.000 �i�m kinh nghi�m ",1)
			return
		-- end
	-- elseif GetTask(T_NVuThienHoang) == 2 and GetTask(T_TienDoNVTHoang) == 1 then
		-- if GetTask(T_TienDoNVTHoang) == 1 then
			-- SetTask(T_NVuThienHoang,3)
				-- if GetTask(T_TienDoNVTHoang) == 1 and GetTask(T_NVuThienHoang) == 3 then
					-- SetTask(T_TienDoNVTHoang,0)
					-- AddSumExp(3000000)
					-- for i=1,100 do AddEventItem(random(37,39)) end
						-- Msg2Player("Ho�n th�nh nhi�m v� Thi�n Ho�ng nh�n ���c 100 t�i m�ng xu�n ")
						-- Msg2Player("Ho�n th�nh nhi�m v� Thi�n Ho�ng nh�n ���c 3.000.000 �i�m kinh nghi�m ")
						-- Msg2SubWorld(""..GetName().." Ho�n th�nh nhi�m v� Thi�n Ho�ng nh�n ���c 3.000.000 �i�m kinh nghi�m ",1)
					-- return
				-- else
					-- return
				-- end
			-- return
		-- end
	-- elseif GetTask(T_NVuThienHoang) == 5 and GetTask(T_TienDoNVTHoang) == 1 then
		-- if GetTask(T_TienDoNVTHoang) == 1 then
			-- SetTask(T_NVuThienHoang,6)
				-- if GetTask(T_TienDoNVTHoang) == 1 and GetTask(T_NVuThienHoang) == 6 then
					-- AddSumExp(4000000)
					-- SetTask(T_TienDoNVTHoang,0)
					-- for i=1,100 do AddEventItem(random(37,39)) end
						-- Msg2Player("Ho�n th�nh nhi�m v� Thi�n Ho�ng nh�n ���c 100 t�i m�ng xu�n ")
						-- Msg2Player("Ho�n th�nh nhi�m v� Thi�n Ho�ng nh�n ���c 4.000.000 �i�m kinh nghi�m ")
						-- Msg2SubWorld(""..GetName().." Ho�n th�nh nhi�m v� Thi�n Ho�ng nh�n ���c 4.000.000 �i�m kinh nghi�m ",1)
					-- return
				-- else
					-- return
				-- end
			-- return
		-- end
	-- elseif GetTask(T_NVuThienHoang) == 8 and GetTask(T_TienDoNVTHoang) == 1 then
		-- if GetTask(T_TienDoNVTHoang) == 1 then
			-- SetTask(T_NVuThienHoang,9)
				-- if GetTask(T_TienDoNVTHoang) == 1 and GetTask(T_NVuThienHoang) == 9 then
					-- AddSumExp(5000000)
					-- SetTask(T_TienDoNVTHoang,0)
					-- for i=1,100 do AddEventItem(random(37,39)) end
						-- Msg2Player("Ho�n th�nh nhi�m v� Thi�n Ho�ng nh�n ���c 100 t�i m�ng xu�n ")
						-- Msg2Player("Ho�n th�nh nhi�m v� Thi�n Ho�ng nh�n ���c 5.000.000 �i�m kinh nghi�m ")
						-- Msg2SubWorld(""..GetName().." Ho�n th�nh nhi�m v� Thi�n Ho�ng nh�n ���c 5.000.000 �i�m kinh nghi�m ",1)
					-- return
				-- else
					-- return
				-- end
			-- return
		-- end
	-- elseif GetTask(T_NVuThienHoang) == 9 and GetTask(T_TienDoNVTHoang) == 1 then
		-- if GetTask(T_TienDoNVTHoang) == 1 then
			-- SetTask(T_NVuThienHoang,10)
				-- if GetTask(T_TienDoNVTHoang) == 1 and GetTask(T_NVuThienHoang) == 10 then
					-- AddSumExp(8000000)
					-- SetTask(T_TienDoNVTHoang,0)
					-- for i=1,100 do AddEventItem(random(37,39)) end
						-- Msg2Player("Ho�n th�nh nhi�m v� Thi�n Ho�ng nh�n ���c 100 t�i m�ng xu�n ")
						-- Msg2Player("Ho�n th�nh nhi�m v� Thi�n Ho�ng nh�n ���c 8.000.000 �i�m kinh nghi�m ")
						-- Msg2SubWorld(""..GetName().." Ho�n th�nh nhi�m v� Thi�n Ho�ng nh�n ���c 8.000.000 �i�m kinh nghi�m ",1)
					-- return
				-- else
					-- return
				-- end
			-- return
		-- end
	else
		Talk(1,"","L�i r�i L�n �i.")
		return
	end
end
