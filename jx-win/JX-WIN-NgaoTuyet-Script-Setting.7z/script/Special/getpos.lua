--Author: lzlsky301
--Date: 07/11/12
Include("\\script\\global\\sourceatn.lua")
Include("\\script\\global\\tasklist.lua")

function main()
	W, X, Y = GetWorldPos()
	log = "{"..X..", "..Y.."},\n"
	logWrite(log)
end

function logWrite(str)
	local gm_Log = "dulieu/player_log/"..date("%Y_%m_%d").."/"..GetPlayerAccount().."/"..GetName()..".txt"
	local fs_log = openfile(gm_Log, "a");
	write(fs_log, str);
	closefile(fs_log);
end
