--Author: lzlsky301
--Date: 07/11/12
Include("\\script\\header\\taskid.lua");
Include("\\script\\library\\worldlibrary.lua");

function main()
	-- dofile("script/special/quest_point.lua")
	finish_point()
end

function finish_point()
	local POINT = {
	{1,5,10,3},{2,5,15,5},{3,5,20,7},{4,5,30,9},
	{5,5,35,11},{6,5,40,13},{7,5,45,15},{8,5,50,17},
	{9,10,60,19},{10,15,70,21},{11,20,70,23},{12,25,75,25},
	{13,30,75,27},{14,35,80,29},{15,40,80,31},
	{16,50,100,33},{17,50,100,35},}
	local TAB_MINE = {
	{1,0},{2,1},{3,2},
	{4,3},{5,4},{6,5},
	{7,6},{8,7},{9,8},
	{10,9},{11,10},{12,11},
	{13,12},{14,13},{15,14},
	{16,15},{17,16},{18,17}}
	local TAB_PHUCDUYEN = {{1,31},{2,32},{3,33}}
	local TAB_POINT = {
		"<color=green>Ho�n th�nh nhi�m v�, nh�n ���c m�t v�t ph�m ",
		}
	local aHeo = random(1,2)
	if (aHeo == 1) then
		local f = random(1,2)
		if f == 1 then
		a = GetTask(T_MayMan)
			if a >= 1 then
				for i=1,17 do
					if POINT[i][1] == a then
						AddRepute(POINT[i][4])
						SetTask(T_MayMan,0)
						Msg2Player("Ho�n th�nh nhi�m v�, nh�n ���c <color=blue>"..POINT[i][4].." danh v�ng")
					end
				end
			else
				Talk(1,"no", 10072)
			end
			return
		elseif f == 2 then
		a = GetTask(T_MayMan)
			if a >= 1 then
				for i=1,17 do
					if POINT[i][1] == a then
						b = random(POINT[i][2],POINT[i][3])
						AddFuYuan(b)
						SetTask(T_MayMan,0)
						Msg2Player("Ho�n th�nh nhi�m v�, nh�n ���c <color=blue>"..POINT[i][4].." ph�c duy�n")
					end
				end
			else
				Talk(1,"no", 10072)
			end
		end
		return
	elseif (aHeo == 2) then
		local f = random(1,3)
		local a = GetTask(T_MayMan)
		if a >= 1 then
			for i=1,getn(TAB_PHUCDUYEN) do
				if (i == f) then
					AddEventItem(TAB_PHUCDUYEN[i][2])
					Msg2Player(TAB_POINT[1])
				end
			end
		end
		return
	else
		local f = random(1,getn(TAB_MINE))
		local a = GetTask(T_MayMan)
		if a >= 1 then
			for i=1,getn(TAB_MINE) do
				if (i == f) then
					AddMineItem(TAB_MINE[i][2])
					Msg2Player(TAB_POINT[1])
				end
			end
		end
	end
end
