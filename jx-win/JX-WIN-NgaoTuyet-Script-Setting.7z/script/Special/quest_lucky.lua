--Author: lzlsky301
--Date: 07/11/12
Include("\\script\\global\\sourceatn.lua")
Include("\\script\\global\\tasklist.lua")

function main()
	-- dofile("script/special/quest_lucky.lua")
	finish_lucky()
end

function finish_lucky()
	local TAB_FINISHLUCKY = {
		"<color=green>D� T�u:<color> <color=earth>Ho�n th�nh nhi�m v�, nh�n ���c c� h�i h�y b�.",
		}
	if GetTask(T_MayMan) >= 1 then
		SetTask(T_MayMan, 0)
		SetTask(T_HuyNhiemVu, GetTask(T_HuyNhiemVu) + 1)
		Talk(1,"no",TAB_FINISHLUCKY[1])	
	else
		Talk(1,"no", 10072)
	end
end
