--Author: lzlsky301
--Date: 07/11/12
Include("\\script\\global\\sourceatn.lua")
Include("\\script\\global\\tasklist.lua")

function TrembleItem()
	local TAB_TREMBLEITEM = {
		"Thao t�c kham n�m Bao Th�ch th�nh c�ng.",
		"Thao t�c kham n�m Bao Th�ch th�t b�i. ",
		"Ch� ���c ��t m�t lo�i Th�y tinh",
		"B�o v�i GM gi�p nh�.",
		}
	local aHeo = GetLevelItem(GetIndexTrembleItem(0))
	local aSky = GetIndexTrembleItem(0)
	local aHeo1 = GetIndexTrembleItem(1)
	local aHeo2 = GetIndexTrembleItem(2)
	local aHeo3 = GetIndexTrembleItem(3)
	local aHeo4 = GetIndexTrembleItem(4)
	local aHeo5 = GetIndexTrembleItem(5)
	local aHeo6 = GetIndexTrembleItem(6)
	local aHeo7 = GetIndexTrembleItem(7)
	if (aHeo <= 4) then
		eHeo = random(1,8)
		eHeo1 = random(4,8)
	elseif (aHeo == 5) then
		eHeo = random(1,10)
		eHeo1 = random(4,8)
	elseif (aHeo == 6) then
		eHeo = random(1,14)
		eHeo1 = random(5,8)
	elseif (aHeo == 7) then
		eHeo = random(1,21)
		eHeo1 = random(5,9)
	elseif (aHeo == 8) then
		eHeo = random(1,28)
		eHeo1 = random(6,9)
	elseif (aHeo == 9) then
		eHeo = random(1,50)
		eHeo1 = random(7,9)
	elseif (aHeo == 10) then
		eHeo1 = random(8,10)
		eHeo = random(1,70)
	end	
	if (aHeo1 > 0) then
		if (aHeo2 == 0) and (aHeo3 == 0) and (aHeo4 == 0) and (aHeo5 == 0) and (aHeo6 == 0) and (aHeo7 == 0) then 
			if (aHeo < 10) then
				if (eHeo <= 7) then
					SetLevelItem(aSky, aHeo + 1)
					DelItem(aHeo1)
					Msg2Player(TAB_TREMBLEITEM[1])
					return
				else
					DelItem(aHeo1)
					Msg2Player(TAB_TREMBLEITEM[2])
					return
				end
			else
				Talk(1,"no","<color=green>Th� R�n:<color> V�t ph�m �� ��t c�p 10 kh�ng th� n�ng c�p th�m")
				return
			end
		else
			Talk(1,"no",TAB_TREMBLEITEM[3])
			return
		end
	elseif (aHeo2 > 0) then
		if (aHeo1 == 0) and (aHeo3 == 0) and (aHeo4 == 0) and (aHeo5 == 0) and (aHeo6 == 0) and (aHeo7 == 0) then 
			if (eHeo <= 7) then
				ChangeSpiritItem(aSky, eHeo1)
				DelItem(aHeo2)
				Msg2Player(TAB_TREMBLEITEM[1])
				return
			else
				DelItem(aHeo2)
				Msg2Player(TAB_TREMBLEITEM[2])
				return
			end
		else
			Talk(1,"no",TAB_TREMBLEITEM[3])
			return
		end
	elseif (aHeo3 > 0) then
		if (aHeo2 == 0) and (aHeo1 == 0) then 
			if (eHeo <= 7) then
				SetSeriesItem(aSky, 0)
				DelItem(aHeo3)
				Msg2Player(TAB_TREMBLEITEM[1])
				return
			else
				DelItem(aHeo3)
				Msg2Player(TAB_TREMBLEITEM[2])
				return
			end
		else
			Talk(1,"no",TAB_TREMBLEITEM[3])
			return
		end
	elseif (aHeo4 > 0) then
		if (aHeo2 == 0) and (aHeo1 == 0) then 
			if (eHeo <= 7) then
				SetSeriesItem(aSky, 1)
				DelItem(aHeo4)
				Msg2Player(TAB_TREMBLEITEM[1])
				return
			else
				DelItem(aHeo4)
				Msg2Player(TAB_TREMBLEITEM[2])
				return
			end
		else
			Talk(1,"no",TAB_TREMBLEITEM[3])
			return
		end
	elseif (aHeo5 > 0) then
		if (aHeo2 == 0) and (aHeo1 == 0) then 
			if (eHeo <= 7) then
				SetSeriesItem(aSky, 2)
				DelItem(aHeo5)
				Msg2Player(TAB_TREMBLEITEM[1])
				return
			else
				DelItem(aHeo5)
				Msg2Player(TAB_TREMBLEITEM[2])
				return
			end
		else
			Talk(1,"no",TAB_TREMBLEITEM[3])
			return
		end
	elseif (aHeo6 > 0) then
		if (aHeo2 == 0) and (aHeo1 == 0) then 
			if (eHeo <= 7) then
				SetSeriesItem(aSky, 3)
				DelItem(aHeo6)
				Msg2Player(TAB_TREMBLEITEM[1])
				return
			else
				DelItem(aHeo6)
				Msg2Player(TAB_TREMBLEITEM[2])
				return
			end
		else
			Talk(1,"no",TAB_TREMBLEITEM[3])
			return
		end
	elseif (aHeo7 > 0) then
		if (aHeo2 == 0) and (aHeo1 == 0) then 
			if (eHeo <= 7) then
				SetSeriesItem(aSky, 4)
				DelItem(aHeo7)
				Msg2Player(TAB_TREMBLEITEM[1])
				return
			else
				DelItem(aHeo7)
				Msg2Player(TAB_TREMBLEITEM[2])
				return
			end
		else
			Talk(1,"no",TAB_TREMBLEITEM[3])
			return
		end
	else
		Talk(1,"no",TAB_TREMBLEITEM[4])
		return
	end
end