--Author: lzlsky301
--Date: 07/11/12
-- Script Uy Thac
Include("\\script\\global\\sourceatn.lua")
Include("\\script\\global\\tasklist.lua")
Include("\\script\\item\\51.lua")

function main()
	--dofile("script/special/offline.lua")
	utoffline()
end

function utoffline()
if GetTask(TaskUyThacOffline) == 0 then
	SayImg("<color=red>H� Th�ng<color>: th�i gian B�ch C�u Ho�n c�a b�n c�n <color=red><color=blue>"..giobch().."<color> gi� <color=blue>"..phutbch().."<color> ph�t<color>.",3,11,
		"B�t ��u �y th�c r�i m�ng/startut",
		"S� d�ng B�ch C�u Ho�n/sudungbch",
		"Tho�t/no")
else
	Talk(1,"","Ng��i �� k�ch ho�t �y th�c, h�y mau tho�t nh�n v�t.")
end
end

function no()
end

function giobch()
if GetTask(TaskBCH) < 60 then
return 0
else
gio = floor((GetTask(TaskBCH)/60),2)
return gio
end
end

function phutbch()
if GetTask(TaskBCH) < 60 then
return GetTask(TaskBCH)
else
gio = floor((GetTask(TaskBCH)/60),2)
phut = GetTask(TaskBCH) - gio*60
return phut
end
end

function startut()
if GetTask(TaskBCH) >= 1 then
ngay = tonumber(date("%d"))
thang = tonumber(date("%m"))
nam = tonumber(date("%y"))
gio = tonumber(date("%H"))
phut = tonumber(date("%M"))
SetTask(TaskUyThacOffline2,thang)
trunggian = (ngay*24*60) + (gio*60) + phut
SetTask(TaskUyThacOffline,trunggian)
Msg2Player("B�n �� �y th�c v�o l�c: "..gio.." gi� "..phut.." ph�t, ng�y "..ngay.."/"..thang.."/"..nam..", b�y gi� b�n c� th� r�i m�ng.")
else
Talk(1,"","B�n �� h�t <color=red>B�ch C�u Ho�n<color>, vui l�ng ki�m tra v� quay l�i sau.")
end
end

function stoput()
ngay = tonumber(date("%d"))
thang = tonumber(date("%m"))
gio = tonumber(date("%H"))
phut = tonumber(date("%M"))
songay = {31,28,31,30,31,30,31,31,30,31,30,31}
if thang == GetTask(TaskUyThacOffline2) then
	hientai = (ngay*24*60) + (gio*60) + phut
	sophutdaut = (hientai - GetTask(TaskUyThacOffline))
	if GetTask(TaskBCH) >= sophutdaut then
	SetTask(TaskUyThacOffline1,GetTask(TaskUyThacOffline1)+sophutdaut)
	SetTask(TaskUyThacOffline,0)
	SetTask(TaskBCH,GetTask(TaskBCH)-sophutdaut)
	else
	SetTask(TaskUyThacOffline1,GetTask(TaskUyThacOffline1)+GetTask(TaskBCH))
	SetTask(TaskUyThacOffline,0)
	SetTask(TaskBCH,0)
	end
elseif (thang == (GetTask(TaskUyThacOffline2)+1)) or (thang == (GetTask(TaskUyThacOffline2)-11)) then
	thangtruoc = (songay[thang]*24*60) - GetTask(TaskUyThacOffline)
	thangnay = (ngay*24*60) + (gio*60) + phut
	hientai = thangnay + thangtruoc
	if GetTask(TaskBCH) >= hientai then
	SetTask(TaskUyThacOffline1,GetTask(TaskUyThacOffline1)+hientai)
	SetTask(TaskUyThacOffline,0)
	SetTask(TaskBCH,GetTask(TaskBCH)-hientai)
	else
	SetTask(TaskUyThacOffline1,GetTask(TaskUyThacOffline1)+GetTask(TaskBCH))
	SetTask(TaskUyThacOffline,0)
	SetTask(TaskBCH,0)
	end
else
	SetTask(TaskUyThacOffline,0)
	SetTask(TaskUyThacOffline1,0)
	Talk(1,"","V� l� do b�n kh�ng v�o game h�n <color=yellow>1 th�ng<color> n�n kinh nghi�m t�ch l�y ���c tr� v� 0.")
end
end

function expuythac()
if (GetLevel() > 70) and (GetLevel() <= 90) then
return 2000
elseif (GetLevel() > 90) and (GetLevel() <= 110) then
return 40000
elseif (GetLevel() > 110) and (GetLevel() <= 130) then
return 40000
elseif (GetLevel() > 130) and (GetLevel() <= 150) then
return 40000
elseif (GetLevel() > 150) and (GetLevel() <= 170) then
return 40000
elseif (GetLevel() > 170) and (GetLevel() <= 190) then
return 40000
elseif (GetLevel() > 190) and (GetLevel() <= 195) then
return 40000
elseif (GetLevel() > 195) and (GetLevel() <= 200) then
return 40000
end
end

function nhanexputoff()
soexpnd = expuythac()*GetTask(TaskUyThacOffline1)
	if GetTask(TaskUyThacOffline1) >= 15 then
	AddOwnExp(soexpnd)
	SetTask(TaskUyThacOffline1,0)
	else
	Talk(1,"","Th�i gian �y th�c tr�n <color=red>15 ph�t<color> m�i ���c nh�n kinh nghi�m.")
	end
end
