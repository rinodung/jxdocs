--Author: lzlsky301
--Date: 07/11/12
Include("\\script\\header\\taskid.lua");
Include("\\script\\library\\worldlibrary.lua");

function ForgeItem()		-- Che tao trang bi huyen tinh
	local TAB_FORGE = 
		{	"Ch� t�o trang b� huy�n tinh th�nh c�ng. Xin ch�c m�ng!",
			"Ch� t�o trang b� huy�n tinh th�t b�i. Xin chia bu�n!",
		}
	local aSky1 = GetIndexForgeItem(0)
	local aSky2 = GetIndexForgeItem(1)
	local aSky3 = GetDetailItem(aSky2)
	if (aSky3 == 4) then
		aHeo = random(1,3)
	elseif (aSky3 == 5) then
		aHeo = random(2,4)
	elseif (aSky3 >= 6) and (aSky3 <= 13) then
		local eHeo = random(1,100)
		if (eHeo == 1) then
			aHeo = 6
		elseif (eHeo > 1) and (eHeo < 6) then
			aHeo = 6
		else
			aHeo = 6
		end
	end
	local eHeo1 = random(1,8)
	if eHeo1 > 1 then
		SetPurpleItem(aSky1, aHeo)
		RemoveItem(aSky2)
		Msg2Player(TAB_FORGE[1])
		Pay(10000)
		return
	else
		RemoveItem(aSky2)
		RemoveItem(aSky1)
		Msg2Player(TAB_FORGE[2])
		Pay(10000)
		return
	end
end

