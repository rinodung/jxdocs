--Author: lzlsky301
--Date: 07/11/12
Include("\\script\\header\\taskid.lua");
Include("\\script\\library\\worldlibrary.lua");

function EnchaseItem()		-- Kham thuoc tinh trang bi
	local TAB_ENCHASE = 
		{	"Kham n�m thu�c t�nh th�nh c�ng. Xin ch�c m�ng!",
			"Kham n�m t�nh th�t b�i. Xin chia bu�n!",
		}
	local aSky1 = GetIndexEnchaseItem(0)
	local aSky2 = GetIndexEnchaseItem(1)
	local aSky3 = GetIndexEnchaseItem(2)
	local aSky4 = GetIndexEnchaseItem(3)
	local aSky5 = GetIndexEnchaseItem(4)
	local aSky6 = GetIndexEnchaseItem(5)
	local aSky7 = GetIndexEnchaseItem(6)
	local aSky8 = GetIndexEnchaseItem(7)
	local aSky9 = GetIndexEnchaseItem(8)
	local aSky10 = GetIndexEnchaseItem(9)
	local aSky11 = GetIndexEnchaseItem(10)
	local eHeo2 = GetDetailItem(aSky2)
	local eHeo3 = GetDetailItem(aSky3)
	local eHeo4 = GetDetailItem(aSky4)
	local eHeo5 = GetDetailItem(aSky5)
	local eHeo6 = GetDetailItem(aSky6)
	local eHeo7 = GetDetailItem(aSky7)
	local eHeo8 = GetDetailItem(aSky8)
	local eHeo9 = GetDetailItem(aSky9)
	local eHeo10 = GetDetailItem(aSky10)
	local eHeo11 = GetDetailItem(aSky11)
	local emHeo1 = GetOp1Item(aSky3)
	local emHeo = GetLevelItem(aSky3)
	local TAB_OPTION = {{1,4,1,10},{2,5,5,15},{3,6,10,20},{4,7,15,25},{5,8,20,35},{6,9,25,45},{7,10,30,50},{8,11,35,55},{9,12,40,60},{10,13,45,65}}
	local TAB_OPTION2 = {{1,4,5,15},{2,5,10,20},{3,6,15,25},{4,7,20,30},{5,8,25,45},{6,9,30,55},{7,10,35,65},{8,11,40,75},{9,12,45,85},{10,13,50,95}}
	local TAB_OPTION1 = {{1,14,5,9,10,11,12,6,7,8},{2,15,4,5,6,8,9,5,10,6},{3,16,6,7,7,8,10,9,5,6},{4,31,6,4,4,3,5,4,3,3},{5,32,4,5,6,7,3,6,6,4},{6,33,4,8,4,5,6,5,7,6}}
	for i=1,getn(TAB_OPTION) do
		if (eHeo2 == TAB_OPTION[i][2]) then
			iHeo0 = random(TAB_OPTION[i][3],TAB_OPTION[i][4])
		end
	end
	for i=1,getn(TAB_OPTION2) do
		if (emHeo == TAB_OPTION2[i][1]) then
			iHeo9 = TAB_OPTION2[i][4]
		end
	end
	for i=1,getn(TAB_OPTION1) do
		if (eHeo4 == TAB_OPTION1[i][2]) then
			iHeo1 = TAB_OPTION1[i][1]
		elseif (aSky4 == 0) then
			iHeo1 = 0
		end
	end
	for i=1,getn(TAB_OPTION1) do
		if (eHeo5 == TAB_OPTION1[i][2]) then
			iHeo2 = TAB_OPTION1[i][2]
		elseif (aSky5 == 0) then
			iHeo2 = 0
		end
	end
	for i=1,getn(TAB_OPTION1) do
		if (eHeo6 == TAB_OPTION1[i][2]) then
			iHeo3 = TAB_OPTION1[i][3]
		elseif (aSky6 == 0) then
			iHeo3 = 0
		end
	end
	for i=1,getn(TAB_OPTION1) do
		if (eHeo7 == TAB_OPTION1[i][2]) then
			iHeo4 = TAB_OPTION1[i][4]
		elseif (aSky7 == 0) then
			iHeo4 = 0
		end
	end
	for i=1,getn(TAB_OPTION1) do
		if (eHeo8 == TAB_OPTION1[i][2]) then
			iHeo5 = TAB_OPTION1[i][5]
		elseif (aSky8 == 0) then
			iHeo5 = 0
		end
	end
	for i=1,getn(TAB_OPTION1) do
		if (eHeo9 == TAB_OPTION1[i][2]) then
			iHeo6 = TAB_OPTION1[i][6]
		elseif (aSky9 == 0) then
			iHeo6 = 0
		end
	end
	for i=1,getn(TAB_OPTION1) do
		if (eHeo10 == TAB_OPTION1[i][2]) then
			iHeo7 = TAB_OPTION1[i][7]
		elseif (aSky10 == 0) then
			iHeo7 = 0
		end
	end
	for i=1,getn(TAB_OPTION1) do
		if (eHeo11 == TAB_OPTION1[i][2]) then
			iHeo8 = TAB_OPTION1[i][8]
		elseif (aSky11 == 0) then
			iHeo8 = 0
		end
	end
	local aTuong = (iHeo0 + iHeo1 + iHeo2 + iHeo3 + iHeo4 + iHeo5 + iHeo6 + iHeo7 + iHeo8 + iHeo9)
	local TAB_LUCK = {{10},{20},{30},{40},{50},{60},{70},{80},{90},{95},{100},{105},{111},{115},{121},{126},{131},{136},{141},{146}}
	if (aTuong == 55) or (aTuong == 77) or (aTuong == 99) or (aTuong == 111) then
		aHang = random(28,30)
	elseif (aTuong < TAB_LUCK[1][1]) then
		aHang = 11
	elseif (aTuong < TAB_LUCK[2][1]) then
		aHang = 12
	elseif (aTuong < TAB_LUCK[3][1]) then
		aHang = 13
	elseif (aTuong < TAB_LUCK[4][1]) then
		aHang = 14
	elseif (aTuong < TAB_LUCK[5][1]) then
		aHang = 15
	elseif (aTuong < TAB_LUCK[6][1]) then
		aHang = 16
	elseif (aTuong < TAB_LUCK[7][1]) then
		aHang = 17
	elseif (aTuong < TAB_LUCK[8][1]) then
		aHang = 18
	elseif (aTuong < TAB_LUCK[9][1]) then
		aHang = 19
	elseif (aTuong < TAB_LUCK[10][1]) then
		aHang = 20
	elseif (aTuong < TAB_LUCK[11][1]) then
		aHang = 21
	elseif (aTuong < TAB_LUCK[12][1]) then
		aHang = 22
	elseif (aTuong < TAB_LUCK[13][1]) then
		aHang = 23
	elseif (aTuong < TAB_LUCK[14][1]) then
		aHang = 24
	elseif (aTuong < TAB_LUCK[15][1]) then
		aHang = 25
	elseif (aTuong < TAB_LUCK[16][1]) then
		aHang = 26
	elseif (aTuong < TAB_LUCK[17][1]) then
		aHang = 27
	elseif (aTuong < TAB_LUCK[18][1]) then
		aHang = 28
	elseif (aTuong < TAB_LUCK[19][1]) then
		aHang = 29
	elseif (aTuong >= TAB_LUCK[19][1]) then
		aHang = 30
	end
	if (eHeo3 == 0) then
		eHeo = 0
	elseif (eHeo3 == 1) then
		eHeo = 2
	elseif (eHeo3 == 2) then
		eHeo = 4
	elseif (eHeo3 >= 3) and (eHeo3 <= 7) then
		eHeo = 1
	elseif (eHeo3 >= 8) and (eHeo3 <= 12) then
		eHeo = 3
	elseif (eHeo3 >= 13) and (eHeo3 <= 17) then
		eHeo = 5
	end
	local nA = random(1,100)
	if nA > 1 then
		SetMagic2Equip(aSky1, emHeo1, eHeo, aHang)
		RemoveItem(aSky2)
		RemoveItem(aSky3)
		for i=3,10 do RemoveItem(GetIndexEnchaseItem(i)) end
		Msg2Player(TAB_ENCHASE[1])
	else
		RemoveItem(aSky2)
		RemoveItem(aSky3)
		for i=3,10 do RemoveItem(GetIndexEnchaseItem(i)) end
		Msg2Player(TAB_ENCHASE[2])
	end		
end

