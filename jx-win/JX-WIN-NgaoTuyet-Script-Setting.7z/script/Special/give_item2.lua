---------------------------------------------
--Author: lzlsky301
-- Script Tra vat pham Hoang Kim
---------------------------------------------
Include("\\script\\global\\sourceatn.lua")
Include("\\script\\global\\tasklist.lua")

function main()
	-- dofile("script/special/give_item2.lua")
	give_item2()
end

function give_item2()
	local TAB_GIVEITEM = {
				"<color=green>Long Ng� <color>: Ch�c M�ng ! B�n �� ho�n th�nh nhi�m v� !",
				"<color=green>Long Ng� <color>: Ra ngo�i ti�u di�t 200 con qu�i r�i quay l�i g�p ta !!!",
				"<color=water>Nhi�m V� Long Ng�:<color> <color=green>Long Ng� <color>: Ra ngo�i ti�u di�t 200 con qu�i r�i quay l�i g�p ta !!!",
				"<color=green>Long Ng� <color>: B�n mang ��n kh�ng ��ng v�t ph�m ",
				"Nhi�m V�: T�m Ng�o V�n T�ng ....",
				"<color=green>Ph� Nam B�ng<color>: T�m Ng�o V�n T�ng �� ph�c m�nh . ",
				"<color=water>Nhi�m V� Trung L�p:<color> <color=green>Ph� Nam B�ng<color>: T�m Ng�o V�n T�ng �� ph�c m�nh . ",
				"<color=green>Ph� Nam B�ng<color>: B�n ch�a ��t v�t ph�m ho�c v�t ph�m kh�ng ��ng",
				"<color=green>Ph� Nam B�ng<color>: T�m Bao Ki�m c� th� ��nh nh�m ch�a �� c� ",
				"<color=green>V�n Nhi:<color> H�y t�m Ng�o V�n T�ng ph�c m�nh �i. ",
				"Nhi�m Vu: t�m Ng�o V�n T�ng �� nh�n nhi�m v� ",
				"<color=pink>Nhi�m V� T� Ph�i:<color> <color=green>V�n Nhi:<color> t�m Ng�o V�n T�ng �� nh�n nhi�m v�.!  ",
				}
	if GetTask(T_NVuHoangKim) >= 1 then 
		a = GetGenreItem(GetIndexGiveItem(nIndex))
		b = GetDetailItem(GetIndexGiveItem(nIndex))
		if GetTask(T_NVuHoangKim) == 2 then
			if a == 4 and b == 115 then
				DelItem(GetIndexGiveItem(nIndex))
				SetTask(T_NVuHoangKim,3)
				Talk(2,"",TAB_GIVEITEM[1],TAB_GIVEITEM[2])
				AddNote(TAB_GIVEITEM[3])
				return
			else
				Talk(1,"",TAB_GIVEITEM[4])
			end
		elseif GetTask(T_NVuHoangKim) == 13 then
			if a == 4 and b == 119 then
				DelItem(GetIndexGiveItem(nIndex))
				SetTask(T_NVuHoangKim,14)
				SetTask(T_TienDoNVHK,0)
				SetTask(T_VatPhamNVHK,0)
				Msg2Player(TAB_GIVEITEM[5])
				Talk(1,"",TAB_GIVEITEM[6])
				AddNote(TAB_GIVEITEM[7])
				return
			else
				Talk(2,"",TAB_GIVEITEM[8],TAB_GIVEITEM[9])
			end
		elseif GetTask(T_NVuHoangKim) == 19 then
			if a == 4 and b == 121 then
			DelItem(GetIndexGiveItem(nIndex))
			SetTask(T_NVuHoangKim,20)
			Talk(1,"",TAB_GIVEITEM[10])
			Msg2Player(TAB_GIVEITEM[11])
			AddNote(TAB_GIVEITEM[12])
			return
			else
				Talk(1,"",TAB_GIVEITEM[8])
			end
		else
			Talk(1,"",TAB_GIVEITEM[10])
			Msg2Player(TAB_GIVEITEM[11])
			AddNote(TAB_GIVEITEM[12])
			return
		end
	end
end
	

