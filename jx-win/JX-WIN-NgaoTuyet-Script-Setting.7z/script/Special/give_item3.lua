---------------------------------------------
--Author: lzlsky301
-- Script Tra vat pham Chung
---------------------------------------------
Include("\\script\\global\\sourceatn.lua")
Include("\\script\\global\\tasklist.lua")

function main()
	-- dofile("script/special/give_item3.lua")
	give_item3()
end

function give_item3()
	Talk(1,"no","Script 3")
end
	