--Author: lzlsky301
--Date: 07/11/12
Include("\\script\\global\\sourceatn.lua")
Include("\\script\\global\\tasklist.lua")

function main()
	-- dofile("script/special/checkadmin.lua")
	checkadmin()
end

function checkadmin()
	local nPassword = GetStringFromUI() 
	if(nPassword == "111111") then
		SetTaskTemp(1000,1)
		Msg2Player("��ng m�t kh�u!")
	else
		Msg2Player("Sai m�t kh�u!")
		KickOutSelf()
	end
end
	

