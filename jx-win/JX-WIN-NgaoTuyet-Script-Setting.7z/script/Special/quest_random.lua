--Author: lzlsky301
--Date: 07/11/12
Include("\\script\\Special\\quest_money.lua")
Include("\\script\\Special\\quest_lucky.lua")
Include("\\script\\Special\\quest_item.lua")
Include("\\script\\Special\\quest_exp.lua")
Include("\\script\\Special\\quest_point.lua")
Include("\\script\\global\\sourceatn.lua")
Include("\\script\\global\\tasklist.lua")
function main()
-- dofile("script/special/quest_random.lua")
quest_random()
end

function quest_random()
	b = random(1,1000)
	if b == 1 then
		finish_item()
		return
	elseif b <= 400 then
		finish_exp()
		return
	elseif b <= 600 then
		finish_money()
		return
	elseif b <= 800 then
		finish_point()
		return
	else
		finish_lucky()
		return
	end
end
