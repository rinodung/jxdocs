--Author: lzlsky301
--Date: 07/11/12
Include("\\script\\header\\taskid.lua");
Include("\\script\\library\\worldlibrary.lua");
function main()
-- dofile("script/special/compound_item.lua")
end
function CompOneItem()		-- Tinh luyen huyen tinh
	local TAB_COMPONE = 
		{	"Tinh luy�n huy�n tinh th�nh c�ng. Xin ch�c m�ng!",
			"Tinh luy�n huy�n tinh th�t b�i. Xin chia bu�n!",
			"B�o v�i GM c�i nh�. ",
			"B�n kh�ng mang �� ng�n l��ng ",
		}
	local aSky1 = GetIndexCompOneItem(0)
	local aSky2 = GetIndexCompOneItem(1)
	local aSky3 = GetIndexCompOneItem(2)
	local aSky4 = GetLevelItem(aSky1)
	local aSky5 = GetLevelItem(aSky2)
	local aSky6 = GetLevelItem(aSky3)
	local aSky7 = GetCash()
	local aHeo = random(1,10)
	if (aHeo < 9) then
		if (aSky7 >= 5000) then
			Pay(5000)
			if (GetCash() == (aSky7 - 5000)) then
				if (aSky4 >= 5) or (aSky5 >= 5) or (aSky6 >= 5) then
					AddEventItem(random(4,6))
					RemoveItem(aSky1)
					RemoveItem(aSky2)
					RemoveItem(aSky3)
					Msg2Player(TAB_COMPONE[1])
					return
				else
					AddEventItem(random(4,5))
					RemoveItem(aSky1)
					RemoveItem(aSky2)
					RemoveItem(aSky3)
					Msg2Player(TAB_COMPONE[1])
					return
				end
			else
				Msg2Player(TAB_COMPONE[3])
				return
			end
		else
			Msg2Player(TAB_COMPONE[4])
			return
		end
	else
		if (aHeo <= 3) then
			Pay(5000)
			RemoveItem(aSky1)
			Msg2Player(TAB_COMPONE[2])
			return
		elseif (aHeo <= 6) then
			Pay(5000)
			RemoveItem(aSky2)
			Msg2Player(TAB_COMPONE[2])
			return
		elseif (aHeo <= 9) then
			Pay(5000)
			RemoveItem(aSky3)
			Msg2Player(TAB_COMPONE[2])
			return
		end
	end
end

function CompTwoItem()		-- Nang cap huyen tinh
	local TAB_COMPTWO = 
		{	"N�ng c�p huy�n tinh th�nh c�ng. Xin ch�c m�ng!",
			"N�ng c�p huy�n tinh th�t b�i. Xin chia bu�n!",
			"B�n mang ng�n l��ng kh�ng �� ",
			"B�o v�i GM c�i nh� ",
		}
	local aSky1 = GetIndexCompTwoItem(0)
	local aSky2 = GetIndexCompTwoItem(1)
	local aSky3 = GetIndexCompTwoItem(2)
	local aSky4 = GetDetailItem(aSky1)
	local aSky6 = GetCash()
	if (aSky4 == 4) then
		eHeo = random(1,10)
	elseif (aSky4 == 5) then
		eHeo = random(1,20)
	elseif (aSky4 == 6) then
		eHeo = random(1,30)
	elseif (aSky4 == 7) then
		eHeo = random(1,40)
	elseif (aSky4 == 8) then
		eHeo = random(1,50)
	elseif (aSky4 == 9) then
		eHeo = random(1,60)
	elseif (aSky4 == 10) then
		eHeo = random(1,70)
	elseif (aSky4 == 11) then
		eHeo = random(1,80)
	elseif (aSky4 == 12) then
		eHeo = random(1,90)
	end
	if (aSky6 >= 5000) then
		Pay(5000)
		if (GetCash() == (aSky6 - 5000)) then
			if (eHeo <= 5) then
				AddEventItem(aSky4 + 1)
				RemoveItem(aSky1)
				RemoveItem(aSky2)
				RemoveItem(aSky3)
				Msg2Player(TAB_COMPTWO[1])
			else
				RemoveItem(aSky1)
				Msg2Player(TAB_COMPTWO[2])
				return
			end
		else
			Msg2Player(TAB_COMPTWO[4])
			return
		end
	else
		Msg2Player(TAB_COMPTWO[3])
		return
	end
end

function CompThreeItem()	-- Nang cap khoang thach
	local TAB_COMPTHREE = 
		{	"N�ng c�p th�nh c�ng. Xin ch�c m�ng!",
			"N�ng c�p th�t b�i. Xin chia bu�n!",
		}
	local aSky1 = GetIndexCompThreeItem(0)
	local aSky2 = GetIndexCompThreeItem(1)
	local aSky3 = GetIndexCompThreeItem(2)
	local aSky4 = GetLevelItem(aSky1)
	if (aSky4 == 1) then
		eHeo = random(1,15)
	elseif (aSky4 == 2) then
		eHeo = random(1,15)
	elseif (aSky4 == 3) then
		eHeo = random(1,15)
	elseif (aSky4 == 4) then
		eHeo = random(1,20)
	elseif (aSky4 == 5) then
		eHeo = random(1,20)
	elseif (aSky4 == 6) then
		eHeo = random(1,25)
	elseif (aSky4 == 7) then
		eHeo = random(1,30)
	elseif (aSky4 == 8) then
		eHeo = random(1,35)
	elseif (aSky4 == 9) then
		eHeo = random(1,40)
	end
	Pay(5000)
	if (eHeo <= 10) then
		SetLevelItem(aSky1, aSky4 + 1)
		RemoveItem(aSky2)
		RemoveItem(aSky3)
		Msg2Player(TAB_COMPTHREE[1])
	else
		RemoveItem(aSky1)
		Msg2Player(TAB_COMPTHREE[2])
	end
end

