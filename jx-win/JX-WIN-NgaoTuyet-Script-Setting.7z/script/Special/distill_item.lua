--Author: lzlsky301
--Date: 07/11/12
Include("\\script\\header\\taskid.lua");
Include("\\script\\library\\worldlibrary.lua");

function DistillItem()		-- Hut thuoc tinh trang bi
	local TAB_DISTILL = 
		{	"H�t thu�c t�nh th�nh c�ng. Xin ch�c m�ng!",
			"H�t thu�c t�nh th�t b�i. Xin chia bu�n!",
		}
	local aSky1 = GetIndexDistillItem(0)
	local aSky2 = GetIndexDistillItem(1)
	local aSky3 = GetIndexDistillItem(2)
	local aSky4 = GetIndexDistillItem(3)
	local aSky5 = GetIndexDistillItem(4)
	local aSky6 = GetIndexDistillItem(5)
	local aSky7 = GetIndexDistillItem(6)
	local aSky8 = GetIndexDistillItem(7)
	local aSky9 = GetIndexDistillItem(8)
	local aSky10 = GetIndexDistillItem(9)
	local aSky11 = GetIndexDistillItem(10)
	local aHeo = GetDetailItem(aSky3)
	local aHeo0 = GetDetailItem(aSky2)
	local aHeo1 = GetOp1Item(aSky1)
	local aHeo2 = GetOp2Item(aSky1)
	local aHeo3 = GetOp3Item(aSky1)
	local aHeo4 = GetOp4Item(aSky1)
	local aHeo5 = GetOp5Item(aSky1)
	local aHeo6 = GetOp6Item(aSky1)
	local iHeo1 = GetDetailItem(aSky4)
	local iHeo2 = GetDetailItem(aSky5)
	local iHeo3 = GetDetailItem(aSky6)
	local iHeo4 = GetDetailItem(aSky7)
	local iHeo5 = GetDetailItem(aSky8)
	local iHeo6 = GetDetailItem(aSky9)
	local iHeo7 = GetDetailItem(aSky10)
	local iHeo8 = GetDetailItem(aSky11)
	local TAB_OPTION = {{1,4,4,10},{2,5,7,14},{3,6,10,20},{4,7,15,25},{5,8,19,29},{6,9,24,34},{7,10,29,39},{8,11,34,44},{9,12,39,49},{10,13,44,54}}
	local TAB_OPTION1 = {{1,14,3,4,5,6,7,8,4,8},{2,15,4,2,1,5,6,5,6,7},{3,16,2,5,1,3,6,7,6,4},{4,31,1,2,2,3,1,2,3,3},{5,32,1,2,2,3,3,4,1,4},{6,33,1,2,2,3,1,5,3,4}}
	for i=1,getn(TAB_OPTION) do
		if (aHeo0 == TAB_OPTION[i][2]) then
			eHeo0 = random(TAB_OPTION[i][3],TAB_OPTION[i][4])
		elseif (aSky2 == 0) then
			eHeo0 = 0
		end
	end
	for i=1,getn(TAB_OPTION1) do 
		if (iHeo1 == TAB_OPTION1[i][2]) then
			eHeo1 = TAB_OPTION1[i][10]
		elseif (aSky4 == 0) then
			eHeo1 = 0
		end
	end
	for i=1,getn(TAB_OPTION1) do 
		if (iHeo2 == TAB_OPTION1[i][2]) then
			eHeo2 = TAB_OPTION1[i][8]
		elseif (aSky5 == 0) then
			eHeo2 = 0
		end
	end
	for i=1,getn(TAB_OPTION1) do 
		if (iHeo3 == TAB_OPTION1[i][2]) then
			eHeo3 = TAB_OPTION1[i][9]
		elseif (aSky6 == 0) then
			eHeo3 = 0
		end
	end
	for i=1,getn(TAB_OPTION1) do 
		if (iHeo4 == TAB_OPTION1[i][2]) then
			eHeo4 = TAB_OPTION1[i][5]
		elseif (aSky7 == 0) then
			eHeo4 = 0
		end
	end
	for i=1,getn(TAB_OPTION1) do 
		if (iHeo5 == TAB_OPTION1[i][2]) then
			eHeo5 = TAB_OPTION1[i][6]
		elseif (aSky8 == 0) then
			eHeo5 = 0
		end
	end
	for i=1,getn(TAB_OPTION1) do 
		if (iHeo6 == TAB_OPTION1[i][2]) then
			eHeo6 = TAB_OPTION1[i][4]
		elseif (aSky9 == 0) then
			eHeo6 = 0
		end
	end
	for i=1,getn(TAB_OPTION1) do 
		if (iHeo7 == TAB_OPTION1[i][2]) then
			eHeo7 = TAB_OPTION1[i][7]
		elseif (aSky10 == 0) then
			eHeo7 = 0
		end
	end
	for i=1,getn(TAB_OPTION1) do 
		if (iHeo8 == TAB_OPTION1[i][2]) then
			eHeo8 = TAB_OPTION1[i][5]
		elseif (aSky11 == 0) then
			eHeo8 = 0
		end
	end
	eHeo = floor((eHeo0 + eHeo1 + eHeo2 + eHeo3 + eHeo4 + eHeo5 + eHeo6 + eHeo7 + eHeo8 + 10)/10)
	if (eHeo >= 10) then
		eHeo = 10
	end
	Pay(5000)
	if (aHeo == 0) then
		SetMagic2Mine(aSky3,aHeo1,eHeo)
		RemoveItem(aSky1)
		RemoveItem(aSky2)
		for i=3,10 do RemoveItem(GetIndexDistillItem(i)) end
		Msg2Player(TAB_DISTILL[1])
	elseif (aHeo == 1) then
		SetMagic2Mine(aSky3,aHeo3,eHeo)
		RemoveItem(aSky1)
		RemoveItem(aSky2)
		for i=3,10 do RemoveItem(GetIndexDistillItem(i)) end
		Msg2Player(TAB_DISTILL[1])
	elseif (aHeo == 2) then
		SetMagic2Mine(aSky3,aHeo5,eHeo)
		RemoveItem(aSky1)
		RemoveItem(aSky2)
		for i=3,10 do RemoveItem(GetIndexDistillItem(i)) end
		Msg2Player(TAB_DISTILL[1])
	elseif (aHeo >= 3) and (aHeo <= 7) then
		SetMagic2Mine(aSky3,aHeo2,eHeo)
		RemoveItem(aSky1)
		RemoveItem(aSky2)
		for i=3,10 do RemoveItem(GetIndexDistillItem(i)) end
		Msg2Player(TAB_DISTILL[1])
	elseif (aHeo >= 8) and (aHeo <= 12) then
		SetMagic2Mine(aSky3,aHeo4,eHeo)
		RemoveItem(aSky1)
		RemoveItem(aSky2)
		for i=3,10 do RemoveItem(GetIndexDistillItem(i)) end
		Msg2Player(TAB_DISTILL[1])
	elseif (aHeo >= 13) and (aHeo <= 17) then
		SetMagic2Mine(aSky3,aHeo6,eHeo)
		RemoveItem(aSky1)
		RemoveItem(aSky2)
		for i=3,10 do RemoveItem(GetIndexDistillItem(i)) end
		Msg2Player(TAB_DISTILL[1])
	end
end

