Include("\\script\\global\\tasklist.lua");
Include("\\script\\global\\serverlib.lua")
Include("\\script\\global\\map_helper.lua")

function system(nPassword)
dofile("script/system/system.lua")
TabSystem = {
"Xem th�ng tin ng��i ch�i/show_info#1",
"Xem th�ng th�ng tin nh�m ng��i ch�i/show_info#2",
"Th�ng b�o t�n s� h� th�ng/show_info#3",
"Th�ng b�o tr�n newmessage/show_info#4",
"H�y b�/no",
}
if (nPassword == "gm") then
Say("Ch�o GameMaster c�a <color=Gold>Ki�m Hi�p T�nh Huy�n", getn(TabSystem), TabSystem)
SetTaskTemp(TMT_GameMaster, 1)
else
Talk(1, "shutdownclient", "M� nh�p v�o sai - ShutDown")
end
end

function shutdownclient()
OfflineLive()
end

function show_info(nKind)
if (nKind == 1) then
	OpenStrBox("Nh�p t�n ho�c t�i kho�n", "GetInfoPlayer")
elseif (nKind == 2) then
	OpenStrBox("T� ? ��n ?", "ShowPlayerFrom#0", 1, 1200)
elseif (nKind == 3) then
	OpenStrBox("Th�ng B�o", "MsgSpecial1")
elseif (nKind == 4) then
	OpenStrBox("Th�ng B�o", "MsgSpecial2")
end
end

function GetInfoPlayer(szName)
	local AdminIndex = PlayerIndex
	for i=1,1200 do
		PlayerIndex = i
		if (GetPlayerAccount() == szName or GetPlayerName() == szName) then
			nVictimIndex = i
			szStr = "S� hi�u: "..nVictimIndex.."\nT�n t�i kho�n: "..GetPlayerAccount().."\nT�n nh�n v�t: "..GetPlayerName().."\nB�n ��: "..GetMapName(nW).." - "..floor(nX/8).."/"..floor(nY/16)
			PlayerIndex = AdminIndex
			Say(szStr, 4,
			"Thay ��i t�a �� ng��i ch�i/change_pos#"..nVictimIndex.."",
			"Thay ��i ch� s� ng��i ch�i/change_point#"..nVictimIndex.."",
			"Thay ��i trang b� ng��i ch�i/change_item#"..nVictimIndex.."",
			"Kh�ng thao t�c/no")
			break
		else
			Say("Kh�ng t�m th�y ng��i ch�i", 2,
			"T�m l�i/show_info#1",
			"D�ng t�m ki�m/no")
		end

	end
end

function change_point(nVictimIndex)
Say("", 0)
end

function change_pos(nVictimIndex)
			Say("Ch�n thao t�c th�c hi�n", 5,
			"Di chuy�n v� GameMaster/MoveGM#"..nVictimIndex.."",
			"Di chuy�n v� B�n ��/MoveTown#"..nVictimIndex.."",
			"Di chuy�n v�o Thi�n lao/MoveCell"..nVictimIndex.."",
			"GameMaster �i chuy�n ��n nh�n v�t/GMMove"..nVictimIndex.."",
			"Kh�ng thao t�c/no")
end

function change_item(nVictimIndex)
			Say("Ch�n thao t�c th�c hi�n", 3,
			"Th�m trang b�/additem_victim#"..nVictimIndex.."",
			"Ki�m tra trang b�/change_item_equipment#"..nVictimIndex.."",
			"Kh�ng thao t�c/no")
end

function additem_victim(nVictimIndex)
		Say("Ch�n thao t�c th�c hi�n", 3,
		"An Bang/gold_normal#1#"..nVictimIndex.."",
		"��nh Qu�c/gold_normal#2#"..nVictimIndex.."",
		"Kh�ng thao t�c/no")
end

function gold_normal(nKind, nVictimIndex)
local nMyIndex = PlayerIndex
PlayerIndex = nVictimIndex
		if (nKind == 1) then
		TabItem = {
		"An Bang C�c Hoa Th�ch Ch� Ho�n/gold_normal_add#10#1#1#"..nVictimIndex.."",
		"An Bang Tinh Th�ch H�ng Li�n/gold_normal_add#11#2#1#"..nVictimIndex.."",
		"An Bang �i�m Ho�ng Ng�c B�i/gold_normal_add#12#1#2#"..nVictimIndex.."",
		"An Bang K� Huy�t Th�ch Gi�i Ch�/gold_normal_add#13#1#"..nVictimIndex.."",
		"Kh�ng thao t�c/no",
		}
		else
		TabItem = {
		"��nh Qu�c Thanh Sa Tr��ng Sam/gold_normal_add#22#2#4#"..nVictimIndex.."",
		"��nh Qu�c X�ch Nhuy�n Ngoa/gold_normal_add#23#2#2#"..nVictimIndex.."",
		"��nh Qu�c � Sa Ph�t Qu�n/gold_normal_add#24#2#2#"..nVictimIndex.."",
		"��nh Qu�c Ng�n T�m Y�u ��i/gold_normal_add#25#2#1#"..nVictimIndex.."",
		"��nh Qu�c T� ��ng h� uy�n/gold_normal_add#26#1#2#"..nVictimIndex.."",
		"Kh�ng thao t�c/no",
		}
		end
PlayerIndex = nMyIndex
	Say("", getn(TabItem), TabItem)
end

function gold_normal_add(nId, nWidth, nHeght, nVictimIndex)
local nMyIndex = PlayerIndex
PlayerIndex = nVictimIndex
	if (CheckPostion(nWidth, nHeght) == 1) then
		AddGoldItem(nId)
		szString = "�� th�m trang b� cho "..GetName().." "
	else
		szString = "H�nh trang c�a "..GetName().." kh�ng c� kho�ng tr�ng "..nWidth.."x"..nHeght.." kh�ng th� th�c hi�n"
	end
PlayerIndex = nMyIndex
	Say(szString, 0)
end	
	

function change_item_equipment(nVictimIndex)
tab_InfoItem = {}
local nMyIndex = PlayerIndex
	for i = 1,10 do
	PlayerIndex = nVictimIndex	
	nIndex = GetIdItem(1, i)
	if (nIndex > 0) then
	tab_InfoItem[i] = ""..GetNameItem(nIndex).." - Index "..nIndex.."/thaotac_item#"..nIndex.."#"..nVictimIndex..""
	else
	tab_InfoItem[i] = "Kh�ng c� trang b� � � n�y/no"
	end
	end
	tab_InfoItem[11] = "Kh�ng thao t�c/no"
	local szString = "Ng��i ch�i "..GetPlayerName().." �ang mang nh�ng trang b� sau"
PlayerIndex = nMyIndex
Say(szString, getn(tab_InfoItem), tab_InfoItem)
end

function thaotac_item(nIndex, nVictimIndex)
			Say("Ch�n thao t�c th�c hi�n", 2,
			"X�a b� v�t ph�m n�y/remove_item#"..nIndex.."#"..nVictimIndex.."",
			"Kh�ng thao t�c/no")
end

function remove_item(nIndex)
local nMyIndex = PlayerIndex
PlayerIndex = nVictimIndex	
Say("GameMaster thu h�i v�t ph�m "..GetNameItem(nIndex).." c�a b�n", 0)
DelItemIdx(nIndex)
PlayerIndex = nMyIndex
Msg2Player("Ho�n t�t x�a b� v�t ph�m")
end

function ShowPlayerFrom(nNumber)
	local AdminIndex = PlayerIndex
	if (nNumber <= 0) then
	OpenStrBox("T� "..tonumber(GetClientString()).." ��n ?", "ShowPlayerFrom#"..tonumber(GetClientString()).."", 1, 1200)
	else

		local nNumberBegin = nNumber
		local nNumberEnd = tonumber(GetClientString())
		local szStr = ""
		for i= nNumberBegin, nNumberEnd do
		PlayerIndex = i
			if (GetPlayerName() ~= "") then
				local nW,nX,nY = GetWorldPos()
				szStr = "S� hi�u: "..i.."\nT�n t�i kho�n: "..GetPlayerAccount().."\nT�n nh�n v�t: "..GetPlayerName().."\nB�n ��: "..GetMapName(nW).." - "..floor(nX/8).."/"..floor(nY/16)
				PlayerIndex = AdminIndex
				Msg2Player(szStr)
			end
		end
	end
end

function MoveGM(nNumber)
	local AdminIndex = PlayerIndex
	local nTarget = tonumber(nNumber)
	local szStr = ""
	local nW, nX, nY = GetWorldPos()
	PlayerIndex = nTarget
	NewWorld(nW, nX, nY)
	SetFightState(0)
	SetLogoutRV(0)
	szStr = "Di chuy�n "..GetPlayerName().." v� GM."
	PlayerIndex = AdminIndex
	Msg2Player(szStr)
end

function MoveTown(nVictimIndex)
	OpenStrBox("MapID/X/Y", "lets_go#"..nVictimIndex.."")
end

function lets_go(nVictimIndex)
	local AdminIndex = PlayerIndex
	szGMString = GetClientString()
	PlayerIndex = nVictimIndex
	local szStr = ""
	MapID = GetParam(szGMString, 1)
	PosX = GetParam(szGMString, 2)
	PosY = GetParam(szGMString, 3)
	NewWorld(MapID, PosX*8, PosY*16)
	SetFightState(0)
	SetLogoutRV(0)
	szStr = "Di chuy�n "..GetPlayerName().." v� "..GetMapName(MapID).." "..PosX.."/"..PosY.."."
	PlayerIndex = AdminIndex
	Msg2Player(szStr)
end

function MoveCell(nNumber)
	local AdminIndex = PlayerIndex
	local nTarget = tonumber(nNumber)
	local szStr = ""
	PlayerIndex = nTarget
	NewWorld(IDMapThienLao,1585,3195)
	SetRevPos(14);
	SetFightState(0)
	SetLogoutRV(0)
	szStr = "Di chuy�n "..GetPlayerName().." v�o Thi�n Lao."
	PlayerIndex = AdminIndex
	Msg2Player(szStr)
end

function  MsgSpecial1(szstr)
local Name = GetParam(szstr,1)
local Msg = GetParam(szstr,2)
Msg2SubWorld(Name,Msg)
end

function  MsgSpecial2(szstr)
AddGlobalNews(szstr)
end
