Include("\\script\\global\\serverlib.lua")
Include("\\script\\global\\tasklist.lua");
Include("\\script\\global\\map_helper.lua");

function main(nNpcIndex)
	DropQuestItem(nNpcIndex, 128, 1, nYearEnd, nMonthEnd, nDayEnd, nHourEnd, nMinEnd)
end;