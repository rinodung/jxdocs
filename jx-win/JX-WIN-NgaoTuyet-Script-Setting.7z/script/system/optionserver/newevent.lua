Include("\\script\\global\\serverlib.lua")
Include("\\script\\global\\tasklist.lua");
Include("\\script\\global\\map_helper.lua");

function event_content()
TabSay = {
"L� Trung Thu h�ng n�m ��u do ta ph� tr�ch",
"Ta mang nguy�n li�u ��n l�m b�nh/make_cake",
"��i b�nh trung thu nh�n th��ng/change_cake",
"�� 6 m�nh tranh V�n Du/tranh#1", 
"�� 6 m�nh tranh Ti�n V�/tranh#2",
"Online nh�n th��ng/online2gift",
"�o�n �o�n vi�n vi�n/no",
}
SayNew(1, 1, TabSay[1], 6, TabSay[2], TabSay[3], TabSay[4], TabSay[5], TabSay[6], TabSay[7])
end

function online2gift()
Say("B�n hi�n c� "..CalcTime(GetTask(T_TongDiemOnline)).." tr�n m�ng. M�i gi� c� th� ��i 300.000 �i�m kinh nghi�m. B�n mu�n ��i bao nhi�u?",2,
"Ta mu�n ��i/online2gift1#0",
"H�n g�p l�i ng��i sau/no")
end

function online2gift1(nNumber)
if (tonumber(nNumber) == 0) then
if (GetTask(T_TongDiemOnline) >= 60) then
OpenStrBox("Nh�p s� gi�", "online2gift1", GetTask(T_TongDiemOnline)/60)
else
Msg2Player("L� quan", "<color=Cyan>Th�i gian tr�n m�ng c�a b�n ch�a �� <color=Green>1<color> gi� kh�ng th� quy ��i")
end
else
for i = 1,tonumber(nNumber) do
AddOwnExp(3000000)
end
AddTask(T_TongDiemOnline, -(nNumber*60))
Msg2Player("L� quan", "<color=Cyan>��y l� ph�n th��ng x�ng ��ng d�nh cho c�c h�. H�y nh�n l�y <color=Green>"..(nNumber*300000).."<color> �i�m kinh nghi�m")
end
end

function change_cake()
TabSay = {
"Ho�t ��ng n�y ch� ho�t ��ng ��n 0h00 30/9\n\t2 B�nh trung thu Minh Nguy�t = 600.000 kinh nghi�m\n\t2 B�nh trung thu Vi�n Nguy�t = 600.000 kinh nghi�m",
"Ta mu�n ��i b�nh Minh Nguy�t/change_cake1#1",
"Ta mu�n ��i b�nh Vi�n Nguy�t/change_cake1#2",
"�o�n �o�n vi�n vi�n/no",
}
Say(TabSay[1], 3, TabSay[2], TabSay[3], TabSay[4])
end

function change_cake1(nKind)
if (tonumber(nKind) == 1) then
if (GetItemCount(BANHMINHNGUYET) >= 2) then
OpenStrBox("Nh�p s� l��ng", "change_cake2#1", GetItemCount(BANHMINHNGUYET)/2)
else
Msg2Player("L� quan", "Ng��i ph�i c� �t nh�t 2 b�nh trung thu Minh Nguy�t m�i c� th� ��i th��ng")
end
elseif (tonumber(nKind) == 2) then
if (GetItemCount(BANHVIENNGUYET) >= 2) then
OpenStrBox("Nh�p s� l��ng", "change_cake2#2", GetItemCount(BANHVIENNGUYET)/2)
else
Msg2Player("L� quan", "Ng��i ph�i c� �t nh�t 2 b�nh trung thu Vi�n Nguy�t m�i c� th� ��i th��ng")
end
end
end

function change_cake2(nKind)
nNumber = tonumber(GetClientString())*2
if (nNumber <= 0) then
return
end
for i = 1,nNumber do
if (tonumber(nKind) == 1) then
DelQuestItem(BANHMINHNGUYET)
elseif (tonumber(nKind) == 2) then
DelQuestItem(BANHVIENNGUYET)
end
end
AddOwnExp(600000*nNumber/2)
Msg2Player("L� quan", "<color=Cyan>��i th�nh c�ng, nh�n ���c <color=Green>"..(600000*nNumber/2).."<color> �i�m kinh nghi�m")
end

function CalcTime(nValue)
	if (floor(nValue/60) > 0) then
		if (nValue-(floor(nValue/60)*60) > 0) then
		return "<color=Green>"..floor(nValue/60).."<color> gi� <color=Green>"..(nValue-(floor(nValue/60)*60)).."<color> ph�t"
		else
		return "<color=Green>"..floor(nValue/60).."<color> gi� "
		end
	else
	return "<color=Green>"..nValue.."<color> ph�t"
	end
end

function make_cake()
TabSay = {
"",
"B�nh ��u xanh h�o h�ng/cake#1",
"B�nh h�t sen h�o h�ng/cake#2",
"B�nh trung thu Minh nguy�t/cake#3",
"B�nh trung thu Vi�n nguy�t/cake#4",
"B�nh trung thu Ho�ng nguy�t/cake#5",
"�o�n �o�n vi�n vi�n/no",
}
SayNew(1, 1, TabSay[1], 6, TabSay[2], TabSay[3], TabSay[4], TabSay[5], TabSay[6], TabSay[7])
end

function cake(nName)
if (nName == 1) then
Say("Nguy�n li�u c�n:\n\t1 ���ng c�t (<color=Green>"..GetItemCount(DUONGCAT).."<color>)\n\t1 B�t m� (<color=Green>"..GetItemCount(BOTMI).."<color>)\n\t1 ��u xanh (<color=Green>"..GetItemCount(DAUXANH).."<color>)\n\t20 v�n l��ng (<color=Gold>"..GetCash().."<color>)", 2,
"H�y n��ng c�n th�n cho ta/make_cake2#1",
"Ta c� ch�t nh�m l�n/no")
elseif (nName == 2) then
Say("Nguy�n li�u c�n:\n\t1 ���ng c�t (<color=Green>"..GetItemCount(DUONGCAT).."<color>)\n\t1 B�t m� (<color=Green>"..GetItemCount(BOTMI).."<color>)\n\t1 H�t sen (<color=Green>"..GetItemCount(HATSEN).."<color>)\n\t20 v�n l��ng (<color=Gold>"..GetCash().."<color>)", 2,
"H�y n��ng c�n th�n cho ta/make_cake2#2",
"Ta c� ch�t nh�m l�n/no")
elseif (nName == 3) then
Say("Nguy�n li�u c�n:\n\t1 ���ng c�t (<color=Green>"..GetItemCount(DUONGCAT).."<color>)\n\t1 B�t m� (<color=Green>"..GetItemCount(BOTMI).."<color>)\n\t1 Th�t g� (<color=Green>"..GetItemCount(THITGA).."<color>)", 2,
"H�y n��ng c�n th�n cho ta/make_cake2#3",
"Ta c� ch�t nh�m l�n/no")
elseif (nName == 4) then
Say("Nguy�n li�u c�n:\n\t1 ���ng c�t (<color=Green>"..GetItemCount(DUONGCAT).."<color>)\n\t1 B�t m� (<color=Green>"..GetItemCount(BOTMI).."<color>)\n\t1 Th�t g� (<color=Green>"..GetItemCount(THITGA).."<color>)", 2,
"H�y n��ng c�n th�n cho ta/make_cake2#4",
"Ta c� ch�t nh�m l�n/no")
elseif (nName == 5) then
Say("Nguy�n li�u c�n:\n\t1 ���ng c�t (<color=Green>"..GetItemCount(DUONGCAT).."<color>)\n\t1 B�t m� (<color=Green>"..GetItemCount(BOTMI).."<color>)\n\t1 ��i g� (<color=Green>"..GetItemCount(DUIGA).."<color>)", 2,
"H�y n��ng c�n th�n cho ta/make_cake2#5",
"Ta c� ch�t nh�m l�n/no")
end
end

function GetMin3Number(nNumber1, nNumber2, nNumber3)
local nMinNumber = nNumber1
if (nMinNumber > nNumber2) then
nMinNumber = nNumber2
end
if (nMinNumber > nNumber3) then
nMinNumber = nNumber3
end
if (nMinNumber <= 0) then
Msg2Player("L� quan","H�nh trang kh�ng �� nguy�n li�u �� n��ng �t nh�t 1 chi�c b�nh")
return
end
return nMinNumber
end

function GetMin3NumberMoney(nNumber1, nNumber2, nNumber3, nMoneyNeed)
local nMinNumber = nNumber1
local nMinNumber2Money = (GetCash()/nMoneyNeed)
if (nMinNumber > nNumber2) then
nMinNumber = nNumber2
end
if (nMinNumber > nNumber3) then
nMinNumber = nNumber3
end
if (nMinNumber > nMinNumber2Money) then
nMinNumber = nMinNumber2Money
end
if (nMinNumber <= 0) then
Msg2Player("L� quan","H�nh trang kh�ng �� nguy�n li�u �� n��ng �t nh�t 1 chi�c b�nh")
return
end
return nMinNumber
end

function make_cake2(nName)
if (nName == 1) then
local nMin = GetMin3NumberMoney(GetItemCount(DUONGCAT), GetItemCount(BOTMI), GetItemCount(DAUXANH), 200000)
OpenStrBox("Nh�p s� b�nh", "make_cake3#1", nMin)
elseif (nName == 2) then
local nMin = GetMin3NumberMoney(GetItemCount(DUONGCAT), GetItemCount(BOTMI), GetItemCount(HATSEN), 200000)
OpenStrBox("Nh�p s� b�nh", "make_cake3#2", nMin)
elseif (nName == 3) then
local nMin = GetMin3Number(GetItemCount(DUONGCAT), GetItemCount(BOTMI), GetItemCount(THITGA))
OpenStrBox("Nh�p s� b�nh", "make_cake3#3", nMin)
elseif (nName == 4) then
local nMin = GetMin3Number(GetItemCount(DUONGCAT), GetItemCount(BOTMI), GetItemCount(THITGA))
OpenStrBox("Nh�p s� b�nh", "make_cake3#4", nMin)
elseif (nName == 5) then
local nMin = GetMin3Number(GetItemCount(DUONGCAT), GetItemCount(BOTMI), GetItemCount(DUIGA))
OpenStrBox("Nh�p s� b�nh", "make_cake3#5", nMin)
end
end

function make_cake3(nKind)
mNumber = tonumber(GetClientString())
if (mNumber > 50) then
mNumber = 50
elseif (mNumber <= 0) then
return
end

for i = 1,tonumber(mNumber) do
DelQuestItem(DUONGCAT)
DelQuestItem(BOTMI)
if (nKind == 1) then
DelQuestItem(DAUXANH)
Pay(200000*mNumber)
elseif (nKind == 2) then
DelQuestItem(HATSEN)
Pay(200000*mNumber)
elseif (nKind == 3 or nKind == 4) then
DelQuestItem(THITGA)
elseif (nKind == 5) then
DelQuestItem(DUIGA)
end
end

if (nKind == 1) then
nIndex = AddQuestItem(BANHDAUXANH, mNumber)
elseif (nKind == 2) then
nIndex = AddQuestItem(BANHHATSEN, mNumber)
elseif (nKind == 3) then
nIndex = AddQuestItem(BANHMINHNGUYET, mNumber)
elseif (nKind == 4) then
nIndex = AddQuestItem(BANHVIENNGUYET, mNumber)
elseif (nKind == 5) then
nIndex = AddQuestItem(BANHHOANGNGUYET, mNumber)
end

SetTime(nIndex, nYearEnd, nMonthEnd, nDayEnd, nHourEnd, nMinEnd)
Msg2Player("Th� l�m b�nh", "<color=Cyan>B�nh n�ng v�a xong ��y! H�y nh�n l�y <color=Gold>"..mNumber.." "..SetColorItem(nIndex).."<color=Cyan> c�a c�c h� ")
end

function tranh(nKind)
if (nKind == 1) then
if (GetItemCount(VANDU1) >= 1 and
GetItemCount(VANDU2) >= 1 and
GetItemCount(VANDU3) >= 1 and
GetItemCount(VANDU4) >= 1 and
GetItemCount(VANDU5) >= 1 and
GetItemCount(VANDU6) >= 1) then
DelQuestItem(VANDU1)
DelQuestItem(VANDU2)
DelQuestItem(VANDU3)
DelQuestItem(VANDU4)
DelQuestItem(VANDU5)
DelQuestItem(VANDU6)
nIndex = AddQuestItem(CONGNGUYET)
SetTime(nIndex, nYearEnd, nMonthEnd, nDayEnd, nHourEnd, nMinEnd)
Msg2Player("L� quan", "<color=Cyan>Ng��i qu� th�t c� l�ng h�y nh�n l�y "..SetColorItem(nIndex).."<color=Cyan> c�a c�c h� ")
else
Msg2Player("L� quan", "<color=Cyan>Ta c�n �� 6 m�nh tranh V�n Du, ng��i c� th� thu th�p �� kh�ng?")
end
elseif (nKind == 2) then
if (GetItemCount(TIENVU1) >= 1 and
GetItemCount(TIENVU2) >= 1 and
GetItemCount(TIENVU3) >= 1 and
GetItemCount(TIENVU4) >= 1 and
GetItemCount(TIENVU5) >= 1 and
GetItemCount(TIENVU6) >= 1) then
DelQuestItem(TIENVU1)
DelQuestItem(TIENVU2)
DelQuestItem(TIENVU3)
DelQuestItem(TIENVU4)
DelQuestItem(TIENVU5)
DelQuestItem(TIENVU6)
nIndex = AddQuestItem(PHUNGNGUYET)
SetTime(nIndex, nYearEnd, nMonthEnd, nDayEnd, nHourEnd, nMinEnd)
Msg2Player("L� quan", "<color=Cyan>Ng��i qu� th�t c� l�ng h�y nh�n l�y "..SetColorItem(nIndex).."<color=Cyan> c�a c�c h� ")
else
Msg2Player("L� quan", "<color=Cyan>Ta c�n �� 6 m�nh tranh Ti�n V�, ng��i c� th� thu th�p �� kh�ng?")
end
end
end