Include("\\script\\global\\serverlib.lua")

function main(nIndex)
Msg2SubWorld("Trang b� t� qu�i v�t","Ng��i ch�i <color=green>"..GetPlayerName().."<color> nh�t ���c <color=Green>"..GetObjName(nIndex).." !<color>")
end