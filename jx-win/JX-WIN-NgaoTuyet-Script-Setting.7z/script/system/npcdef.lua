function OnDeath(nNpcIndex)
			nRandom = random(1,100)		
			local nW, nX, nY = GetNpcPos(nNpcIndex)
			npcmapindex= SubWorldID2Idx(nW)  			
			if (nRandom == 2) then
			Obj1 = AddObj(463, npcmapindex, nX*32, nY*32, "\\script\\missions\\questdatau\\diadochi\\balanghuyen.lua");
			end
			if (nRandom == 50) then
			Obj1 = AddObj(464, npcmapindex, nX*32, nY*32, "\\script\\missions\\questdatau\\matchi\\matchi.lua");
			end
			if (nRandom == 100) then
			Obj1 = AddObj(475, npcmapindex, nX*32, nY*32, "\\script\\global\\quest_new\\meat.lua");
			end
end