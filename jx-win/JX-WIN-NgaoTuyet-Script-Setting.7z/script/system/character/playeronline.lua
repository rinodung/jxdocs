--=======================================
--Author: Hoang
--=======================================
Include("\\script\\global\\serverlib.lua")
Include("\\script\\global\\tasklist.lua");
Include("\\script\\global\\maplist.lua");

function main(nIndex)
	MessageInfoVIP()
	CheckNewDay()
	CheckDual()
	CheckSkill()
	CheckRank()
	CheckPK()
	CheckItem()
	SendClientInfo()
end

function MessageInfoVIP()
	szName = GetName()
	Msg2SubWorld("<color=green>Nh�n v�t <color=metal>"..szName.."<color> v�o tr� ch�i")
end

function ReportBind(nTotalBindItem)
	if (nTotalBindItem > 0) then
		Talk(1,"","B�n �ang c� <color=red>"..nTotalBindItem.."<color> trang b� c�n ���c m� kh�a b�o hi�m, b�n c� th� ki�m tra trong m�c C�p nh�t s� ki�n (<color=white>F11<color>) !")
	end
end

function NoteBind(nIndex)
	AddNote("V�t ph�m <color=green>"..GetNameItem(nIndex).." <color> m� kh�a sau <color=green>"..CalcTime(GetBindItem(nIndex)).."")
end

function CalcTime(nValue)
	if (floor(nValue/60) > 0) then
		return ""..floor(nValue/60).." gi� "..(nValue-(floor(nValue/60)*60)).." ph�t  !"
	else
		return ""..nValue.." ph�t  !"
	end
end

function CheckSkill()
	if HaveMagic(1) ~= 1 then
	AddMagic(1)
	end
	if HaveMagic(2) ~= 1 then
	AddMagic(2)
	end
	if HaveMagic(53) ~= 1 then
	AddMagic(53)
	end
end

function CheckNewDay()
ngay = tonumber(date("%d"))
if (GetTask(T_LuuNgay) <= 0) then
	SetTask(T_LuuNgay,ngay)
else
	if (GetTask(T_LuuNgay) ~= ngay) then
	SetTask(T_LuuNgay,ngay)
	AddTask(T_TongDiemOnline,GetTask(T_NhanDiemOnline))
	SetTask(T_NhanDiemOnline,0)
	SetTask(T_BayBan,0)
	SetTask(T_Bind,0)
	end
end
end

function CheckDual()
local nTimeDualExp = GetTask(T_TimeDualExp)
local nTimeDualSkill = GetTask(T_TimeDualSkill)
if (nTimeDualExp > 0) then
		SetDualExp(2,nTimeDualExp)
		AddSkillState(370,1,nTimeDualExp)
end
if (nTimeDualSkill > 0) then
		SetDualSkill(2,nTimeDualSkill)
		AddSkillState(370,1,nTimeDualSkill)
end
end


function CheckRank()
if (GetLevel() < 10) then
	SetRank(23)
elseif (GetRankOnName() == 55) then 
	SetRank(66)
	AddSkillState(376,1,-1)
elseif (GetRankOnName() == 61) then
	SetRank(61)
	AddSkillState(376,1,-1)	
elseif (GetRankOnName() == 81) then
	SetRank(81)
	AddSkillState(377,1,-1)	
elseif (GetRankOnName() == 82) then
	SetRank(82)
	AddSkillState(372,1,-1)
elseif (GetRankOnName() == 83) then
	SetRank(83)
	AddSkillState(373,1,-1)
elseif (GetRankOnName() == 84) then
	SetRank(84)
	AddSkillState(374,1,-1)
elseif (GetRankOnName() == 85) then
	SetRank(85)
	AddSkillState(375,1,-1)
elseif (GetRankOnName() == 86) then
	SetRank(86)
	AddSkillState(372,1,-1)
elseif (GetRankOnName() == 87) then
	SetRank(87)
	AddSkillState(373,1,-1)
elseif (GetRankOnName() == 88) then
	SetRank(88)
	AddSkillState(374,1,-1)
elseif (GetRankOnName() == 89) then
	SetRank(89)
	AddSkillState(375,1,-1)
end
end

function CheckPK()
	local nW, nX, nY = GetWorldPos()
	if (nW == IDMapThienLao) and (GetPK() >= 1) then
		SetTimer(600*18,8)
		return
	end
	if (GetPK() >= 8) then
		Msg2Player("Tay ng��i �� nhu�m m�u qu� nhi�u, h�y v�o Thi�n Lao �� �n n�n s�m h�i.")	
		SetTimer(600*18,8)
		NewWorld(IDMapThienLao,1600,3200) 
		SetFightState(0)
		SetPKState(0,0)
		SetLogoutRV(0)
		SetTask(T_DemTimePK,3)
	end
end

function CheckItem()
if (GetItemCount(89) <= 0) then
AddQuestItem(89)
end
end

function SendClientInfo()
SetCamp(GetCamp())
SetCurCamp(GetCurCamp())
SetTask(T_MauPhe,0)
SetTask(T_NhanDiemOnline,GetTask(T_NhanDiemOnline))
SetTask(T_Bind,GetTask(T_Bind))
SetTask(T_ExpSkill1,GetTask(T_ExpSkill1))
SetTask(T_ExpSkill2,GetTask(T_ExpSkill2))
SetTask(T_ExpSkill3,GetTask(T_ExpSkill3))
end
