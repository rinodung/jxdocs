function main()
	w, x, y = GetWorldPos()
	head = "khong tham gia hoat dong"
	if w == 378 then
		SetTask(T_MauPhe,0)
		RestoreCamp()
		SetPKState(0,0)
		SetCreateTeam(1)
		RankOnName(0)
		ResetMask()
		head = "dang tham gia hoat dong [Tong Kim]"
	end
	
	print(GetName().." thoat game | "..head)
end