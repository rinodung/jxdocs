Include("\\script\\global\\serverlib.lua")
Include("\\script\\global\\tasklist.lua");
Include("\\script\\global\\maplist.lua");
Include("\\script\\system\\system.lua");

	nMin = tonumber(date("%M"))
	nGio = tonumber(date("%H"))
	nNgay = tonumber(date("%d")) + 7
	nThang = tonumber(date("%m"))
	nNam = tonumber(date("%y")) + 2000

function special_func()
dofile("script/system/admin.lua")
special_func1()
end

function special_func1()
local tabChoose_func_test = {
	"R�i kh�i./no",
	"Thao t�c/test_function",
	"Nh�n v�t/func_manage",
	"Qu�n l� ng��i ch�i/go_system",
}
SayNew("",getn(tabChoose_func_test),tabChoose_func_test)
end

function go_system()
if (GetTaskTemp(TMT_GameMaster) > 0) then
system("gm")
else
OpenStrBox("Nh�p m� GameMaster", "system")
end
end


function logWrite(str)
local gm_Log = "script/toado.txt"
local fs_log = openfile(gm_Log, "a");
write(fs_log, ""..str.."\n");
closefile(fs_log);
end

function func_manage()
local tabChoose_manager = {
	"R�i kh�i./no",
	"Tr� l�i/"..GetLastDiagFunc().."",
	"Nh�n �i�m th��ng/function_manager_step2#1",
	"Nh�n trang b�/function_manager_step2#2",
	"Nh�n chi�n m�/function_manager_step2#3",
	}
	SayNew("", getn(tabChoose_manager), tabChoose_manager)
end

function function_manager_step2(nsel)
if (nsel == 1) then
tab_Modify = {
"R�i kh�i/no",
"Tr� l�i/"..GetLastDiagFunc().."",
"��ng c�p/func_modify_step1#1",
"Ng�n l��ng/func_modify_step1#2",
"Danh v�ng/func_modify_step1#3",
"Ph�c duy�n/func_modify_step1#4",
"L�nh ��o/func_modify_step1#5",
"Tr�ng sinh/func_modify_step1#6",
--"<500 �i�m SM, SK, TP, NC>/func_modify_step1",
}
SayNew("",getn(tab_Modify),tab_Modify)
elseif (nsel == 2) then
SayNew("", 7,
"R�i kh�i/no",	
"Tr� l�i/"..GetLastDiagFunc().."",
"Ng� h�nh/function_manager_step3#1",
"Trang b� HK th��ng/function_manager_step3#2",
"Trang b� HKMP/function_manager_step3#3",
"M�t n�/function_manager_step3#4",
"Phi phong/function_manager_step3#5",
"Ti�n ��ng/function_manager_step3#6")
elseif (nsel == 3) then
TabHorse = {
"R�i kh�i/no",	
"Tr� l�i/"..GetLastDiagFunc().."",
"� V�n ��p Tuy�t/get_horse_step3#1",
"Chi�u D� Ng�c S� T�/get_horse_step3#2",
"Phi V�n/get_horse_step3#3",
"B�n Ti�u/get_horse_step3#4",
"Phi�u V�/get_horse_step3#5",
}
SayNew("Ch�n lo�i ng�a ch� ��nh", getn(TabHorse), TabHorse);
end
end

function test_function()
	SayNew( "", 5, 
	"R�i kh�i/no",	
	"Tr� l�i/"..GetLastDiagFunc().."",
	"Nh�n nguy�n li�u trung thu/test_function_step1",
	"Nh�n m�nh tranh V�n Du/test_function_step1",
	"Nh�n m�nh tranh Ti�n V�/test_function_step1")
	--"H�m/test_function_step1")
end

function test_function_step1(nsel)
if (nsel == 1) then
AddQuestItem(DUONGCAT, 50)
AddQuestItem(BOTMI, 50)
AddQuestItem(DAUXANH, 50)
AddQuestItem(HATSEN, 50)
AddQuestItem(DUIGA, 50)
AddQuestItem(THITGA, 50)
elseif (nsel == 2) then
AddQuestItem(VANDU1)
AddQuestItem(VANDU2)
AddQuestItem(VANDU3)
AddQuestItem(VANDU4)
AddQuestItem(VANDU5)
AddQuestItem(VANDU6)
elseif (nsel == 3) then
AddQuestItem(TIENVU1)
AddQuestItem(TIENVU2)
AddQuestItem(TIENVU3)
AddQuestItem(TIENVU4)
AddQuestItem(TIENVU5)
AddQuestItem(TIENVU6)
elseif (nsel == 4) then
new_function_tvt()
end
end

function save_pos()
SetTaskTemp(200,1)
w,x,y = GetWorldPos()
logWrite("{"..(x*32)..","..(y*32).."},")
Msg2Player("�� ghi l�i log c�a t�a �� n�y t�i script/toado.txt")
end
---------------------------------------------------------


function func_modify_step1(nsel)
if (nsel == 1) then
OpenStrBox("Nh�p ��ng c�p", "modify_level", 1, 200)
elseif (nsel == 2) then
OpenStrBox("Nh�p s� ti�n", "modify_money", 5000000)
elseif (nsel == 3) then
OpenStrBox("Nh�p danh v�ng", "modify_repute", 10000)
elseif (nsel == 4) then
OpenStrBox("Nh�p ph�c duy�n", "modify_fuyan", 10000)
elseif (nsel == 5) then
AddLeadExp(99999)
elseif (nsel == 6) then
OpenStrBox("Nh�p tr�ng sinh", "modify_reborn", 5)
elseif (nsel == 7) then
AddStrg(500)
AddEng(500)
AddDex(500)
AddVit(500)
end
end

function modify_level(nLevel)
SetLevel(nLevel)
end

function modify_money()
local nNumber = tonumber(GetClientString())
Earn(nNumber)
end

function modify_fuyan()
local nNumber = tonumber(GetClientString())
AddFuYuan(nNumber)
end

function modify_repute()
local nNumber = tonumber(GetClientString())
AddRepute(nNumber)
end

function modify_reborn(mNumber)
local nNumber = tonumber(mNumber)
SetReBorn(nNumber)
Msg2Player("Nh�n v�t ��t c�nh gi�i tr�ng sinh "..nNumber.."")
end


function task_battle()
AddTask(T_TichLuyTam,random(100,1000))
AddTask(T_LienTramHT,random(100,1000))
AddTask(T_LienTramCao,random(100,1000))
AddTask(T_LienTram,random(100,1000))
AddTask(T_PK,random(100,1000))
AddTask(T_NPC,random(100,1000))
AddTask(T_TuVong,random(100,1000))
AddTask(T_DoatCo,random(100,1000))
end


function new_function_tvt()
			tab_NewFunc_TVT = {
			"R�i kh�i/no",
			"Tr� l�i/"..GetLastDiagFunc().."",
			"SetMask(nNumber) - h�m thay ��i nh�n v�t th�nh Npc theo th� t� t�i Npc.txt./new_function_tvt_step1",
			"ReSetMask() - h�m x�a b� tr�ng th�i mang m�t n�./new_function_tvt_step1",
			"OpenQuest(nId) - m� ra h�p tho�i nh�n th��ng nhi�m v� d� t�u./new_function_tvt_step1",
			"OpenTong(1) - m� ra h�p tho�i l�p bang h�i, c�n 1 Nh�c V��ng ki�m./new_function_tvt_step1",
			"SetExBox(1)- m� r�ng r��ng ch�a �� th� nh�t./new_function_tvt_step1",
			}
	SayNew("", getn(tab_NewFunc_TVT), tab_NewFunc_TVT)
end

function new_function_tvt_step1(nsel)
if (nsel == 1) then
SetMask(random(1,100))
elseif (nsel == 2) then
ReSetMask()
elseif (nsel == 3) then
OpenQuest(random(1,53))
elseif (nsel == 4) then
OpenTong(1)
elseif (nsel == 5) then
SetExBox(1)
end
end

----------------------------------------------------


function function_manager_step3(nsel)
if (nsel == 1) then
function_manager_step4()
elseif (nsel == 2) then
TabGoldNormal = {
"Kim Phong/gold_normal#1#9",
"An Bang/gold_normal#10#13",
"��nh Qu�c/gold_normal#22#26",
"Nhu T�nh/gold_normal#41#44",
"Hi�p C�t/gold_normal#45#48",
"Tr� l�i/"..GetLastDiagFunc().."",
"Kh�ng nh�n/no",
}
Say("Xin ch�n b� trang b� c�n", getn(TabGoldNormal), TabGoldNormal)
elseif (nsel == 3) then
Msg2Player("Kh�ng c� trang b� lo�i n�y")
elseif (nsel == 4) then
OpenStrBox("Nh�p ��ng c�p", "get_mask_item", 1, 19)
elseif (nsel == 5) then
for a = 1, 11 do
AddItem(0,12,0,a,0,0,10)
end
elseif (nsel == 6) then
OpenStrBox("Nh�p s� l��ng", "get_tiendong", 50)
end
end

function get_tiendong(nNumber)
AddQuestItem(TIENDONG, nNumber)
end

function gold_normal(nIdBegin, nIdEnd)
for nId = nIdBegin,nIdEnd do
AddGoldItem(nId)
end
end

function get_mask_item(nNumber)
AddItem(0,11,0,nNumber,1,0,10)
end

function special_item()
nLevel = random(1,10)
AddItem(0,2,28,nLevel,1,0,10)
end

function yellow_add(nsel)
end

-----------------------------------------

function get_horse_step3(nSel)
if (nSel == 1) then
nIndex = AddItem(0,10,5,6,0,0,0)
elseif (nSel == 2) then
nIndex = AddItem(0,10,5,10,0,0,0)
elseif (nSel == 3) then
nIndex = AddItem(0,10,8,10,0,0,0)
elseif (nSel == 4) then
nIndex = AddItem(0,10,6,10,0,0,0)
elseif (nSel == 5) then
nIndex = AddItem(0,10,7,10,0,0,0)
else
return
end
AddTime(nIndex, 7)
end


function function_manager_step4()
	local TAB_HE = {
		"H� Kim/series_item",
		"H� M�c/series_item",
		"H� Th�y/series_item",
		"H� H�a/series_item",
		"H� Th�/series_item",
		"Tr� l�i/"..GetLastDiagFunc().."",
		"K�t th�c ��i tho�i/no",}
	SayNew("",6,TAB_HE[1],TAB_HE[2],TAB_HE[3],TAB_HE[4],TAB_HE[5],TAB_HE[6])
end
function series_item(nSeries)
	local TAB_DO = {
		"V� Kh�/get_weapon#"..nSeries.."",
		"Trang B� N�/getclothes#"..nSeries.."#0",
		"Trang B� Nam/getclothes#"..nSeries.."#1",
		"D�y Chuy�n/getitemsmall_sex#"..nSeries.."#1",
		"Ng�c B�i/getitemsmall_sex#"..nSeries.."#2",
		"Nh�n/getitemsmall_sex#"..nSeries.."#3",
		"Tr� l�i/"..GetLastDiagFunc().."",
		"R�i kh�i/no",}
	SayNew("", getn(TAB_DO), TAB_DO)
end


function getitemsmall_sex(nSeries, nKind)
	local TabSex = {
		"N�/getitemsmall_level#"..nSeries.."#0#"..nKind.."",
		"Nam/getitemsmall_level#"..nSeries.."#1#"..nKind.."",
		"Tr� l�i/"..GetLastDiagFunc().."",
		"R�i kh�i/no",}
	SayNew("",getn(TabSex),TabSex)
end

function getitemsmall_level(nSeries, nSex, nKind)
	local TabLevel = {
		"C�p 1/getitemsmall_number#"..nSeries.."#"..nSex.."#1#"..nKind.."",
		"C�p 2/getitemsmall_number#"..nSeries.."#"..nSex.."#2#"..nKind.."",
		"C�p 3/getitemsmall_number#"..nSeries.."#"..nSex.."#3#"..nKind.."",
		"C�p 4/getitemsmall_number#"..nSeries.."#"..nSex.."#4#"..nKind.."",
		"C�p 5/getitemsmall_number#"..nSeries.."#"..nSex.."#5#"..nKind.."",
		"C�p 6/getitemsmall_number#"..nSeries.."#"..nSex.."#6#"..nKind.."",
		"C�p 7/getitemsmall_number#"..nSeries.."#"..nSex.."#7#"..nKind.."",
		"C�p 8/getitemsmall_number#"..nSeries.."#"..nSex.."#8#"..nKind.."",
		"C�p 9/getitemsmall_number#"..nSeries.."#"..nSex.."#9#"..nKind.."",
		"C�p 10/getitemsmall_number#"..nSeries.."#"..nSex.."#10#"..nKind.."",
		"Tr� l�i/"..GetLastDiagFunc().."",
		"R�i kh�i/no",}
	SayNew("",getn(TabLevel),TabLevel)
end

function getitemsmall_number(nSeries, nSex, nLevel, nKind)
OpenStrBox("Nh�p s� l��ng(c�i)", "getitemsmall_success#"..nSeries.."#"..nSex.."#"..nLevel.."#"..nKind.."", 60)
end

function getitemsmall_success(nSeries, nSex, nLevel, nKind)
	local nItemNumber = GetClientString()
	if (nKind == 1) then
	for i=1,nItemNumber do
		nIndex = AddItem(0, 4, nSex, nLevel, nSeries, 100, 10)
		if (CheckPostion(nIndex) == 0) then
		Msg2Player(format("C�n �t nh�t 1 kho�ng tr�ng %dx%d trong t�i", GetWidthItem(nIndex), GetHeightItem(nIndex)))
		break;
		end		
	end
	elseif (nKind == 2) then
	for i=1,nItemNumber do
		nIndex = AddItem(0, 9, nSex, nLevel, nSeries, 100, 10)
		if (CheckPostion(nIndex) == 0) then
		Msg2Player(format("C�n �t nh�t 1 kho�ng tr�ng %dx%d trong t�i", GetWidthItem(nIndex), GetHeightItem(nIndex)))
		break;
		end		
	end
	elseif (nKind == 3) then
	for i=1,nItemNumber do
		nIndex = AddItem(0, 3, 0, nLevel, nSeries, 100, 10)
		if (CheckPostion(nIndex) == 0) then
		Msg2Player(format("C�n �t nh�t 1 kho�ng tr�ng %dx%d trong t�i", GetWidthItem(nIndex), GetHeightItem(nIndex)))
		break;
		end		
	end
	end
end

function getclothes(nSeries, nSex)
	local TabClothes0 = {
	"Y Ph�c/getarmor_woman#"..nSeries.."",
	"��nh M�o/gethelm_woman#"..nSeries.."",
	"Y�u ��i/getbelt#"..nSeries.."#6",
	"H�i T�/getboot#"..nSeries.."#5#0",
	"Bao Tay/getclothes_level#"..nSeries.."#8#0",
	"Tr� l�i/"..GetLastDiagFunc().."",
	"R�i kh�i/no",}
	local TabClothes1 = {
	"Y Ph�c/getarmor_man#"..nSeries.."",
	"��nh M�o/gethelm_man#"..nSeries.."",
	"Y�u ��i/getbelt#"..nSeries.."#6",
	"H�i T�/getboot#"..nSeries.."#5#1",
	"Bao Tay/getclothes_level#"..nSeries.."#8#1",
	"Tr� l�i/"..GetLastDiagFunc().."",
	"R�i kh�i/no",}
	if (nSex == 0) then
		SayNew("",getn(TabClothes0),TabClothes0)
	else
		SayNew("",getn(TabClothes1),TabClothes1)
	end
end

function getbelt(nSeries, Detail)
	local TabBelt = {
	"Thu�c Da/getclothes_level#"..nSeries.."#"..Detail.."#0",
	"Kim Lo�i/getclothes_level#"..nSeries.."#"..Detail.."#1",
	"Tr� l�i/"..GetLastDiagFunc().."",
	"R�i kh�i/no",}	
	SayNew("",getn(TabBelt),TabBelt)
end

function getboot(nSeries, Detail, nSex)
	local TabBoot = {
	"Gi�y C�/getclothes_level#"..nSeries.."#"..Detail.."#1",
	"Gi�y C�/getclothes_level#"..nSeries.."#"..Detail.."#2",
	"Gi�y Da/getclothes_level#"..nSeries.."#"..Detail.."#3",
	"Tr� l�i/"..GetLastDiagFunc().."",
	"R�i kh�i/no",}	
	if (nSex == 0) then
	SayNew("",getn(TabBoot)-1,TabBoot[2], TabBoot[3], TabBoot[4])
	else
	SayNew("",getn(TabBoot)-2,TabBoot[1], TabBoot[4])
	end
end

function getarmor_woman(nSeries)
	local TabClothesWoMan = {
	"N� T�ng Nh�n/getclothes_level#"..nSeries.."#2#7",
	"N� ��o Nh�n/getclothes_level#"..nSeries.."#2#8",
	"N� S�t Th�/getclothes_level#"..nSeries.."#2#9",
	"Ki�u N�/getclothes_level#"..nSeries.."#2#10",
	"N� T��ng/getclothes_level#"..nSeries.."#2#11",
	"N� �n M�y/getclothes_level#"..nSeries.."#2#12",
	"Linh Tinh/getclothes_level#"..nSeries.."#2#13",
	"Tr� l�i/"..GetLastDiagFunc().."",
	"R�i kh�i/no",}
	SayNew("",getn(TabClothesWoMan),TabClothesWoMan)
end

function getarmor_man(nSeries)
	local TabClothesMan = {
	"T�ng Nh�n/getclothes_level#"..nSeries.."#2#0",
	"��o Nh�n/getclothes_level#"..nSeries.."#2#1",
	"S�t Th�/getclothes_level#"..nSeries.."#2#2",
	"L�ng T�/getclothes_level#"..nSeries.."#2#3",
	"T��ng Qu�n/getclothes_level#"..nSeries.."#2#4",
	"�n M�y/getclothes_level#"..nSeries.."#2#5",
	"Linh Tinh/getclothes_level#"..nSeries.."#2#6",
	"Tr� l�i/"..GetLastDiagFunc().."",
	"R�i kh�i/no",}
	SayNew("",getn(TabClothesMan),TabClothesMan)
end

function gethelm_woman(nSeries)
	local TabClothesWoMan = {
	"N� T�ng Nh�n/getclothes_level#"..nSeries.."#7#7",
	"N� ��o Nh�n/getclothes_level#"..nSeries.."#7#8",
	"N� S�t Th�/getclothes_level#"..nSeries.."#7#9",
	"Ki�u N�/getclothes_level#"..nSeries.."#7#10",
	"N� T��ng/getclothes_level#"..nSeries.."#7#11",
	"N� �n M�y/getclothes_level#"..nSeries.."#7#12",
	"Linh Tinh/getclothes_level#"..nSeries.."#7#13",
	"Tr� l�i/"..GetLastDiagFunc().."",
	"R�i kh�i/no",}
	SayNew("",getn(TabClothesWoMan),TabClothesWoMan)
end

function gethelm_man(nSeries)
	local TabClothesMan = {
	"T�ng Nh�n/getclothes_level#"..nSeries.."#7#0",
	"��o Nh�n/getclothes_level#"..nSeries.."#7#1",
	"S�t Th�/getclothes_level#"..nSeries.."#7#2",
	"L�ng T�/getclothes_level#"..nSeries.."#7#3",
	"T��ng Qu�n/getclothes_level#"..nSeries.."#7#4",
	"�n M�y/getclothes_level#"..nSeries.."#7#5",
	"Linh Tinh/getclothes_level#"..nSeries.."#7#6",
	"Tr� l�i/"..GetLastDiagFunc().."",
	"R�i kh�i/no",}
	SayNew("",getn(TabClothesMan),TabClothesMan)
end

function getclothes_level(nSeries, nDetail, nParti)
	local TabLevel = {
		"C�p 1/getclothes_number#"..nSeries.."#"..nDetail.."#"..nParti.."#1",
		"C�p 2/getclothes_number#"..nSeries.."#"..nDetail.."#"..nParti.."#2",
		"C�p 3/getclothes_number#"..nSeries.."#"..nDetail.."#"..nParti.."#3",
		"C�p 4/getclothes_number#"..nSeries.."#"..nDetail.."#"..nParti.."#4",
		"C�p 5/getclothes_number#"..nSeries.."#"..nDetail.."#"..nParti.."#5",
		"C�p 6/getclothes_number#"..nSeries.."#"..nDetail.."#"..nParti.."#6",
		"C�p 7/getclothes_number#"..nSeries.."#"..nDetail.."#"..nParti.."#7",
		"C�p 8/getclothes_number#"..nSeries.."#"..nDetail.."#"..nParti.."#8",
		"C�p 9/getclothes_number#"..nSeries.."#"..nDetail.."#"..nParti.."#9",
		"C�p 10/getclothes_number#"..nSeries.."#"..nDetail.."#"..nParti.."#10",
		"Tr� l�i/"..GetLastDiagFunc().."",
		"R�i kh�i/no",}
	SayNew("",getn(TabLevel),TabLevel)
end

function getclothes_number(nSeries, nDetail, nParti, nLevel)
OpenStrBox("Nh�p s� l��ng(c�i)", "getclothes_success#"..nSeries.."#"..nDetail.."#"..nParti.."#"..nLevel.."", 60)
end

function getclothes_success(nSeries, nDetail, nParti, nLevel)
	for i = 1,GetClientString() do
		nIndex = AddItem(0, nDetail, nParti, nLevel, nSeries, 100, 10)
		if (CheckPostion(nIndex) == 0) then
		Msg2Player(format("C�n �t nh�t 1 kho�ng tr�ng %dx%d trong t�i", GetWidthItem(nIndex), GetHeightItem(nIndex)))
		break;
		end		
	end
end

function get_weapon(nSeries)
	local TabWeapon = {
		"Tr��ng Ki�m/getitem_level#"..nSeries.."#0",
		"��i �ao/getitem_level#"..nSeries.."#1",
		"C�n - B�ng/getitem_level#"..nSeries.."#2",
		"Th��nng - K�ch/getitem_level#"..nSeries.."#3",
		"Song Ch�y/getitem_level#"..nSeries.."#4",
		"Song �ao/getitem_level#"..nSeries.."#5",
		"Phi Ti�u/getitem_level#"..nSeries.."#6",
		"Phi �ao/getitem_level#"..nSeries.."#7",
		"T� Ti�n/getitem_level#"..nSeries.."#8",
		"Tr� l�i/"..GetLastDiagFunc().."",
		"R�i kh�i/no",}
	SayNew("",getn(TabWeapon),TabWeapon[1],TabWeapon[2],TabWeapon[3],TabWeapon[4],TabWeapon[5],TabWeapon[6],TabWeapon[7],TabWeapon[8],TabWeapon[9],TabWeapon[10])
end
function getitem_level(nSeries, nKindWeapon)
	local TabLevel = {
		"C�p 1/getitem_number#"..nSeries.."#"..nKindWeapon.."#1",
		"C�p 2/getitem_number#"..nSeries.."#"..nKindWeapon.."#2",
		"C�p 3/getitem_number#"..nSeries.."#"..nKindWeapon.."#3",
		"C�p 4/getitem_number#"..nSeries.."#"..nKindWeapon.."#4",
		"C�p 5/getitem_number#"..nSeries.."#"..nKindWeapon.."#5",
		"C�p 6/getitem_number#"..nSeries.."#"..nKindWeapon.."#6",
		"C�p 7/getitem_number#"..nSeries.."#"..nKindWeapon.."#7",
		"C�p 8/getitem_number#"..nSeries.."#"..nKindWeapon.."#8",
		"C�p 9/getitem_number#"..nSeries.."#"..nKindWeapon.."#9",
		"C�p 10/getitem_number#"..nSeries.."#"..nKindWeapon.."#10",
		"Tr� l�i/"..GetLastDiagFunc().."",
		"R�i kh�i/no",}
	SayNew("",getn(TabLevel),TabLevel)
end

function getitem_number(nSeries, nKindWeapon, nLevel)
OpenStrBox("Nh�p s� l��ng(c�i)", "getitem_success#"..nSeries.."#"..nKindWeapon.."#"..nLevel.."", 60)
end

function getitem_success(nSeries, nKindWeapon, nLevel)
	local nItemNumber = GetClientString()
	local nNumber = nKindWeapon
	local nKindWeapon = nKindWeapon - 6
	if (nNumber < 6) then
		for i = 1, nItemNumber do
		nIndex = AddItem(0, 0, nNumber, nLevel, nSeries, 100, 10)
			if (CheckPostion(nIndex) == 0) then
			Msg2Player(format("C�n �t nh�t 1 kho�ng tr�ng %dx%d trong t�i", GetWidthItem(nIndex), GetHeightItem(nIndex)))
			break;
			end
		end
	else
		for i = 1, nItemNumber do
		nIndex = AddItem(0, 1, nKindWeapon, nLevel, nSeries, 100, 10)
			if (CheckPostion(nIndex) == 0) then
			Msg2Player(format("C�n �t nh�t 1 kho�ng tr�ng %dx%d trong t�i", GetWidthItem(nIndex), GetHeightItem(nIndex)))
			break;
			end
		end
	end
end
