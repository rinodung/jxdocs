Include("\\script\\global\\serverlib.lua")
Include("\\script\\global\\tasklist.lua")
Include("\\script\\global\\map_helper.lua")


function logingame()
end


function OnDeath(IndexDeath, IndexKiller)
	local PlayerAtk = IndexKiller
	BeKilled = 0
	if (PlayerAtk > 0) then
		local AddPKnum = 1
		PlayerIndex = IndexDeath
		if (GetNormalPKState() == 0) then
		BeKilled = 1
		end
		PlayerIndex = PlayerAtk
		if (GetNormalPKState() == 2) then
		if (BeKilled == 1) then
		if (GetPK() < 10) then
		--SetPK(GetPK()+AddPKnum)
		SetTask(T_TimerPlayer,1)
		str = "<color=water>Ch�c n�ng<color>: B�n v�a b� <color=red>�� s�t<color> b�i ng��i ch�i <color=green>"..GetPlayerName().." <color>v�o <color=green>"..date().." !"
		end
		end
		else
		str = "<color=water>Ch�c n�ng<color>: B�n v�a b� h� s�t b�i ng��i ch�i <color=green>"..GetPlayerName().." <color>v�o <color=green>"..date().."!"
		end
	end
	PlayerIndex = IndexDeath
	AddNote(str)
end

system_message = {
"B�n v�n ch�a m� ch�c n�ng b�o h� v� m� r�ng r��ng. Xin h�y ��n Ba L�ng huy�n g�p Th�m C�u (188, 198) �� mua ch�c n�ng n�y.",
"Nh�m b�o v� t�i s�n cho b�n! V�t ph�m qu� kh�ng ���c t�y � v�t ra ngo�i",
"S� l��ng v�t ph�m kh�ng ��ng v�i y�u c�u ��a ra",
"Trang b� �� h� h�ng ho�n to�n kh�ng th� s�a ch�a b�ng ph��ng ph�p b�nh th��ng. Xin h�y ��n L�m An g�p th� r�n th�n b� ",
"Trang b� �� h� h�ng ho�n to�n kh�ng th� m�c. Xin h�y ��n L�m An g�p th� r�n th�n b� ",
"Kh�ng th� s� d�ng Th� ��a Ph� l�c n�y",
"Ngo�i hi�u c�a ng��i �� thay ��i",
"T�m th�i kh�ng th� thay ��i ngo�i hi�u",
}

function ChangeTitle(nId)
	if (GetChangeTitle() <= 0) then
		if (nId ~= GetTitleNumber()) then
			ChangePlayerTitle(nId)
			--PutMessageNew(0, 0, system_message[7])		
		end
	else
		PutMessageNew(0, 0, system_message[8])	
	end
end

function SystemMessage(nIdMessage)
	if (nIdMessage == 6) then
		PutMessageNew(2, 1, system_message[nIdMessage])
	else
		PutMessageNew(0, 0, system_message[nIdMessage])
	end
end

function ReportRemoveItem(nIndex)
PutMessageNew(0, 0, "H� th�ng x�a b� "..GetNameItem(nIndex).." h�t h�n")
luulog_itemlosttime(nIndex)
end

function ReportUnBindItem(nIndex)
PutMessageNew(0, 0, "Trang b� "..GetNameItem(nIndex).." �� m� kh�a b�o hi�m")
luulog_itemunbind(nIndex)
end

function ReleaseInfo(nPlayerIndex)
--Load func when someone player logout
--Msg2SubWorld("ReleaseInfo", " "..GetName().." leave game at "..date().."")
end

function CalcDamage(nDamageCause, nDamageReceived)
Msg2Player("S�t th��ng b�n th�n g�y ra", " "..nDamageCause.." �i�m")
Msg2Player("S�t th��ng b�n th�n nh�n v�o", " "..nDamageReceived.." �i�m")
end


function CreatTongSucces(IDItem)
DelQuestItem(IDItem)
end

function luulog_itemlosttime(nIndex)
	local szAccount = GetPlayerAccount()
	local szName = GetPlayerName()
	local szItemName = GetNameItem(nIndex)
	local log = "===================================================== Item Het Han  ========================================================\n"
	log = log..date("%H:%M:%S").."\tT�i kho�n: "..szAccount.."\t T�n: "..szName.."\n"
	log = log.."\t\t\tVat pham: "..szItemName.."\n"
	logWrite(log,"data/logitemhethan/"..GetPlayerName()..".txt")
end

function luulog_itemunbind(nIndex)
	local szAccount = GetPlayerAccount()
	local szName = GetPlayerName()
	local szItemName = GetNameItem(nIndex)
	local log = "===================================================== Item Da Thao  ========================================================\n"
	log = log..date("%H:%M:%S").."\tT�i kho�n: "..szAccount.."\t T�n: "..szName.."\n"
	log = log.."\t\t\tVat pham: "..szItemName.."\n"
	logWrite(log,"data/logdinhthao/logitemthao/"..GetPlayerName()..".txt")
end

function logWrite(str,link)
	local gm_Log = link
	local fs_log = openfile(gm_Log, "a");
	write(fs_log, str);
	closefile(fs_log);
end