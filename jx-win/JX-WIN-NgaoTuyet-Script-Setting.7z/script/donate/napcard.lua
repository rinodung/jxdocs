----============================================N�p Th� Online===========================================--
----------------------------------------------------------------------------------------------------------
--Script By Carot.
--Author : N�p Th�.
----------------------------------------------------------------------------------------------------------
--============================================================================================================

Include("\\script\\library\\worldlibrary.lua");
Include("\\script\\header\\taskid.lua");
Include("\\script\\global\\npcchucnang\\tientrang.lua");
Include("\\script\\donate\\danhsachcard.lua");

------------------------------------------------Load Dofile------------------------------------------------------
----------------------------------------------------------------------------------------------------------
function main()
dofile("script/donate/napcard.lua")
ActiveTBTN()
end

----------------------------------------------------------------------------------------------------------
function ActiveTBTN()
            Say2("<color=pink>Th�n S�:<color> <bclr=blue>V� Thi�u Hi�p ��y c� v� gi�u c� !",3,1,"",
             "N�p Th� Online./napthe",
             "��i Kim Nguy�n B�o./moshop",
             "Ta Ch� Nh�n Ti�n Gh� Qua Th�i!/no")
end

---------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
function napthe()
           Say("S� Serial: <color=red>"..GetTask(39).."<color>, M�t M�:  <color=red>"..GetTask(40).."",4,
             "Nh�p S� Serial./nhapseri",
             "Nh�p M�t M� Th�./nhapmathe",
             "Ti�n H�nh Ki�m Tra./napcard",
             "Th�i!Ta Kh�ng C� Ti�n./no")
end

---------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
function nhapseri()
SayEx({"<color=violet>S� Serial<color> : ","0/number","1/number","2/number","3/number","4/number","5/number","6/number","7/number","8/number","9/number"})
end
---------------------------------------------------------------------------------------------------------------
function number(nsel)
	if GetTaskTemp(13) <= 6 then
	SetTaskTemp(13,GetTaskTemp(13) + 1)
	callnumber(nsel)
        end
end;	
---------------------------------------------------------------------------------------------------------------
function callnumber(id)
	if GetTaskTemp(13) == 1 then
		SetTask(39,100000*id)
		Talk(1,"conta1","S� <color=violet>Serial<color> Th� 1 �� nh�p l�: <color=red>"..id.."")
	elseif GetTaskTemp(13) == 2 then
		SetTask(39,GetTask(39) + (10000*id))
		Talk(1,"conta1","S� <color=violet>Serial<color> Th� 2 �� nh�p l�: <color=red>"..id.."")
	elseif GetTaskTemp(13) == 3 then
		SetTask(39,GetTask(39) + (1000*id))
		Talk(1,"conta1","S� <color=violet>Serial<color> Th� 3 �� nh�p l�: <color=red>"..id.."")
	elseif GetTaskTemp(13) == 4 then
		SetTask(39,GetTask(39) + (100*id))
		Talk(1,"conta1","S� <color=violet>Serial<color> Th� 4 �� nh�p l�: <color=red>"..id.."")
	elseif GetTaskTemp(13) == 5 then
		SetTask(39,GetTask(39) + (10*id))
		Talk(1,"conta1","S� <color=violet>Serial<color> Th� 5 �� nh�p l�: <color=red>"..id.."")
	elseif GetTaskTemp(13) == 6 then
		SetTask(39,GetTask(39) + id)
		Talk(1,"Exita1","S� <color=violet>Serial<color> B�n �� nh�p l�: <bclr=blue>"..GetTask(39)..".")
	end
end;
---------------------------------------------------------------------------------------------------------------
function nhapmathe()
SayEx({"<color=violet>M�t M� Th� <color> : ","0/numbera1","1/numbera1","2/numbera1","3/numbera1","4/numbera1","5/numbera1","6/numbera1","7/numbera1","8/numbera1","9/numbera1"})
end
---------------------------------------------------------------------------------------------------------------
function numbera1(nsel)
	if GetTaskTemp(13) <= 6 then
	SetTaskTemp(13,GetTaskTemp(13) + 1)
	callnumbera1(nsel)
        end
end;
---------------------------------------------------------------------------------------------------------------
function Exita1()
SetTaskTemp(13,0)
end;

function callnumbera1(id)
	if GetTaskTemp(13) == 1 then
		SetTask(40,100000*id)
		Talk(1,"conti","S� <color=violet>M� Th� <color> Th� 1 �� nh�p l�: <color=red>"..id.."")
	elseif GetTaskTemp(13) == 2 then
		SetTask(40,GetTask(40) + (10000*id))
		Talk(1,"conti","S� <color=violet>M� Th� <color> Th� 2 �� nh�p l�: <color=red>"..id.."")
	elseif GetTaskTemp(13) == 3 then
		SetTask(40,GetTask(40) + (1000*id))
		Talk(1,"conti","S� <color=violet>M� Th� <color> Th� 3 �� nh�p l�: <color=red>"..id.."")
	elseif GetTaskTemp(13) == 4 then
		SetTask(40,GetTask(40) + (100*id))
		Talk(1,"conti","S� <color=violet>M� Th� <color> Th� 4 �� nh�p l�: <color=red>"..id.."")
	elseif GetTaskTemp(13) == 5 then
		SetTask(40,GetTask(40) + (10*id))
		Talk(1,"conti","S� <color=violet>M� Th� <color> Th� 5 �� nh�p l�: <color=red>"..id.."")
	elseif GetTaskTemp(13) == 6 then
		SetTask(40,GetTask(40) + id)
		Talk(1,"Exita1","<color=violet>M� Th� <color> B�n �� nh�p l�: <bclr=blue>"..GetTask(40)..".")
	end
end;	
---------------------------------------------------------------------------------------------------------------	

function conta1()
		SayEx({"<color=violet>Serial<color> : �i�n Serial.","0/number","1/number","2/number","3/number","4/number","5/number","6/number","7/number","8/number","9/number"})
end;

function conti()
		SayEx({"<color=violet>M� Th�<color> : �i�n m�t m�.","0/numbera1","1/numbera1","2/numbera1","3/numbera1","4/numbera1","5/numbera1","6/numbera1","7/numbera1","8/numbera1","9/numbera1"})
end;

---------------------------------------------------------------------------------------------------------------
function check()
         for k=1,getn(VANG) do
         if GetUUID() == VANG[k][3] then
         return k
         end
     end
end

---------------------------------------------------------------------------------------------------------------
function napcard()
        for i=1,getn(NAP_CARD) do
	        if GetTask(39) == NAP_CARD[i][2] then
        	if GetTask(40) == NAP_CARD[i][3] then
        	if NAP_CARD[i][1] == 0 then
        	Talk(1,"","<color=violet>Th� n�y �� ���c s� d�ng r�i !")
        	else
                SetTask(41,NAP_CARD[i][4])
                thoigian = tonumber(date("%H%M%d%m"))
                vatpham()
                NAP_CARD[i][1] = 0
                NAP_CARD[i][2] = GetName()
                NAP_CARD[i][3] = thoigian 
                BANG2 = TaoBang(NAP_CARD,"NAP_CARD")
                LuuBang("script/donate/danhsachcard.lua",BANG2)
                Talk(1,"","Ch�c m�ng b�n �� nh�n ���c: <color=red>"..tenvatpham().."")
                Msg2Player("<color=violet>�� Nh�p D� Li�u V�o H� Th�ng!")
                end
            end 
        end
    end 
end

--==============================================***V�t Ph�m***=================================================----
function tenvatpham()
          if GetTask(41) == 10 then --(Task 41,10 = Th� 10k vn�)
          return "Kim Nguy�n B�o"
          elseif GetTask(41) == 20 then --(Task 41,20 = Th� 20k vn�)
          return "Kim Nguy�n B�o"
          elseif GetTask(41) == 50 then --(Task 41,50 = Th� 50k vn�)
          return "Kim Nguy�n B�o"
	  elseif GetTask(41) == 100 then --(Task 41,100 = Th� 100k vn�)
          return "Kim Nguy�n B�o"
          elseif GetTask(41) == 200 then --(Task 41,200 = Th� 200k vn�)
          return "Kim Nguy�n B�o"
          elseif GetTask(41) == 300 then --(Task 41,300 = Th� 300k vn�)
          return "Kim Nguy�n B�o"
          elseif GetTask(41) == 500 then --(Task 41,500 = Th� 500k vn�)
          return "Kim Nguy�n B�o"
          end
end

--==================================================***KNB***===========================================
function vatpham()
        if GetTask(41) == 10 then --(Task 41,10 = Th� 10k vn�)
        AddItem(0,3,17,0,0,5,0,0)--KNB
        SetTask(196,1000)
        elseif GetTask(41) == 20 then --(Task 41,20 = Th� 20k vn�)
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        SetTask(196,2000)
        elseif GetTask(41) == 50 then --(Task 41,50 = Th� 50k vn�)
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB        
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        SetTask(196,3000)
        elseif GetTask(41) == 100 then --(Task 41,100 = Th� 100k vn�)
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB        
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        SetTask(196,4000)
        elseif GetTask(41) == 200 then --(Task 41,200 = Th� 200k vn�)
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB        
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB 12
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB        
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        SetTask(196,5000)
        elseif GetTask(41) == 300 then --(Task 41,300 = Th� 300k vn�)
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB        
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB 12
        AddItem(0,3,17,0,0,5,0,0)--KNB 
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB        
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB 12
        AddItem(0,3,17,0,0,5,0,0)--KNB 
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB        
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        SetTask(196,6000)
        elseif GetTask(41) == 300 then --(Task 41,300 = Th� 300k vn�)
        AddItem(0,3,17,0,0,5,0,0)--KNB 
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB        
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB 
        AddItem(0,3,17,0,0,5,0,0)--KNB 12
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB        
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB 
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB 12
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB        
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB 
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB 12
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB        
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB 
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB 12
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB        
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        AddItem(0,3,17,0,0,5,0,0)--KNB
        SetTask(196,7000)
Talk(1,"","Ch� C� M�nh Gi� GiftCode 20k-50k-100k-200k-300k-500k vn�")
end
end
	
----------------------------------------------------------------------------------------------------------
function no()
end;
-----------------------------------------------***END***--------------------------------------------------
----------------------------------------------------------------------------------------------------------
--========================================================================================================
