--script khi player dang nhap
--author: Ken Nguyen
--Include("\\script\\library\\worldlibrary.lua");
Include("\\script\\header\\taskid.lua");
--Chia lay so du: (a/b - floor(a/b))*b

function main()
	Yr,Mth,Dy,Hr,Mn,Se = GetTime();
--	local nNam = GetTask(TASK_NAM) + 2000;
	local nNam = GetTask(TASK_NAM) ;
	local nThang = GetTask(TASK_THANG)
	local nNgay = GetTask(TASK_NGAY)
	if(nNam ~= Yr or nThang ~= Mth or nNgay ~= Dy) then --reset 1 ngay moi
		SetTask(TASK_NAM,Yr);
		SetTask(TASK_THANG,Mth);
		SetTask(TASK_NGAY,Dy);
		--reset task can thiet tai day
		SetTask(TASK_RESET,0);
		SetTask(TASK_RESET2,0);
		SetTask(TASK_DATCUOC4, 0);
		SetTask(TASK_DATCUOC5, 0);
		SetTask(TASK_DATCUOC6, 0);
	end
	local nAuraT = GetTask(TASK_THOIGIAN4);
	if(nAuraT > 0) then
		local nCurTime = GetTimeMin();
		if(nCurTime - nAuraT > 0) then
		SetTask(TASK_THOIGIAN4, 0);
		SetRankEx(0,1);
		end
	end
	local nTTLTime = GetTask(TASK_TIENTHAOLO)
	if(nTTLTime > 0) then
		AddSkillState(440, 1, nTTLTime);
	end
	nTTLTime = GetTask(TASK_THIENSONBAOLO)
	if(nTTLTime > 0) then
		AddSkillState(441, 1, nTTLTime*1080);
	end
	nTTLTime = GetTask(TASK_QUEHOATUU)
	if(nTTLTime > 0) then
		AddSkillState(450, 1, nTTLTime*1080);
	end
	DelMagic(1486);
	Msg2Player("Ch�o M�ng C�c H� ��n V�i :<bclr=white><color=red>             V� L�m Tuy�t S�n Phi H�  ")
	Msg2Player("<color=yellow>Admin kh�ng c� trong Game.M�i li�n h� qua Yahoo :<bclr=blue>   hotro_thonghonpro    <bclr><color=yellow>        Kh�ng PM trong game ! Tr�nh b� l�a ��o !")
        Msg2Player("<color=green> Server Online b�n v�t ph�m t�i   NPC K� Tr�n C�c t�i Ba L�ng Huy�n .Ch� s� d�ng <color=red>Ti�n ��ng<color><color=green> �� mua B�o V�t !")
	Msg2Player("<color=violet>Ch�c c�c b�n vui vώ !  BQT .<color>")


end;
