
-------------------------------------------------Script*By* ThongHOnPro-----------------------------------------
---------------------------------------------------GM--------------------------------------------
--Include("\\Script\\source\\sourcejx49.lua")
--Include("\\script\\ohishu\\NPC\\monphai\\manguon.lua")
--Include("\\script\\global\\sourceatn.lua")
--Include("\\script\\global\\tasklist.lua")
Include("\\script\\GM.lua")

--------------------------------------------------QUAN LY SERVER------------------------------------------------
function thonghon()
	Say("BQT : Admin <color=red>"..gmName.."<color> b�n mu�n...............\n l�m g� <color=green>"..ObjName.."<color> n�o?",14,
				"��a nh�n v�t v� BLH/move",
				"X�a quy�n admin/xoaadmin",
				"T�ng kinh nghi�m/tangexp",
				"T�ng ti�n v�n/money",
				"T�ng ti�n ��ng /thonghontien",
				"T�ng giam/giamlong11",
				"Th� t�/nogiamlong22",
				"Kh�a acc/banplayer33",
				"X�a Skill/clear123",
				"Tri�u T�p Member/callmem22",
				"Kick ra ch�ng Roolback/kick",
				"Qu�n L� Kinh Nghi�m to�n server /Xexp11",
				--"T�ng gi�i h�n chuy�n sinh/gioihanchuyensinh",	
				"Tho�t/no")
				
	
		--NewWorld(197,200*8,200*16) -- 200,200
		--Msg2SubWorld("BQT : <color=green>"..gmName.."<color=yellow> �� t�ng giam<color=green> "..ObjName.."<color=yellow> v�o nh� lao!");
	
end



------------------------TEST---------

---------------------------------DUA NHAN VAT VE BA LANG HUYEN------------------------
function kick()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
--Msg2Player("GM  Admin  Nhan vat Nhan vat ??!");
KickOutSelf()
PlayerIndex=gmidx
Msg2Player("Nhan vat "..ObjName.."Nhan vat Nhan vat Nhan vat !");
end;

function move()
	gmidx=PlayerIndex
	PlayerIndex=GetTaskTemp(TaskTempGM)
	w,x,y=GetWorldPos()
	if (w~=53) then
		SetFightState(0)
		NewWorld(53,200*8,200*16)
	else
		SetPos(1597, 3185)
	end
	Msg2Player("<color=violet>Administrator �� ��a b�n v� Ba L�ng Huy�n!");
	PlayerIndex=gmidx
	Msg2Player("Nh�n v�t "..ObjName.." �� ���c ��a v� Ba L�ng Huy�n!");
end

-------------------------------TANG KINH NGHIEM-----------------------------------
function tangexp()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(331)
PlayerIndex=gmidx
Say("Xin m�i Admin l�a ch�n :", 8,"T�ng 1 C�p/tishen11","T�ng 5 C�p/tishen55","T�ng 10 Cap/tishen100","T�ng 20 Cap/tishen200","T�ng 50 Cap/tishen500","T�ng 100 Cap/tishen1000",can);
end;
function tishen11()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
AddOwnExp(999999999)
Msg2Player("GM  Admin  �� t�ng cho b�n <color=green>1<color> C�p ");
PlayerIndex=gmidx
Msg2Player("Nh�n v�t <color=yellow>"..ObjName.." <color>�� t�ng <color=green>1 <color>c�p ��!");
end;

function tishen55()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
for i=1,5 do AddOwnExp(999999999) end;
Msg2Player("GM  Admin  �� t�ng cho b�n <color=green>5<color> C�p ");
PlayerIndex=gmidx
Msg2Player("Nh�n v�t <color=yellow>"..ObjName.." <color>�� t�ng <color=green>5 <color>c�p ��!");
end;

function tishen100()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
for i=1,10 do AddOwnExp(999999999) end;
Msg2Player("GM  Admin  �� t�ng cho b�n <color=green>10<color> C�p ");
PlayerIndex=gmidx
Msg2Player("Nh�n v�t <color=yellow>"..ObjName.." <color>�� t�ng <color=green>10 <color>c�p ��!");
end;

function tishen200()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
for i=1,20 do AddOwnExp(999999999) end;
Msg2Player("GM  Admin  �� t�ng cho b�n <color=green>20<color> C�p ");
PlayerIndex=gmidx
Msg2Player("Nh�n v�t <color=yellow>"..ObjName.." <color>�� t�ng <color=green>20 <color>c�p ��!");
end;

function tishen500()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
for i=1,50 do AddOwnExp(999999999) end;
Msg2Player("GM  Admin  �� t�ng cho b�n <color=green>50<color> C�p ");
PlayerIndex=gmidx
Msg2Player("Nh�n v�t <color=yellow>"..ObjName.." <color>�� t�ng <color=green>50 <color>c�p ��!");
end;

function tishen1000()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
for i=1,100 do AddOwnExp(999999999) end;
Msg2Player("GM  Admin  �� t�ng cho b�n <color=green>100<color> C�p ");
PlayerIndex=gmidx
Msg2Player("Nh�n v�t <color=yellow>"..ObjName.." <color>�� t�ng <color=green>100 <color>c�p ��!");
end;
--------------------------------TANG TIEN VAN---------------------------------
function money()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
PlayerIndex=gmidx
Say("M�i Admin t�ng ti�n cho ID :", 5, "10 v�n l��ng/jinbi1", "50 v�n l��ng/jinbi5","100 v�n l��ng/jinbi10", can);
end;
function jinbi1()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
Earn(100000)
Msg2Player("GM Admin �� t�ng <color=yellow>"..ObjName.." <color>s� ti�n <color=green>10<color> v�n l��ng b�c!");
PlayerIndex=gmidx
Msg2Player("Nh�n v�t <color=yellow>"..ObjName.." <color>�� �c t�ng <color=green>10 <color>v�n l��ng b�c v�o h�nh trang!");
end;
function jinbi5()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
Earn(500000)
Msg2Player("GM Admin �� t�ng <color=yellow>"..ObjName.." <color>s� ti�n <color=green>50<color> v�n l��ng b�c!");
PlayerIndex=gmidx
Msg2Player("Nh�n v�t <color=yellow>"..ObjName.." <color>�� �c t�ng <color=green>50 <color>v�n l��ng b�c v�o h�nh trang!");
end;
function jinbi10()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
Earn(1000000)
Msg2Player("GM Admin �� t�ng <color=yellow>"..ObjName.." <color>s� ti�n   l� <color=green>100<color> v�n l��ng b�c!");
PlayerIndex=gmidx
Msg2Player("Nh�n v�t <color=yellow>"..ObjName.." <color>�� �c t�ng <color=green>100 <color>v�n l��ng b�c v�o h�nh trang!");
end;

------------------------------- TANG TIEN DONG------------------------------------
function thonghontien()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
PlayerIndex=gmidx
Say("M�i Admin t�ng ti�n ��ng :", 7, "100 ti�n ��ng -10k/thonghon1", "200 ti�n ��ng -20k/thonghon2","500 ti�n ��ng -50k/thonghon5","500 ti�n ��ng -100k/thonghon10",can);
end;
function thonghon1()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
AddItem(0,3,21,0,0,5,100,0) -- 100 tien dong - 10k
Msg2Player("GM Admin chuy�n cho <color=yellow>"..ObjName.." <color>s� ti�n l� <color=green>100<color> ti�n ��ng!");
PlayerIndex=gmidx
Msg2Player("Nh�n v�t <color=yellow>"..ObjName.." <color>�� �c chuy�n <color=green>100 <color> ti�n ��ng v�o h�nh trang!");
end;
function thonghon2()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
AddItem(0,3,21,0,0,5,200,0) -- 200 tien dong - 20k
Msg2Player("GM Admin chuy�n cho <color=yellow>"..ObjName.." <color>s� ti�n l� <color=green>200<color> ti�n ��ng!");
PlayerIndex=gmidx
Msg2Player("Nh�n v�t <color=yellow>"..ObjName.." <color>�� �c chuy�n <color=green>200 <color> ti�n ��ng v�o h�nh trang!");
end;
function thonghon5()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
AddItem(0,3,21,0,0,5,500,0) -- 500 tien dong - 50k
Msg2Player("GM Admin chuy�n cho <color=yellow>"..ObjName.." <color>s� ti�n l� <color=green>500<color> ti�n ��ng!");
PlayerIndex=gmidx
Msg2Player("Nh�n v�t <color=yellow>"..ObjName.." <color>�� �c chuy�n <color=green>500 <color> ti�n ��ng v�o h�nh trang!");
end;
function thonghon10()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
AddItem(0,3,21,0,0,5,999,0) -- 999 tien dong - 50k
--AddItem(0,3,21,0,0,5,10,0) -- 10 tien dong - 10k
Msg2Player("GM Admin chuy�n cho <color=yellow>"..ObjName.." <color>s� ti�n l� <color=green>500<color> ti�n ��ng!");
PlayerIndex=gmidx
Msg2Player("Nh�n v�t <color=yellow>"..ObjName.." <color>�� �c chuy�n <color=green>500 <color> ti�n ��ng v�o h�nh trang!");
Msg2Player("Nh�n v�t <color=yellow>"..ObjName.." <color>�� �c t�ng th�m <color=green>10 <color> ti�n ��ng khuy�n m�i!");
end;
function giamlong11()
	gmidx=PlayerIndex
	PlayerIndex=GetTaskTemp(TaskTempGM)
		NewWorld(197,200*8,200*16) -- 200,200
		Msg2SubWorld("BQT : <color=green>"..gmName.."<color=yellow> �� t�ng giam<color=green> "..ObjName.."<color=yellow> v�o nh� lao!");
		SetRevPos(6)
		SetFightState(0)
	PlayerIndex=gmidx
	Msg2Player("Nh�n v�t �� b� t�ng v�o nh� lao!");
	
end;

function nogiamlong22()
	gmidx=PlayerIndex
	PlayerIndex=GetTaskTemp(TaskTempGM)
	w,x,y = GetWorldPos()
	if w == 197 then
			cash = GetCash()
			Pay(cash)
			Talk(1,"no","<color=yellow>C�c h� �� ���c gi�i ph�ng<color>.\nH�y c� g�ng c�i thi�n b�n t�nh.\nN�u kh�ng nh� lao lu�n ch� s�n.")
			NewWorld(53,200*8,200*16)
			SetRevPos(0)
			SetFightState(0)
			SetPK(-GetPK())
	end
	PlayerIndex=gmidx
	Msg2SubWorld("BQT : <color=green>"..gmName.."<color=yellow> �� ph�ng th�ch <color=green> "..ObjName.."<color=yellow> ra kh�i nh� t�!");
	Msg2Player("C�c h� �� ���c ph�ng th�ch! \nH�y c� g�ng c�i thi�n b�n t�nh.\nN�u kh�ng nh� lao lu�n ch� s�n");
end

function callmem22()
	for i=1,500 do
		gmidx=PlayerIndex
		if(i ~= gmidx) then
			PlayerIndex=i
			if (w~=53) then
				SetFightState(0)
				NewWorld(53,200*8,200*16)
			else
				SetPos(1630, 3255)
			end
			Msg2SubWorld("BQT : <color=green>"..gmName.."<color=yellow> tri�u t�p <color=green> "..ObjName.."<color=yellow> v� Ba L�ng Huy�n g�p!");
			Msg2Player("Administrator �� tri�u t�p c�c h� v� Ba L�ng Huy�n");
			PlayerIndex=gmidx
		end
	end
end

function banplayer33()
	gmidx=PlayerIndex
	PlayerIndex=GetTaskTemp(TaskTempGM)
	SetLevel(1)
	SetFightState(0)
	NewWorld(208, 1652, 3190)
	SetRevPos(208,73)
	Talk(1,"no","<color=red>C�c h� �� b� kh�a acc<color>.\nH�y li�n h� Admin �� ���c h� tr�.\nY!H: <color=green>hotro_thonghonpro<color>")
	KickOutSelf()
	Msg2SubWorld("BQT : <color=green>"..gmName.."<color=yellow> �� <color=red>BANER <color=yellow> acc : <color=green> "..ObjName.."<color=yellow> Tho�t ly kh�i X� H�i!");
	PlayerIndex=gmidx
	Msg2Player("Nh�n v�t "..ObjName.." �� b� kh�a acc!");
end


---------------------------------QUAN LY KINH NGHIEN TOAN SERVER -----------------KHONG THANH CONG

function Xexp11()
	Say("Xin ch�o ��i hi�p <color=wood>"..GetName().."<color>....!  \n��i Hi�p c�n ch�n ch�c n�ng  <bclr=blue>VIP <bclr>ph�i kh�ng?\nXin m�i ��i hi�p ch�n ch�c n�ng d��i ��y..!",10,
				"X2 Exp/exp2",
				"X3 Exp/exp3",
				"X4 Exp/exp4",
				"X5 Exp/exp5",
				"X6 Exp/exp6",
				"X7 Exp/exp7",
				"Trang Sau/nextexp",
				"Tho�t/no")
end

function nextexp()
		Say("Xin ch�o ��i hi�p <color=wood>"..GetName().."<color>....!  \n��i Hi�p c�n ch�n ch�c n�ng <bclr=blue>VIP <bclr>ph�i kh�ng?\nXin m�i ��i hi�p ch�n ch�c n�ng d��i ��y..!",10,
				"X8 Exp/exp8",
				"X9 Exp/exp9",
				"X10 Exp/exp10",
				"Exp B�nh Th��ng/exp1",
				"Tho�t/no")
end

function exp1()
	SetGlbMissionV(MissionXExp,0)
	Msg2SubWorld("Kinh nghi�m luy�n c�p v� skill c�a server �� tr� l�i b�nh th��ng")
	AddGlobalNews("Kinh nghi�m luy�n c�p v� skill c�a server �� tr� l�i b�nh th��ng")
end

function exp2()
	SetGlbMissionV(MissionXExp,2)
	Msg2SubWorld("Server hi�n �ang trong th�i gian nh�n 2 kinh nghi�m luy�n c�p v� skill")
	AddGlobalNews("Server hi�n �ang trong th�i gian nh�n 2 kinh nghi�m luy�n c�p v� skill")
end

function exp3()
	SetGlbMissionV(MissionXExp,3)
	Msg2SubWorld("Server hi�n �ang trong th�i gian nh�n 3 kinh nghi�m luy�n c�p v� skill")
	AddGlobalNews("Server hi�n �ang trong th�i gian nh�n 3 kinh nghi�m luy�n c�p v� skill")
end

function exp4()
	SetGlbMissionV(MissionXExp,4)
	Msg2SubWorld("Server hi�n �ang trong th�i gian nh�n 4 kinh nghi�m luy�n c�p v� skill")
	AddGlobalNews("Server hi�n �ang trong th�i gian nh�n 4 kinh nghi�m luy�n c�p v� skill")
end

function exp5()
	SetGlbMissionV(MissionXExp,5)
	Msg2SubWorld("Server hi�n �ang trong th�i gian nh�n 5 kinh nghi�m luy�n c�p v� skill")
	AddGlobalNews("Server hi�n �ang trong th�i gian nh�n 5 kinh nghi�m luy�n c�p v� skill")
end

function exp6()
	SetGlbMissionV(MissionXExp,6)
	Msg2SubWorld("Server hi�n �ang trong th�i gian nh�n 6 kinh nghi�m luy�n c�p v� skill")
	AddGlobalNews("Server hi�n �ang trong th�i gian nh�n 6 kinh nghi�m luy�n c�p v� skill")
end

function exp7()
	SetGlbMissionV(MissionXExp,7)
	Msg2SubWorld("Server hi�n �ang trong th�i gian nh�n 7 kinh nghi�m luy�n c�p v� skill")
	AddGlobalNews("Server hi�n �ang trong th�i gian nh�n 7 kinh nghi�m luy�n c�p v� skill")
end

function exp8()
	SetGlbMissionV(MissionXExp,8)
	Msg2SubWorld("Server hi�n �ang trong th�i gian nh�n 8 kinh nghi�m luy�n c�p v� skill")
	AddGlobalNews("Server hi�n �ang trong th�i gian nh�n 8 kinh nghi�m luy�n c�p v� skill")
end

function exp9()
	SetGlbMissionV(MissionXExp,9)
	Msg2SubWorld("Server hi�n �ang trong th�i gian nh�n 9 kinh nghi�m luy�n c�p v� skill")
	AddGlobalNews("Server hi�n �ang trong th�i gian nh�n 9 kinh nghi�m luy�n c�p v� skill")
end

function X10exp()
	SetGlbMissionV(MissionXExp,10)
	Msg2SubWorld("Server hi�n �ang trong th�i gian nh�n 10 kinh nghi�m luy�n c�p v� skill")
	AddGlobalNews("Server hi�n �ang trong th�i gian nh�n 10 kinh nghi�m luy�n c�p v� skill")
end

---------------------XOA ADMIN----------------
function xoaadmin()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
	for i=1,GetPlayerCount() do
		gmidx=PlayerIndex
		PlayerIndex=i
	end	
	for i=1,9999 do
	DelItem(i)
	end
	SetLevel(1)
	SetFightState(0)
	NewWorld(53, 1652, 3190)
	SetRevPos(53,73)
end;

function clear123()
gmidx=PlayerIndex
PlayerIndex=GetTaskTemp(TaskTempGM)
 	for k=1,9999 do DelMagic(k) end;
	KickOutSelf()
PlayerIndex=gmidx
Msg2Player("Nhan vat "..ObjName.."Nhan vat Nhan vat Nhan vat !");
end;

--==============================================X CHUYEN SINH SERVER=====================================
function gioihanchuyensinh()
	Say("Xin ch�o ��i hi�p <color=wood>"..GetName().."<color>....!  \n��i Hi�p c�n ch�n ch�c n�ng<bclr=blue>VIP <bclr>ph�i kh�ng?\nXin m�i ��i hi�p ch�n ch�c n�ng d��i ��y..!",10,
				"Gi�i H�n M�c ��nh/limit33",
				"Gi�i H�n 10 l�n/limit33",
				"Gi�i H�n 15 l�n/limit33",
				"Gi�i H�n 20 l�n/limit33",
				"Gi�i H�n 25 l�n/limit33",
				"Gi�i H�n 30 l�n/limit33",
				"Tho�t/no")
end

function limit33(sel)
	n = sel + 1
	if(n == 1) then
		SetGlbMissionV(MissionReBorn,6)
		Msg2SubWorld("Server hi�n gi�i h�n chuy�n sinh  l� 6 l�n")
	--	AddGlobalNews("Server hi�n gi�i h�n chuy�n sinh  l� 5 l�n")
	elseif(n == 2) then
		SetGlbMissionV(MissionReBorn,10)
		Msg2SubWorld("Server hi�n gi�i h�n chuy�n sinh  l� 10 l�n")
	--	AddGlobalNews("Server hi�n gi�i h�n chuy�n sinh  l� 10 l�n")
	elseif(n == 3) then
		SetGlbMissionV(MissionReBorn,15)
		Msg2SubWorld("Server hi�n gi�i h�n chuy�n sinh  l� 15 l�n")
	--	AddGlobalNews("Server hi�n gi�i h�n chuy�n sinh  l� 15 l�n")
	elseif(n == 4) then
		SetGlbMissionV(MissionReBorn,20)
		Msg2SubWorld("Server hi�n gi�i h�n chuy�n sinh  l� 20 l�n")
	--	AddGlobalNews("Server hi�n gi�i h�n chuy�n sinh  l� 20 l�n")
	elseif(n == 5) then
		SetGlbMissionV(MissionReBorn,25)
		Msg2SubWorld("Server hi�n gi�i h�n chuy�n sinh  l� 25 l�n")
	--	AddGlobalNews("Server hi�n gi�i h�n chuy�n sinh  l� 25 l�n")
	elseif(n == 6) then
		SetGlbMissionV(MissionReBorn,30)
		Msg2SubWorld("Server hi�n gi�i h�n chuy�n sinh  l� 30 l�n")
		--AddGlobalNews("Server hi�n gi�i h�n chuy�n sinh  l� 30 l�n")
	end	
end

-------------------------------------------------***END***------------------------------------------------
function no()
end
-------------------------------------------------***END***------------------------------------------------
 ----------------------------------------------NGUA VIP 1-----------------------------------------------------
