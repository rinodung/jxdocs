--2 thang thieu lam hoa son
--Author: Ken Nguyen 2013
--DMEM TEAM

function main(NpcIndex)
	Talk(1,"",12295)
end;
