--dao nhan que
--Author: Ken Nguyen 2014
--DMEM Entertainment

function main(NpcIndex)
	Say(12138,2,
	"T�m hi�u c�ch luy�n k� n�ng 120/timhieu120",
	"��ng/no")
end;

function timhieu120()
	Talk(1,"",10341)
end;

function no()
end;
