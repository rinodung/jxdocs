--hoa son lao tau
--Author: Ken Nguyen 2013
--DMEM TEAM

function main(NpcIndex)
	Talk(1,"",10544)
end;
