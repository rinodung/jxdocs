--Script by carot.
-- Chi�u H�i NPC Kim.
--========================================================================================================--
Include("\\script\\header\\taskid.lua");
Include("\\script\\header\\time.lua");
Include("\\script\\header\\tongkim.lua");
Include("\\script\\library\\worldlibrary.lua");
Include( "\\script\\item\\checkmapid.lua" )
Include("\\script\\header\\monphaiheader.lua");
Include("\\script\\feature\\tongkim\\drop.lua");

function useitem(nItemIdx)
	if (GetFightState() == 0) then
		Talk(1,"","<color=violet>Kh�ng th� s� d�ng trong t�nh tr�ng phi chi�n ��u!")
		return
	end;
		if(CheckMap() == 0) then
	return end;
	Msg2Player("<color=violet>Kim Ti�u T�c �� xu�t hi�n gi�p b�n...");
	local w,x,y = GetWorldPos();
	local nRand = RANDOM(1921,1921);
	local id = AddNpc(nRand,1,SubWorldID2Idx(w),x,y,0);
        SetNpcName(id, "Kim Ti�u T�c")	--��t t�n cho qu�i
	SetNpcScript(id, "\\script\\global\\lastdamage\\kimbinh.lua");
        SetNpcDropScript(id, "\\script\\feature\\tongkim\\drop.lua");
        SetNpcSer(id, "555")--Ng� H�nh
	SetNpcLifeTime(id,1200);--time boss
	RemoveItem(nItemIdx,1);
end
