--Script by carot.
-- SoCOLA loai 3.
function useitem(nItemIndex)
	if (CheckRoom(2,3) == 0) then
		Talk(1,"","Xin s�p x�p h�nh trang 2x3 �!")
	return end
	vatpham();
	AddOwnExp(10000000)
	RemoveItem(nItemIndex,1,1)
end;

ENAM = 2025
ETHANG = 1
ENGAY = 1

function vatpham()
	local nRand = RANDOM(700);
	if(nRand == 399) then
		AddItem(0,4,RANDOM(72,79),0,0,5,0,0)
	elseif(nRand == 299) then
		AddItem(0,5,RANDOM(71,73),0,0,0,5,0)
	elseif(nRand == 199) then
		AddItem(0,5,1,0,0,5,0,0)
	elseif(nRand == 99) then
		AddItem(0,5,RANDOM(56,60),0,0,0,5,0)
	elseif(nRand == 9) then
		local nIndex = ItemSetAdd(0,2,RANDOM(53,55),0,0,5,0,0)	
		SetItemDate(nIndex, ENAM,ETHANG,ENGAY,0,0);
		AddItemID(nIndex);
	elseif(nRand < 150) then
		AddItem(0,2,random(0,2),0,0,5,2,0)
	elseif(nRand < 200) then
		local nIndex = ItemSetAdd(0,2,3,0,0,5,1,0)
		SetItemDate(nIndex, ENAM,ETHANG,ENGAY,0,0);
		AddItemID(nIndex);
	elseif(nRand < 300) then
		local nIndex = ItemSetAdd(0,3,34,0,0,5,1,0)
		SetItemDate(nIndex, ENAM,ETHANG,ENGAY,0,0);
		AddItemID(nIndex);
	elseif(nRand < 400) then
		AddItem(0,3,0,0,random(5,10),5,2,0)
	elseif(nRand < 450) then
		local nIndex = ItemSetAdd(0,3,27,0,0,0,1,0)
		SetItemDate(nIndex, ENAM,ETHANG,ENGAY,0,0);
		AddItemID(nIndex);
	elseif(nRand < 500) then
		local nIndex = ItemSetAdd(0,2,56,0,0,5,1,0)
		SetItemDate(nIndex, ENAM,ETHANG,ENGAY,0,0);
		AddItemID(nIndex);
	end
end
