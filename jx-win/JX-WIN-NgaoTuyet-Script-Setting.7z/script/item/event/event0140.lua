--Script by Carot.
--T�i T�nh Nh�n Nh�.

function useitem(nItemIdx)
	if(CheckRoom(2,1) == 1) then
		local nid = ItemSetAdd(0,5,135,0,0,0,50,0);
		AddItemID(nid);
		RemoveItem(nItemIdx,1);
	else
		Talk(1,"","B�n nh�n ���c 50 c�i <color=yellow> s�c�la Lo�i 1");
	end
end;
