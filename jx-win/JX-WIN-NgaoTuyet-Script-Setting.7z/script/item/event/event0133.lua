--Script By carot.
-- C�m Nang MP L�nh.

function useitem(nItemIdx)
	if(CheckRoom(2,1) == 1) then
	nIndex = ItemSetAdd(0,5,134,0,0,5,0);--tho dia phu
	if(nIndex > 0) then
		LockItem(nIndex)--khoa bao hiem vinh vien
		SetItemDate(nIndex,43200)
		AddItemID(nIndex)
		RemoveItem(nItemIdx,1);
        end
	else
		Talk(1,"","Kh�ng �� ch� ch�ng,xin c�c h� s�p x�p l�i h�nh trang.");
	end
end;
