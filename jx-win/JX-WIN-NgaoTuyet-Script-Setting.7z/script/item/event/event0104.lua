--Script by Carot.
--hat gi�ng ho�ng kim.

Include( "\\script\\item\\checkmapid.lua" )
function useitem(nItemIdx)
	if(CheckMapForTP() > 1) then
	Msg2Player("<color=yeloow>N�i ��y kh�ng th�ch h�p �� tr�ng c�y!")
	return end;
	Msg2Player("<color=yeloow> B�n �� tr�ng ���c 1 c�y Mai Thi�n Di�p.");
	local w,x,y = GetWorldPos();
	local nRand = RANDOM(1334,1334);
	local id = AddNpc(nRand,1,SubWorldID2Idx(w),x,y,0);
	SetNpcCurCamp(id, 5);
	SetNpcScript(id, "\\script\\global\\lastdamage\\death_hat.lua");
	SetNpcLifeTime(id,32400);
        SetNpcName(id, "Mai Thi�n Di�p")	--��t t�n cho qu�i
        SetNpcDropScript(id, "\\script\\global\\droprate\\drop_hat.lua");
        SetNpcSer(id, "555")--Ng� H�nh
	SetNpcLifeTime(id,32400);--time boss
	RemoveItem(nItemIdx,1);
	if(nRand == 1334) then
	AddOwnExp(10000000)
	AddCountNews2("<bclr=white><color=red> Ch�c m�ng "..GetName().." �� tr�ng ���c Mai Thi�n Di�p",3);
	else
	AddOwnExp(50000000)
	end
end
