-- Script by Carot.
--HV b�o ch�u.

Include("\\script\\header\\trangbi.lua");
Include("\\script\\item\\questkey0064.lua");

function useitem(nItemIndex)
	if (CheckRoom(2,3) == 0) then
		Talk(1,"","Xin s�p x�p h�nh trang 5x8 �!")
	return end
	vatpham();
	RemoveItem(nItemIndex,1,1)
end;

function vatpham()
	Say("M�i c� <color=wood>"..GetName().."<color> ch�n trang b�...",2,
	"Ch�n  B� Trang B� Huy�n Vi�n ./huyenvien",
	"Ta kh�ng th�m cho ng��i lu�n ./no")
end

function no()
end;
