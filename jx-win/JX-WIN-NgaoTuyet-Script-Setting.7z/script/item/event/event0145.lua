--Script *By *CaRot
--Ng�i Sao May M�n.

Include("\\script\\header\\taskid.lua");

function useitem(nItemIndex)
	local nValue = GetTask(TASK_RESET);
	local nUsed = GetNumber(nValue,10);
	if (nUsed >= 200) then
		Talk(1,"","<color=yellow>H�m nay b�n �� s� d�ng 200 Sao r�i. Mai h�y ti�p t�c!")
	return end
	if (GetLevel() < 80) then
		Talk(1,"","<color=yellow>��ng c�p 80 tr� l�n m�i ���c s� d�ng Ng�i Sao May M�n cao.")
	return end
    SetTask(TASK_RESET,SetNumber(nValue,10,nUsed+1))
    AddOwnExp(5000000)
    RemoveItem(nItemIndex,1,1)
end
