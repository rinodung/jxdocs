--Script by Carot.
--Ph� Qu� b�o h�p.

function useitem(nItemIdx)
	if(CheckRoom(5,2) == 1) then
		local nid = ItemSetAdd(0,5,29,0,0,0,10,0);
		AddItemID(nid);
		RemoveItem(nItemIdx,1);
	else
		Talk(1,"","B�n nh�n ���c 10 c�i <color=yellow> V� S� May M�n.");
	end
end;
