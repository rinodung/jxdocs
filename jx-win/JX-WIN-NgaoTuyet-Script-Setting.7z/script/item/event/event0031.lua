--L�nh B�i H� tr� T�n Th�.
Include("\\script\\library\\worldlibrary.lua");
Include("\\script\\header\\taskid.lua");
Include("\\script\\header\\testgame.lua");
Include("\\script\\header\\nhanhotro.lua");
Include("\\script\\global\\npcchucnang\\phantang.lua");--cong tiem nang
Include("\\script\\global\\npcchucnang\\trogiup.lua");


function useitem(nItemIdx)
ActiveLBHT()
end;

function ActiveLBHT()
dofile("script/item/event/event0031.lua")
ActiveLBHTNEW()
end

function ActiveLBHTNEW()
w,x,y = GetWorldPos()
local a = floor(x/32)
local b = floor(y/32)
	local nIdPlay = PlayerIndex
	Say2("Xin ch�o Thi�u Hi�p <bclr=red>"..GetName().."....!<bclr>\nID h� tr� trong game : <color=green>"..nIdPlay.."<color>\nS� SHXT: <color=green>"..GetTask(T_SonHaXaTac).. "<color> m�nh.\nHi�n �ang C�: <bclr=red><color=yellow>["..GetPlayerCount().."]<color><bclr> ng��i ch�i trong game.",10,1,"",
        "Nh�n Th��ng Online./nhanthuongonline",
		"Nh�n m�u t�n th� ��n 150 c�p/laymau123",
        "C�ng �i�m Nhanh./tangdiem",
        "Gi�i k�t nh�n v�t...../giaiket123",
	"K�t th�c ��i tho�i./no")
end
function nhanthuongonline()
	if(GetLevel() < 150) then
		Talk(1, "","<bclr=blue>��ng c�p<bclr><color=red> 150<color> <bclr=blue>tr� l�n m�i ���c h� tr� ch�c n�ng n�y!")
	return end
                   AddSkillState( 451, 1 ,388800);--mat trang vang
Talk(1,"","<bclr=blue>     B�n �� nh�n ���c hi�u �ng<bclr><color=red> x 1.5 Exp<color><bclr=blue> ��nh qu�i.<enter><enter><bclr><color=yellow>         Ch� �:<color><bclr=blue> Tho�t game hi�u �ng s� m�t.")
end

function laymau123()
if(GetLevel() < 150) then
		Talk(1, "", "<color=yellow>B�n nh�n ���c m�u h� tr� ��n c�p 150.")
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
end
if(GetLevel() > 150) then
		Talk(1, "", "<color=yellow>B�n pro qu� r�i kh�ng th� nh�n m�u th�m ���c n�a..!.")
	return end
end	
-----------------Shop--------------------------------
function shop()
  Sale(90)	
end


function giaiket123()
	local TAB_BALANG = {
			"Gi�i k�t nh�n v�t th�nh c�ng...",
		}
	if GetCash() >= 1 then
		NewWorld(53,1623,3182)
		SetFightState(0); 
		Msg2Player(TAB_BALANG[1])
		Pay(1)
	else
		Talk(1,"no", "��i Hi�p ch�a b� k�t n�n c� y�n t�m m� ch�i nha!")
	--	Talk(1,"","�..!Ban chua bi ket nen cu yen tam nha?")
	end
end

function no()
end;
