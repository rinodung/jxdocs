--Script by Carot.
--hat gi�ng Hoa H�ng.

Include( "\\script\\item\\checkmapid.lua" )
function useitem(nItemIdx)
	if(CheckMapForTP() > 1) then
	Msg2Player("<color=yeloow>N�i ��y kh�ng th�ch h�p �� tr�ng c�y!")
	return end;
	Msg2Player("<color=yeloow> B�n �� tr�ng ���c 1 c�y Hoa H�ng T�nh �i.");
	local w,x,y = GetWorldPos();
	local nRand = RANDOM(1255,1255);
	local id = AddNpc(nRand,1,SubWorldID2Idx(w),x,y,0);
	SetNpcScript(id, "\\script\\global\\lastdamage\\death_hat.lua");
	SetNpcCurCamp(id, 5);
	SetNpcLifeTime(id,32400);
        SetNpcName(id, "Hoa H�ng T�nh �i")	--��t t�n cho qu�i
        SetNpcDropScript(id, "\\script\\global\\droprate\\drop_hat");
        SetNpcSer(id, "555")--Ng� H�nh
	SetNpcLifeTime(id,32400);--time boss
	RemoveItem(nItemIdx,1);
	if(nRand == 1255) then
	AddOwnExp(10000000)
	AddCountNews2("<bclr=white><color=red> Ch�c m�ng "..GetName().." �� tr�ng ���c Hoa H�ng T�nh �i",3);
	else
	AddOwnExp(50000000)
	end
end
