--Script by Caorot

function useitem(nItemIdx)
sudungbch()
end;

function sudungbch()
if GetLevel() >= 70 then
	if GetTask(TaskBCH) >= 2880 then
	Talk(1,"","Th�i gian �y th�c t�i �a l� <color=red>48 gi� <color=red>, b�n kh�ng th� s� d�ng th�m.")
	else
	RemoveItem(nItemIndex)
	SetTask(TaskBCH,GetTask(TaskBCH)+480)
	Msg2Player("Th�i gian B�ch C�u Ho�n c�a b�n c�n "..giobch().." gi� "..phutbch().." ph�t.")
	end
else
Talk(1,"","��ng c�p 70 m�i c� th� s� d�ng B�ch C�u Ho�n.")
end
end

function giobch()
if GetTask(TaskBCH) < 60 then
return 0
else
gio = floor((GetTask(TaskBCH)/60),2)
return gio
end
end

function phutbch()
if GetTask(TaskBCH) < 60 then
return GetTask(TaskBCH)
else
gio = floor((GetTask(TaskBCH)/60),2)
phut = GetTask(TaskBCH) - gio*60
return phut
end
end

function no()
end
