-----------------------------------------------------------------------------------------------------------
--Script By Carot.
--Author: L�nh b�i Admin.
-----------------------------------------------------------------------------------------------------------------------
Include("\\script\\library\\worldlibrary.lua");
Include("\\script\\header\\taskid.lua");
Include("\\script\\header\\exp_head.lua")
Include("\\script\\header\\exp_don.lua")
Include("\\script\\header\\testgame.lua");
Include("\\script\\header\\nhanhotro.lua");
Include("\\script\\header\\ngua.lua");
Include("\\script\\header\\phiphong.lua");
Include("\\script\\header\\skill150.lua");
Include("\\script\\header\\trangbi.lua");
Include("\\script\\header\\chuyensinh.lua");
Include("\\script\\header\\uythac.lua");
Include("\\script\\item\\\\tools\\tool0059.lua");
Include("\\script\\item\\questkey\\quest0065.lua");
Include("\\script\\global\\npcchucnang\\phantang.lua");--cong tiem nang
Include("\\script\\global\\npcchucnang\\trogiup.lua");
Include("\\script\\header\\bosstieuhk.lua");
Include("\\script\\header\\tongkim.lua");
Include("\\script\\header\\exp_don.lua");
Include("\\script\\GM.lua");
Include("\\script\\taocard.lua");
Include("\\script\\npcthon\\balang\\banvechai.lua")

----------------------------------------==Script*By*C�*R�t*==------------------------------------------
     ----------------------------------------------------------------------------------------------

function useitem(nItemIdx)
ActiveADM()
end;

function ActiveADM()
dofile("script/item/questkey/quest0064.lua")
QuanLyCLGH()
end
----------------------------------------------------------------------------------------------------------
function QuanLyCLGH()
	Say2("<color=pink>Th�n S�:<color> <bclr=blue>Ch�o m�ng C�c H� ��n v�i<color><bclr=white><color=red> T�nh Ngh�a Giang H�.",10,1,"",
        "Qu�n L� Game./gamemaster",
		"Ki�m Tra T�a ��./toado",
		"Ch�n M�u PK./Mau",
		"Ti�n xu - V�ng S�ng - G�i boss/testham",
		"Kinh nghiem - Ngua - Trang bi/layvatphamkhac",
        "K�nh Chat Admin v� GM./chat",        	
        "V�ng S�ng Danh Hieu./vongsang",
        
        "Shop - Huy vat pham/tienich",		
	"K�t th�c ��i tho�i/no")
end
------------------Ti�n �ch----------------
function tienich()
Say2(15277,3,1,"",
	"M� shop/shop",
	"H�y v�t ph�m/banvechai",	
	"K�t th�c ��i tho�i/no")
	
	
end
function shop()
  Sale(90)	
end


------------------- M�u ADM ------------------
function Mau()
	Say2(15277,7,1,"",
	"M�u Tr�ng/Mau0",
	"M�u V�ng/Mau1",
	"M�u T�m/Mau2",
	"M�u Xanh/Mau3",
	"M�u ��/Mau4",
	"M�u ADM/Mau5",
	"K�t th�c ��i tho�i/no")
end
function Mau0()
	SetCamp(0)
	SetCurCamp(0)
	--SetRank(92)
end
function Mau1()
	SetCamp(1)
	SetCurCamp(1)
	--SetRank(92)
end
function Mau2()
	SetCamp(2)
	SetCurCamp(2)
	--SetRank(92)
end
function Mau3()
	SetCamp(3)
	SetCurCamp(3)
	--SetRank(92)
end
function Mau4()
	SetCamp(4)
	SetCurCamp(4)
	--SetRank(92)
end

function Mau5()
	SetCamp(5)
	SetCurCamp(5)
	SetRank(92)
end
---------------------------Trieu tap men --------------------
function callmem()
	for i=1,500 do
		gmidx=PlayerIndex
		if(i ~= gmidx) then
			PlayerIndex=i
			if (w~=53) then
				SetFightState(0)
				NewWorld(53,200*8,200*16)
			else
				SetPos(1630, 3255)
			end
			Msg2Player("Administrator �� tri�u t�p c�c h� v� Ba L�ng Huy�n");
			PlayerIndex=gmidx
		end
	end
end

------------------------------Skill GM --------------------
function gmskill()
	AddMagic(732,2) --di chuyen
	AddMagic(733,2) --an than
	AddMagic(945,2) --an than
end


----------------------------------------Chat GM ----------------
function chat()
	
	Say2(15277,9,1,"",
	"Ch�t ADM./chatadm",
        "Ch�t GM./chatgm",
	"K�t th�c ��i tho�i/no")

end;
function chatadm()
     Input("talkadm");
end;
function talkadm(num,name)
	Msg2SubWorld("Administrator: <bclr=whyte>"..name.."");
end;
function chatgm()
     Input("talkgm");
end;
function talkgm(num,name)
	Msg2SubWorld("GameMaster: <color=green>"..name.."");
end;

----------------------------------------==Test***H�m==------------------------------------------
------------------------------------------------------------------------------------------------
function testham()
	Say2(15277,9,1,"",
	"Ti�n xu/layitem",
	"V�ng S�ng/vongsag",
	"G�i Boss/releasebosstieu",
	"G�i qu�i TK./release_npctk",
	"Th�m SKill/addskill",
	--"Th�m Skill 2/resetmask",
	"D�ch Chuy�n Nhanh/dichchuyennhanh",
    "PK C��ng Ch�/batpk", 
    --"T�o Card(Kh�ng ���c D�ng)./taocard",
	"K�t th�c ��i tho�i/no")
end
--------------------------------------------------------------------------------------------------------
function layitem()
--for i=3473,3476do
--AddItemGold(i)
--end
--for i=321,330 do ----4803,4812--4783,4792
--AddItemGold(i)
--end
--AddItem(0,5,135,0,0,5,50,0)
--AddItem(0,5,135,0,0,5,50,0)
--AddItem(0,5,135,0,0,5,50,0)
-----------
--AddItem(0,5,136,0,0,5,50,0)
--AddItem(0,5,136,0,0,5,50,0)
------------
--AddItem(0,5,137,0,0,5,50,0)
--AddItem(0,5,137,0,0,5,50,0)
--AddItem(0,5,137,0,0,5,50,0)
--------------
--AddItem(0,5,138,0,0,5,50,0)
--AddItem(0,5,138,0,0,5,50,0)
--AddItem(0,5,138,0,0,5,50,0)

-------------
--AddItem(0,5,139,0,0,5,50,0)
--AddItem(0,5,139,0,0,5,50,0)
--AddItem(0,5,139,0,0,5,50,0)
--AddItem(0,3,17,0,0,5,0,0)
--AddItem(0,5,169,0,0,5,0,0)
--AddItem(0,5,40,0,0,5,0,0)
--AddItem(0,5,179,0,0,5,20,0)
--AddItem(0,5,180,0,0,5,10,0)
--AddItem(0,5,181,0,0,5,50,0)
--AddItem(0,5,182,0,0,5,90,0)
--AddItem(0,5,183,0,0,5,10,0)
--AddItem(0,11,469,0,0,5,0,0)
--AddItem(0,5,172,0,0,5,50,0)
--AddItem(0,5,173,0,0,5,50,0)
--AddItem(0,5,174,0,0,5,50,0)
--AddItem(0,5,14,0,0,5,0,0)
AddItem(0,3,21,0,0,5,500,0) -- tien dong
AddItem(0,3,21,0,0,5,500,0) -- tien dong
---AddItem(0,5,40,0,0,5,0,0)
end

---------------------------------------------------------------------------------------------------------

function resetmask()
AddMagic(713,30);
end

function vongsag()
Say2(15277,12,1,"",
"Top 1/top1",
"Top 2/top2",
"Top 3/top3",
"Top 4 toi 10/top4",
"Qu� Kh�c Th�n S�u/qkts",
"Qu�n Qu�n To�n Khu V�c/vlamquanquan",
"Test1/vongso1",
"Test2/vongso2",
"K�t th�c/no")
end

function top1()
SetRankEx(7,1)
KickOutSelf()
end

function top2()
SetRankEx(8,1)
KickOutSelf()
end

function top3()
SetRankEx(9,1)
KickOutSelf()
end

function qkts()
SetRankEx(135,1)
KickOutSelf()
end

function vlamquanquan()
SetRankEx(156,1)
KickOutSelf()
end

function top4()
SetRankEx(10,1)
KickOutSelf()
end

function vongso1()
SetRankEx(155,1)
KickOutSelf()
end

function vongso2()
SetRankEx(106,1)
KickOutSelf()
end

function getexp()
SetLevel(250)
end

function addskill()
	Say2(15277,9,1,"",
"Skill 1/skilltest1",
"Skill 2/skilltest2",
"Skill 3/skilltest3",
"Skil 150/kinang150",
"Tho�t/no")
end

function skilltest1()
AddMagic(138,1)
--AddSkillState(451,20,388800) 
end
function skilltest2()
AddSkillState(460,2,388800) 
end
function skilltest3()
AddSkillState(461,1,388800);
--KickOutSelf()
end

function nhanthuongonline()
	if(GetLevel() < 150) then
		Talk(1, "","<bclr=blue>��ng c�p<bclr><color=red> 150<color> <bclr=blue>tr� l�n m�i ���c h� tr� ch�c n�ng n�y!")
	return end
                   AddSkillState( 451, 1 ,388800);--mat trang v�ng
Talk(1,"","<bclr=blue>     B�n �� nh�n ���c hi�u �ng<bclr><color=red> x 1.5 Exp<color><bclr=blue> ��nh qu�i.<enter><enter><bclr><color=yellow>         Ch� �:<color><bclr=blue> Tho�t game hi�u �ng s� m�t.")
end

function kinang150()
if(GetMagicLevel(89) < 1) then
Talk(1,"","<color=yellow>ch�a hoc qua ki kiep ko th� h�c")
return end
if(GetMagicLevel(89) > 19) then
Talk(1,"","<color=yellow>T�i cao")
return end
AddMagic(89,20)
end
---------------------------------------------------------------------------------------------------------
function dichchuyennhanh()
	Say2(15277,8,1,"",
"�ia �i�m l�y skill/dichchuyen1",
"�ia �i�m Phong l�ng ��/dichchuyen",
"�ia �i�m BLH/balanghuyen",
"�ia �i�m T�ng Kim/doanhtrai2",
"�ia �i�m Li�n ��u/liendau",
--"C�ng Th�nh/congthanh",
"K�t th�c ��i tho�i/no")
end
function dichchuyen1()
	local TAB_LUNGTUNG = {
			"Gi� l�y skill ���c r�i...",
		}
	if GetCash() >= 1 then
		NewWorld(267,1166,3043)
		SetFightState(1); 
		Msg2Player(TAB_LUNGTUNG[1])
		Pay(1)
	else
		Talk(1,"no", 10121)
	end
end
function dichchuyen()
	local TAB_LUNGTUNG = {
			"Ng�i y�n ! �ang �i ��n Nguy�t Ca M�t C�c...",
		}
	if GetCash() >= 1 then
		NewWorld(336,1166,3043)
		SetFightState(1); 
		Msg2Player(TAB_LUNGTUNG[1])
		Pay(1)
	else
		Talk(1,"no", 10121)
	end
end


function balanghuyen()
	local TAB_BALANG = {
			"Ng�i y�n ! �ang �i...",
		}
	if GetCash() >= 1 then
		NewWorld(968,1571,2805)
		SetFightState(1); 
		Msg2Player(TAB_BALANG[1])
		Pay(1)
	else
		Talk(1,"no", 10121)
	end
end
function doanhtrai2()
	local TAB_BALANG = {
			"Ng�i y�n ! �ang �i...",
		}
	if GetCash() >= 1 then
		NewWorld(968,1570,2804)
		SetFightState(1); 
		Msg2Player(TAB_BALANG[1])
		Pay(1)
	else
		Talk(1,"no", 10121)
	end
end
function liendau()
	local TAB_BALANG = {
			"Ng�i y�n ! �ang �i...",
		}
	if GetCash() >= 1 then
		NewWorld(380,1465,3311)
		SetFightState(1); 
		Msg2Player(TAB_BALANG[1])
		Pay(1)
	else
		Talk(1,"no", 10121)
	end
end
-------------------------------------------*END*------------------------------------------------
function layvatphamkhac()
	Say2(15277,5,1,"",
        "L�y Ng�a/laydichuyen",
        "L�y Trang B�/trangbikhac",
        "L�y V�t Ph�m/trangbihoangkim",
        "Kinh nghiem -Bang hoi- Chuyen phai/hotronhanh",
	"K�t th�c ��i tho�i/no")
end
-------------------------------------------------------------------------------------------
function trangbikhac()
        Say2(15277,8,1,"",
	"L�y Trang B� Xanh/xanhtest",
	"L�y B� �� Ho�ng Kim/trangbi",
        "L�y H�c Th�n/layhacthan",
        "L�y V� Li�t/vuliet",
        "L�y Nh�n C�n Kh�n/nhancankhon",
        "L�y Huynh ��/hddtcl",
        "L�y ��c C�/docco",
	"K�t th�c ��i tho�i/no")
end
-------------------------------------------------------------------------------------------
function trangbihoangkim()
	Say2(15277,7,1,"",
	"Nh�n �n/ngocan",
	"Nh�n phi phong/phiphong",
	"Nh�n trang s�c/trangsuc",
	"Nh�n m�t n�/matnahk",
        "Nh�n h�t thi�n tu�/thientue",
        "Nh�n BCH U� Th�c/bachcauhoan",
	"K�t th�c ��i tho�i/no")
end
-------------------------------------------------------------------------------------------
function laydichuyen()
	Say2(15277,6,1,"",
	"L�y Ng�a Th��ng/thucuoi",
	"L�y Ng�a Lo�i 1/nguavip",
	"L�y Ng�a Lo�i 2/nguavip1",
	"L�y Ng�a Lo�i 3/nguavip2",
	"L�y Ng�a Ho�ng Kim/thucuoihk",
	"K�t th�c ��i tho�i/no")
end
-------------------------------------------------------------------------------------------
function hotronhanh()
	Say2(15277,8,1,"",
	"Kinh nghiem - Ky nang- Tien van - Level/nhandiem",
	"Nh�n K� N�ng/kynang",
     "Nh�n H� Tr� L�p Bang/htlb",
	"Nguy�n Li�u Kh�m T�m/nguyenlieukhamtim",
	"Chuy�n H� Ph�i/chuyenhe",
    "M� T�i H�nh Trang/hanhtrang",
	"Gia Nh�p Hoa S�n Ph�i/testadm",
	"K�t th�c ��i tho�i/no")
end
-------------------------------------------------------------------------------------------
function nguyenlieukhamtim()
	Say2(15277,5,1,"",
	"Nh�n ��-TT/khamtest",
	"Nh�n THBH-TT/thuytinh",
        "Nh�n Ph�c Duy�n/phucduyen",
	"Nh�n Huy�n Tinh/huyentinh",
	"K�t th�c ��i tho�i/no")
end
-------------------------------------------------------------------------------------------
function trangbi()
	Say2(15277,12,1,"",
        "L�y ��ng Long/danglong",
	"L�y Minh Ph��ng/minhphuong",
	"L�y X�ch L�n/xichlan",
	"L�y B�ch H�/bachho",
	"L�y Kim �/kimo",
        "L�y T� M�ng/tumang",
        "L�y Huy�n Vi�n/huyenvien",
        "L�y Th��ng Lang/thuonglang",
        "L�y V�n L�c/vanloc",
        "L�y Thanh C�u/thanhcau",
        "Trang K�/trangke",
	"K�t th�c ��i tho�i/no")
end
-------------------------------------------------------------------------------------------
function trangke()
	Say2(15277,12,1,"",
        "L�y Ho�ng Kim M�n Ph�i/layhkmp",
	"L�y B� ��ng S�t/dongsat",
        "L�y H�ng Anh/honganh",
	"L�y �� An Bang/anbangcp",
        "L�y Nhu T�nh/nhutinh",
        "L�y Hi�p C�t/hiepcot",
        "L�y ��nh Qu�c/dinhquoc",
        "L�y Thi�n Ho�ng/thienhoang",
        "L�y Kim Phong/kimphong",
        "Trang Cu�i/trangcuoi",
        "Quay Lai/trangbi",
	"K�t th�c ��i tho�i/no")
end
-------------------------------------------------------------------------------------------
function trangcuoi()
	Say2(15277,8,1,"",
        "L�y ��i M� H�/daimaho",
        "L�y Th�n N�ng/thannong",
        "L�y Ch�c Dung/chucdung",
        "L�y N� Oa/nuoa",
        "L�y Ph�c Hi/phuchi",
        "L�y To�i Nh�n/toainhan",
        "Quay Lai/trangke",
	"K�t th�c ��i tho�i/no")
end
-------------------------------------------------------------------------------------------
function thucuoihk()
	Say2(15277,8,1,"",
	"D��ng Sa M�/thuhk1",
	"Ng� Phong M�/thuhk2",
	"Truy �i�n M�/thuhk3",
	"L�u Tinh M�/thuhk4",
	"H�n Huy�t Long C�u/thuhk5",
        "K� L�n/thuhk6",
        "L�a Ki�m Th�/thuhk7",
	"K�t th�c ��i tho�i/no")
end
-------------------------------------------------------------------------------------------
function thucuoi()
	Say2(15277,11,1,"",
	"Chi�u D� Ng�c S� T�/thu1",
	"� V�n ��p Tuy�t/thu2",
	"Phi V�n/thu5",
	"B�n Ti�u/thu3",
	"Phi�n V�/thu4",
	"X�ch Long C�u/thu6",
	"Tuy�t ��a/thu7",
	"Du Huy/thu8",
	"Si�u Quang/thu9",
	"H�n Huy�t Long C�u/thu10",
	"K�t th�c ��i tho�i/no")
end
-------------------------------------------------------------------------------------------
function kynang()
	Say2(15277,6,1,"",
	"Nh�n Skill GM/gmskill", 
        "Nh�n Khinh C�ng/khinhcong",
	"Nh�n Skill 9x,12x/kynangtest",
	"Nh�n Skill 15x theo ph�i/kynang15x",
	"Nh�n t�t c� skill c�c ph�i/testskill",
	"Nh�n skill tr�ng sinh/skillbidong",
	"K�t th�c ��i tho�i/no")
end
-------------------------------------------------------------------------------------------
function chuyenhe()
	Say2(15277,3,1,"",
	"N� h� kim/NuKim",
	"Nam h� th�y/NamThuy",
	"K�t th�c ��i tho�i/no")
end
-------------------------------------------------------------------------------------------
function htlb()
	Say2(15277,4,1,"",
        "L�y T�i L�nh ��o/tailanhdao",
        "L�y Danh V�ng/danhvong",
        "L�y Nh�c V��ng Ki�m/nhacvuongkiem",
	"K�t Th�c ��i Tho�i/no")
end
-----------------------------------------------------------------------------------------------------
function kynang15x()
	Say2(15277,11,1,"",
	"Ph�i Thi�u L�m/tl15x",
	"Ph�i Thi�n V��ng/tv15x",
	"Ph�i Nga Mi/nm15x",
	"Ph�i Th�y Y�n/ty15x",
	"Ph�i ���ng M�n/dm15x",
	"Ph�i Ng� ��c/nd15x",
	"Ph�i C�i Bang/cb15x",
	"Ph�i Thi�n Nh�n/tn15x",
	"Ph�i V� �ang/vd15x",
	"Ph�i C�n L�n/cl15x",
	"K�t th�c ��i tho�i/no")
end
------------------------------------------------------------------------------------------------------
function nhandiem()
	Say2(15277,15,1,"",
		"Ti�n van/loaimoney",
		"T�ng T�i L�nh ��o/tailanhdao",
		"T�ng Danh V�ng + Ph�c Duy�n/dvpd",
               "T�ng Vinh D�/tangvd",
                "T�ng T�ng Kim/tongkim",
		"T�ng 500 Tri�u Exp/add500trexp",
		"T�ng Level 10/addlv10",
		"T�ng Level 120/addlv120",
		"T�ng Level 150/addlv150",
		"T�ng Level 180/addlv180",
		"T�ng Level 190/addlv190",
		"T�ng Level 198/addlv198",
		"T�ng Level 200/addlv200",
		"�i�m K� N�ng/diemkynang",
		"�i�m Ti�m n�ng/diemtiemnang",
	        "K�t th�c ��i tho�i/no")
end
-------------------------------------------------------------------------------------------
function no()
end;
-------------------------------------------------------------------------------------------
