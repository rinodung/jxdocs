--L�nh B�i G�i Boss (C�ng Th�nh ).
--Script By CaRot.
Include("\\script\\header\\taskid.lua");
Include("\\script\\header\\time.lua");
Include("\\script\\header\\tongkim.lua");
Include("\\script\\library\\worldlibrary.lua");
Include( "\\script\\item\\checkmapid.lua" )
Include("\\script\\header\\monphaiheader.lua");

function useitem(nItemIdx)
	if(CheckMapForTP() > 1) then
	Msg2Player("<color=green>M� Ph�t !N�i ��y thanh t�nh kh�ng th� th� Boss ...")
	return end;
	Msg2Player("<color=yellow>Thi�n Binh Th�n Th��ng �� xu�t hi�n gi�p b�n...");
	local w,x,y = GetWorldPos();
	local nRand = RANDOM(1921,1921);
	local id = AddNpc(nRand,1,SubWorldID2Idx(w),x,y,0);
        SetNpcName(id, "Thi�n Binh Th�n T��ng")	--��t t�n cho qu�i
	SetNpcScript(id, "\\script\\global\\lastdamage\\thienbinh.lua");
        SetNpcSer(id, "555")--Ng� H�nh
	SetNpcLifeTime(id,1200);--time boss
	RemoveItem(nItemIdx,1);
end
