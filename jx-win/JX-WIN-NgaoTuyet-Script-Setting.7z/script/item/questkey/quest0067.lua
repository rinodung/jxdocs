--T�n V�t Hoa S�n

function useitem(nItemIndex)
	Say2(15653,1,0,GetName(),"V�ng ! Ta ch�p nh�n. /no");
        if GetSex() == 0 then
        SetSeries(2) 
	RemoveItem(nItemIndex,1)
	else
	Talk(1,"","Nh� ng��i kh�ng ph�i Nam gi�i,b� Les � ?")
    end
end

function no()
end;
