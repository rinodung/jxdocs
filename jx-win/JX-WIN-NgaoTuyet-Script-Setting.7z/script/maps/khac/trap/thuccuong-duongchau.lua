
function main(sel)
	NewWorld(80,1530,2918)		--	
	SetFightState(1)		--
end;
