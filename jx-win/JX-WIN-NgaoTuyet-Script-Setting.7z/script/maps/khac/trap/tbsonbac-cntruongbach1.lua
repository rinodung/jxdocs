
function main(sel)

	NewWorld(320,1568,2340)		--	
	SetFightState(1)		--
    AddWayPoint(197)

end;
