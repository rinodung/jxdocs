
function main(sel)

	NewWorld(320,1562,2968)		--	
	SetFightState(1)		--
    AddWayPoint(197)

end;
