
function main()

	NewWorld(11, 3406,5293)		--	
	SetFightState(1)		--
end;
