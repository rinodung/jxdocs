
function main(sel)

	NewWorld(92,1850,3235)		--	
	SetFightState(1)		--
    AddWayPoint(151)
end;
