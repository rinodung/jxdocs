
function main(sel)

	NewWorld(1,1216,3393)		--	
	SetFightState(1)		--
end;
