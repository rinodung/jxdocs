
function main(sel)

	NewWorld(319, 2027,3304)		--	
	SetFightState(1)		--
    AddWayPoint(196)

end;
