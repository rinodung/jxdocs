
function main(sel)

	NewWorld(92,2024,3039)		--	
	SetFightState(1)		--
    AddWayPoint(151)
end;
