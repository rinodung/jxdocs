
function main(sel)

	NewWorld(78, 1655,2991)	
	SetFightState(1)
	
end;
