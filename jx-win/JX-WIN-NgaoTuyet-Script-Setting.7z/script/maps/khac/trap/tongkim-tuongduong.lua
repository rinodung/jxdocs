
function main(sel)

	if(NewWorld(78, 1769,3094) == 1) then
	SetFightState(1)		--
	end
	
end;
