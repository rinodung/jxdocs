--Loi tat den long mon tran
function main(sel)

	--NewWorld(136,1714,3154)		--	ve khoai hat lam
	SetFightState(1)		--
	NewWorld(121,1855,4125)	--ve long mon
end;
