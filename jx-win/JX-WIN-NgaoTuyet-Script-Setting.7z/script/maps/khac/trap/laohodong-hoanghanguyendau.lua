
function main(sel)

	NewWorld(122,1665,3323)		--	
	SetFightState(1)		--
end;

