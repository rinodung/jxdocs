
function main(sel)
 	NewWorld(37, 2080,2478)		--	
	SetFightState(1)		--
end;
