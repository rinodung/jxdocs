
function main(sel)

	NewWorld(322,2039,4107)	
	SetFightState(1)
    AddWayPoint(200)

end;
