function main(sel)
	
	if (GetMSRestTime(1,1) > 0) then
	SetPos(1670,3095)
	SetFightState(0)
	end
end;
