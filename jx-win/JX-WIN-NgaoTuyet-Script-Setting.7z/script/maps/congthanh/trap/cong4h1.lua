function main(sel)

if ( GetFightState() == 0 ) then	
	SetPos(1859,3526)		
	SetFightState(1)		
	
else			       		
	SetPos(1867,3539)			
	SetFightState(0)		
end;
end;
