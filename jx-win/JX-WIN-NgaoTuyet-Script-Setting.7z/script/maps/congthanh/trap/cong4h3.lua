function main(sel)

if ( GetFightState() == 0 ) then	
	SetPos(1855,3589)		
	SetFightState(1)		
	
else			       		
	SetPos(1865,3598)			
	SetFightState(0)		
end;
end;
