function main(sel)

if ( GetFightState() == 0 ) then	
	SetPos(1593,3269)		
	SetFightState(1)		
	
else			       		
	SetPos(1586,3258)			
	SetFightState(0)		
end;
end;

