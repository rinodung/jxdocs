function main(sel)

if ( GetFightState() == 0 ) then	
	SetPos(1903,3539)		
	SetFightState(1)		
	
else			       		
	SetPos(1908,3556)			
	SetFightState(0)		
end;
end;
