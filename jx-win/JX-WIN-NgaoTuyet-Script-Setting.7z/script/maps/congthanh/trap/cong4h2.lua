function main(sel)

if ( GetFightState() == 0 ) then	
	SetPos(1846,3543)		
	SetFightState(1)		
	
else			       		
	SetPos(1852,3554)			
	SetFightState(0)		
end;
end;
