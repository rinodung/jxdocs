function main(sel)

if ( GetFightState() == 0 ) then	
	SetPos(1540,3284)		
	SetFightState(1)		
	
else			       		
	SetPos(1536,3264)			
	SetFightState(0)		
end;
end;
