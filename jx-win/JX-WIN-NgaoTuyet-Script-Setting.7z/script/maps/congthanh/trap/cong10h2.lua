function main(sel)

if ( GetFightState() == 0 ) then	
	SetPos(1579,3286)		
	SetFightState(1)		
	
else			       		
	SetPos(1570,3273)			
	SetFightState(0)		
end;
end;
