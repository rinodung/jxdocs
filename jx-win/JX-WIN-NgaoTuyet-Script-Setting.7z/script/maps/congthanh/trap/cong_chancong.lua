function main(sel)
	
	if (GetMSRestTime(1,1) > 0) then
	SetPos(1828,3498)
	SetFightState(0)
	end
end;
