function main(sel)

if ( GetFightState() == 0 ) then	
	SetPos(1588,3213)		
	SetFightState(1)		
	
else			       		
	SetPos(1582,3227)			
	SetFightState(0)		
end;
end;
