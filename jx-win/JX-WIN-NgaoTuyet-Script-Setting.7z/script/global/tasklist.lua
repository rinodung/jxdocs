--********************************************************************************
									-- TASK -- 
--********************************************************************************
-- MON PHAI
T_VaoPhai				= 1
T_XuatSu				= 2
T_HocKhinhCong			= 3
-- VAT PHAM
T_VLMT					= 4
T_TTK					= 5
-- HE THONG
T_HoTro					= 6
T_LuuNgayThangNam		= 7
T_LuuNgay				= 8
T_LuuThangNam			= 9
T_LuuNam				= 10
-- TONG KIM
T_BattleFaction			= 11
T_PK					= 12
T_NPC					= 13
T_LienTramHT			= 14
T_Treasure				= 15
T_TalkFlag				= 16
T_CalcPK				= 17
T_CalcNPC				= 18
T_CalcLienTramHT		= 19
T_CalcTreasure			= 20
T_CalcTalkFlag			= 21
T_TichLuyTran			= 22
T_Death					= 23
T_LienTramCN			= 24

-- DA TAU
T_SoNVTrongNgay			= 25
T_HuyNhiemVu			= 26
T_SoLanHuyNV			= 27
T_SoNVHoanThanh			= 28
T_KhoiDongSHXT			= 29
T_SonHaXaTac			= 30
T_MayMan				= 31
T_TimVatPham			= 32
T_TimDoChi				= 33
T_TimMatChi				= 34
T_DanhQuai				= 35
T_NDPhucDuyen			= 36
T_NDDanhVong			= 37
T_NDTongKim				= 38
T_DiemHienCo			= 39
T_DiemYeuCau			= 40
T_TienDoNV				= 41
-- SAT THU
T_SoNVBSTTrongNgay		= 50
T_HoanThanhNVBST		= 51
T_NhanNVBST				= 52
T_LuuDiemLenBST			= 53
T_PhanLoaiBoss			= 54
T_BossCap70				= 55
T_BossCap100			= 56
T_BossCap120			= 57
T_LuuDiemSTSaMac		= 58
-- SO NHAP
T_NVuSoNhap				= 70
-- VUOT AI
T_VuotAiTrongNgay		= 85
-- Huy Hoang
T_SuDungHuyHoang		= 90
T_SuDungHoangKim		= 91
-- TY VO
-- LIEN DAU
T_LuuSoTran				= 95
T_LuuSoTranThang		= 96
T_ThanhLapChienDoi		= 97
-- Task Bo Tu Pk
T_DemTimePK				= 101
-- Task Mon Phai
T_CaiBang				= 120
T_ConLon				= 121
T_DuongMon				= 122
T_NgaMy					= 123
T_NguDoc				= 124
T_ThienNhan				= 125
T_ThienVuong			= 126
T_ThieuLam				= 127
T_ThuyYen				= 128
T_VoDang				= 129

T_Meat					= 130
T_Quest_MeatRandom		= 131
--CHUYEN SINH
T_ChuyenSinh1			= 151
T_LuuSkill1				= 152
T_LuuSkill2				= 153
T_LuuSkill3				= 154
T_NhanLaiSkill			= 155
-- LUYEN SKILL
T_ExpSkill1				= 191
T_ExpSkill2				= 192
T_ExpSkill3				= 193

T_QuestChuyenSinh 		= 300

T_ResetFree				= 301
T_ResetType				= 302
-- EVENT
nYearEnd				= 2014
nMonthEnd				= 9
nDayEnd					= 15
nHourEnd				= 22
nMinEnd					= 0

T_LongDenBuom			= 400
T_LongDenSao			= 401
T_LongDenOng			= 402
T_LongDenTron			= 403
T_LongDenCaChep			= 404
T_LongDenKeoQuan		= 405
T_BanhDauXanh			= 406
T_BanhHatSen			= 407
T_BanMinhNguyet			= 408
T_BanhVienNguyen		= 409
T_BanhHoangNguyet		= 410
T_CongNguyet			= 411
T_PhuDung				= 412

T_RosePlanting			= 506
-- DINH NGHIA TU SOURCE
T_Offline				= 159
T_BCH					= 160
T_TimeDualSkill			= 166
T_ValueDualSkill		= 167
T_TimeDualExp			= 168
T_ValueDualExp			= 169
T_BayBan				= 170
T_TichLuy				= 171
T_VinhDu				= 172
T_PlayerCount			= 173
T_NhanDiemOnline		= 811
T_TongDiemOnline		= 812
T_SayNotice				= 11
T_DBCH                                                           =161
T_LoaiBCH                                  =162
--*******************************************************************************
							-- TASK TEMP --
--*******************************************************************************
-- TONG KIM
TMP_ThoiGianXuatPhat	= 1
-- HUY HOANG	
TMP_PickItem			= 2
TMP_Index				= 3
-- VUOTAI
TMP_VuotAi				= 4
TMP_VA_PTUONG			= 5
TMP_VA_TDO				= 6
TMP_VA_BKINH			= 7
TMP_VA_DCHAU			= 8
--Event trong cay
TMP_TOADOX				= 10
TMP_TOADOY				= 11
TMP_INDEXTC				= 12
--Lien Dau
TMP_LienDau_DonDau 		= 16
TMP_DthuLienDau			= 17
TMP_DthuLienDauCao		= 18
--Tong Kim
TMP_CamCo_Tcap			= 19
TMP_TKim_Tcap			= 20
-- Phong Lang Do
TMP_PhongLangDo			= 21
-- GM

TMP_LuuTimeOff			= 165
-- Task Security
TMP_Quest				= 220
TMT_KindTimer			= 398
TMT_CountDownTimerPL	= 399

TMT_GameMaster			= 999

--*******************************************************************************
							-- MISSION --
--*******************************************************************************
M_Server				= 1
M_TongKim				= 2
M_VuotAi_Pig			= 3
M_LD_DONDAU				= 8
M_TKim_Tcap				= 9

--*******************************************************************************
							-- GLBMISSION --
--*******************************************************************************
-- TongKim Tcap
GM_TichLuyT				= 1
GM_TichLuyK 			= 2
GM_NguoiTong			= 3
GM_NguoiKim				= 4
GM_TimeEndTK			= 5
GM_HinhThucTK			= 6
GM_NguyenSoai			= 7
-- VUOT AI TDuong
M_TrangThai_TDuong		= 8
M_AiDangVuot_TDuong		= 9
M_SoLuongQuai_TDuong	= 10
M_ThoiGianCho_TDuong	= 11
-- Vuot Ai PTuong
M_TrangThai_PTuong		= 12
M_AiDangVuot_PTuong		= 13
M_SoLuongQuai_PTuong	= 14
M_ThoiGianCho_PTuong	= 15
-- VUOT AI TDo
M_TrangThai_TDo			= 16
M_AiDangVuot_TDo		= 17
M_SoLuongQuai_TDo		= 18
M_ThoiGianCho_TDo		= 19
-- Vuot Ai BKINH
M_TrangThai_BKinh		= 20
M_AiDangVuot_BKinh		= 21
M_SoLuongQuai_BKinh		= 22
M_ThoiGianCho_BKinh		= 23
-- Vuot Ai DChau
M_TrangThai_DChau		= 24
M_AiDangVuot_DChau		= 25
M_SoLuongQuai_DChau		= 26
M_ThoiGianCho_DChau		= 27
-- vuot ai
GM_VuotAi_Pig			= 28
-- Lien Dau TCap
M_LienDau_DonDau		= 29
-- Phong Lang Do
GM_BenThuyen1			= 30		
GM_BenThuyen2			= 31	
GM_BenThuyen3			= 32
-- Mon Phai		
GM_CaiBang				= 40
GM_ConLon				= 41
GM_DuongMon				= 42
GM_NgaMy				= 43
GM_NguDoc				= 44
GM_ThienNhan			= 45
GM_ThienVuong			= 46
GM_ThieuLam				= 47
GM_ThuyYen				= 48
GM_VoDang				= 49
--********************************************************
--				QUESTKEY
--********************************************************
KIMNGUYENBAO			= 7
LAMTHUYTINH				= 8
TUTHUYTINH				= 9
LUCTHUYTINH				= 10
TINHHONGBAOTHACH		= 11
TIENDONG				= 126
MATCHI					= 127
TUINGUYENLIEU			= 128
DUONGCAT				= 129
BOTMI					= 130
DAUXANH					= 131
HATSEN					= 132
DUIGA					= 133
THITGA					= 134
BANHDAUXANH				= 142
BANHHATSEN				= 143
BANHMINHNGUYET			= 144
BANHVIENNGUYET			= 145
BANHHOANGNGUYET			= 146
NGUYETDANG				= 135
DENBUOM					= 136
DENSAO					= 137
DENONG					= 138
DENTRON					= 139
DENCACHEP				= 140
DENKEOQUAN				= 141
VANDU1					= 147
VANDU2					= 148
VANDU3					= 149
VANDU4					= 150
VANDU5					= 151
VANDU6					= 152
TIENVU1					= 153
TIENVU2					= 154
TIENVU3					= 155
TIENVU4					= 156
TIENVU5					= 157
TIENVU6					= 158
CONGNGUYET				= 159
PHUNGNGUYET				= 160

THUNGNUOC				= 264
PHANBON					= 265
QUAHUYHOANGSO			= 271
QUAHUYHOANGTRUNG		= 272
QUAHUYHOANGCAO			= 273
QUAHOANGKIM				= 274
