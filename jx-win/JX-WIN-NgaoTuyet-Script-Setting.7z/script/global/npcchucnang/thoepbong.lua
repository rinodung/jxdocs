---Script by Ken Nguyen
--Than bi thuong nhan
--Include("\\script\\header\\taskid.lua");
NEED_ROOM_EMPTY = "Qu� kh�ch h�y s�p x�p l�i h�nh trang."
NOT_TRADE = "��ng/no";
function main()
	Say2("<color=red>Qu�n L� S� Ki�n :<color> B�n D��i L� C�ng Th�c Ch� T�o<enter><enter>Ch�t D�o + Ru�t = <color=green>B�ng Da<color><enter><enter>Ch�t D�o + Ru�t + V� B�ng Ho�ng Kim = <color=green>B�ng Ho�ng Kim<color><enter><enter>Ch�t D�o + Ru�t + V� B�ng B�ch Kim = <color=green>B�ng B�ch Kim<color>",11,5,"",
        "Ch� T�o B�ng Da/epbongda",
        "Ch� T�o B�ng Ho�ng Kim/epbongda",
        "Ch� T�o B�ng B�ch Kim/epbongda",
	"K�t th�c ��i tho�i/no")

function epbongda(sel)
	local da = 	GetItemCount(33,5)
	local ruot = 	GetItemCount(34,5)
	local vhk =	GetItemCount(35,5)
	local vbk = 	GetItemCount(36,5)
	local bda = 	GetItemCount(37,5)
	local bhk = 	GetItemCount(38,5)
	local bbk = 	GetItemCount(39,5)
        local succ = 0;
	n = sel + 1
	if(n == 1) then
   	    if(da >= 1 and ruot >=1 ) then
		   succ = 1;
		   Input("bda")
		   Msg2Player(EPBONG)
	    end
	    if(succ == 0) then
		   Talk(1,"","Ng��i kh�ng c� <color=green>Da <color>or<color=green> Ru�t <color>r�i.")
	    end
	elseif(n == 2) then
   	    if(da >= 1 and ruot >=1 and vhk >=1 ) then
		   succ = 1;
		   Input("bhk")
		   Msg2Player(EPBONG)
	    end
	    if(succ == 0) then
		   Talk(1,"","Ng��i kh�ng c� <color=green>Da <color>or<color=green> Ru�t <color>or<color=green> V� Ho�ng Kim <color>r�i.")
	    end
	elseif(n == 3) then
	   	    if(da >= 1 and ruot >=1 and vbk>=1) then
		   succ = 1;
		   Input("bbk")
		   Msg2Player(EPBONG)
	    end
	    if(succ == 0) then
		   Talk(1,"","Ng��i kh�ng c� <color=green>Da <color>or<color=green> Ru�t <color>or<color=green> V� B�ch Kim <color> r�i.")
	    end
	end
  end
end
function bda(num)
	local da = 	GetItemCount(33,5)
	local ruot = 	GetItemCount(34,5)
	local bda = 	37
	if(num < 1 or num > 50) then
        Talk(1,"","S� L��ng T�i �a l� <color=green>50")
        return end
	if(da >= num and ruot >= num ) then
          AddItem(0,5,bda,0,0,5,num,0)
               DelItem(33,5,num)
               DelItem(34,5,num)
		Talk(1,"","Ch�c M�ng �� Nh�n ���c<color=green> "..(num).." <color>B�ng Da.")
        else
 		Talk(1,"","Ng��i Thi�u <color=green>"..(num-ruot).." Ru�t Cao Su<color> ho�c <color=green>"..(num-da).." Ch�t D�o <color>r�i.")
        end
end

function bhk(num)
	local da = 	GetItemCount(33,5)
	local ruot = 	GetItemCount(34,5)
	local vhk =	GetItemCount(35,5)
	local bhk = 	38
	if(num < 1 or num > 50) then
        Talk(1,"","S� L��ng T�i �a l� <color=green>50")
        return end
	if(da >= num and ruot >= num ) then
               AddItem(0,5,bhk,0,0,5,num,0)
               DelItem(33,5,num)
               DelItem(34,5,num)
               DelItem(35,5,num)
		Talk(1,"","Ch�c M�ng �� Nh�n ���c<color=green> "..(num).." <color>B�ng Ho�ng Kim.")
        else
 		Talk(1,"","Ng��i Thi�u <color=green>"..(num-ruot).." Ru�t Cao Su<color> ho�c <color=green>"..(num-da).." Ch�t D�o <color> ho�c <color=green>"..(num-vhk).." V� Ho�ng Kim <color>r�i.")
        end
end

function bbk(num)
	local da = 	GetItemCount(33,5)
	local ruot = 	GetItemCount(34,5)
	local vbk = 	GetItemCount(36,5)
	local bbk = 	39
	if(num < 1 or num > 50) then
        Talk(1,"","S� L��ng T�i �a l� <color=green>50")
        return end
	if(da >= num and ruot >= num and vbk >= num) then
               AddItem(0,5,bbk,0,0,5,num,0) 
               DelItem(33,5,num)
               DelItem(34,5,num)
               DelItem(36,5,num)
		Talk(1,"","Ch�c M�ng �� Nh�n ���c<color=green> "..(num).." <color>B�ng B�ch Kim.")
        else
 		Talk(1,"","Ng��i Thi�u <color=green>"..(num-ruot).." Ru�t Cao Su<color> ho�c <color=green>"..(num-da).." Ch�t D�o <color> ho�c <color=green>"..(num-vbk).." V� B�ch Kim <color>r�i.")
        end
end

function noinput()
	FreezeItem(GetTaskTemp(ITEMINDEX),0)
end;


function no()
end
