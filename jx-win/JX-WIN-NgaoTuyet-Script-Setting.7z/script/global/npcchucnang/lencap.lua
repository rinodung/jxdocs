--Script By CaRot.
--T�ng B�nh.

function main()
dofile("script/global/npcchucnang/lencap.lua")
ActiveTB()
end
------------------------------------------------L�n C�p-----------------------------------------
function ActiveTB()
	Say2("Mu�n tham gia ho�t ��ng qu� b�ng h�u c�n ��t c�p<color=red> 160 <color>mang theo <color=red>5<color> H�nh Hi�p K� v� <color=red>500 v�n l��ng.",2,1,"",
		"Th�ng C�p M�i Ng�y./thuongthangcap",
		"K�t th�c ��i tho�i!/no")
end

function thuongthangcap()
	local nValue = GetTask(TASK_RESET);
	local nUsed = GetNumber(nValue,1);
	if (nUsed >= 5) then
		Talk(1, "", "<color=yellow>M�i ng�y ch� ���c ph�p th�ng c�p 5 l�n. Mai h�y ��n ti�p!")
return end
	if(GetLevel() < 160) then
		Talk(1, "", "<color=yellow>��ng c�p 160 m�i c� th� nh�n th��ng.")
return end
        local nMoney = GetCash()
	if( nMoney < 5000000) then
        Talk(1,"","<color=yellow>C�n ti�u hao 500 v�n c�c h� kh�ng �em theo �� r�i!")
return end
	local nHL1 = GetItemCount(113,5)
	local nHL2 = GetItemCount(114,5)
	local nHL3 = GetItemCount(115,5)
	local nHL4 = GetItemCount(116,5)
	local nHL5 = GetItemCount(117,5)
	local nTotal = nHL1 + nHL2 + nHL3 + nHL4 + nHL5
	if(nTotal < 5) then
		Talk(1,"","C�n c� �� <color=red>5 <color> <color=yellow>H�nh Hi�p K� <color> <color=red>1 + 2 + 3 + 4 + 5 <color> c�c h� mang theo kh�ng �� r�i!")
	return end
	Pay(5000000)
	AddOwnExp(2000000000)
        SetTask(TASK_RESET,SetNumber(nValue,1,nUsed+1))
        nTotal = 5;	
		DelItem(113,5,1)
		DelItem(114,5,1)
		DelItem(115,5,1)
		DelItem(116,5,1)
		DelItem(117,5,1)
		Talk(1,"","<color=yellow> Ch�c m�ng c�c h� �� th�ng c�p th�nh c�ng!");
end

------------------------------------------------***END***-------------------------------------------
------------------------------------------------***END***-------------------------------------------
function no()
end;
