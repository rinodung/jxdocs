--Script By CaRot.
--T�ng B�nh.

function main()
dofile("script/global/npcchucnang/banhcattuong.lua")
ActiveTB()
end
------------------------------------------------B�nh C�t T��ng-----------------------------------------
function ActiveTB()
	Say2("<color=yellow>T�t nh�t t�i r�i ng��i t�nh t�ng ta l� v�t g� ��y?",8,1,"",
        "T�ng b�nh ch�ng H�t d� ./banhhatde",
        "T�ng b�nh ch�ng Th�t heo/banhthitheo",
        "T�ng b�nh ch�ng Th�t b�/banhthitbo",
        "T�ng b�nh ch�ng Th�p c�m/banhthapcam",
        "T�ng b�nh ch�ng Th��ng/banhthuong",
	"T�ng b�nh ch�ng H�o H�n/banhhaohan",
	"T�ng b�nh ch�ng Th��ng H�n/banhthuonghan",
	"K�t th�c ��i tho�i/no")
end
------------------------------------------------B�nh H�t D�-------------------------------------------
function banhhatde()
	if(GetLevel() < 50) then
		Talk(1, "", "<color=yellow>��ng c�p 50 m�i c� th� t�ng b�nh.")
return end
	local nBHD1 = GetItemCount(97,3)
	local nTotal = nBHD1
	if(nTotal < 1) then
		Talk(1,"","C�n c� <color=red>1 <color> <color=yellow>B�nh H�t D� <color> c�c h� kh�ng mang theo r�i!")
	return end
	AddOwnExp(1500000)
        nTotal = 1;
	for i=1,3 do
		if(nTotal > 0 and nBHD1 > 0) then
		DelItem(97,3)
		nTotal = nTotal - 1
		nBHD1 = nBHD1 - 1
                end
        end
                Talk(1,"","<color=yellow>C�m �n l�ng t�t c�a ng��i!Ta c� m�n qu� nh� <color><color=red>1.500.000 <color><color=yellow>Exp xin h�y nh�n cho.")
end

------------------------------------------------B�nh Th�t Heo-------------------------------------------
function banhthitheo()
	if(GetLevel() < 50) then
		Talk(1, "", "<color=yellow>��ng c�p 50 m�i c� th� t�ng b�nh.")
return end
	local nBTH1 = GetItemCount(98,3)
	local nTotal = nBTH1
	if(nTotal < 1) then
		Talk(1,"","C�n c� <color=red>1 <color> <color=yellow>B�nh Th�t Heo <color> c�c h� kh�ng mang theo r�i!")
	return end
	AddOwnExp(2500000)
        nTotal = 1;
	for i=1,3 do
		if(nTotal > 0 and nBTH1 > 0) then
		DelItem(98,3)
		nTotal = nTotal - 1
		nBTH1 = nBTH1 - 1
                end
        end
                Talk(1,"","<color=yellow>C�m �n l�ng t�t c�a ng��i!Ta c� m�n qu� nh� <color><color=red>2.500.000 <color><color=yellow>Exp xin h�y nh�n cho.")
end

------------------------------------------------B�nh Th�t B�-------------------------------------------
function banhthitbo()
	if(GetLevel() < 50) then
		Talk(1, "", "<color=yellow>��ng c�p 50 m�i c� th� t�ng b�nh.")
return end
	local nBTB1 = GetItemCount(99,3)
	local nTotal = nBTB1
	if(nTotal < 1) then
		Talk(1,"","C�n c� <color=red>1 <color> <color=yellow>B�nh Th�t B� <color> c�c h� kh�ng mang theo r�i!")
	return end
	AddOwnExp(3500000)
        nTotal = 1;
	for i=1,3 do
		if(nTotal > 0 and nBTB1 > 0) then
		DelItem(99,3)
		nTotal = nTotal - 1
		nBTB1 = nBTB1 - 1
                end
        end
                Talk(1,"","<color=yellow>C�m �n l�ng t�t c�a ng��i!Ta c� m�n qu� nh� <color><color=red>3.500.000 <color><color=yellow>Exp xin h�y nh�n cho.")
end

------------------------------------------------B�nh Th�p C�m-------------------------------------------
function banhthapcam()
	if(GetLevel() < 80) then
		Talk(1, "", "<color=yellow>��ng c�p 80 m�i c� th� t�ng b�nh.")
return end
	local nBTC1 = GetItemCount(100,3)
	local nTotal = nBTC1
	if(nTotal < 1) then
		Talk(1,"","C�n c� <color=red>1 <color> <color=yellow>B�nh Th�p C�m <color> c�c h� kh�ng mang theo r�i!")
	return end
	AddOwnExp(5000000)
        nTotal = 1;
	for i=1,3 do
		if(nTotal > 0 and nBTC1 > 0) then
		DelItem(100,3)
		nTotal = nTotal - 1
		nBTC1 = nBTC1 - 1
                end
        end
                Talk(1,"","<color=yellow>C�m �n l�ng t�t c�a ng��i!Ta c� m�n qu� nh� <color><color=red>5.000.000 <color><color=yellow>Exp xin h�y nh�n cho.")
end

------------------------------------------------B�nh Ch�ng Th��ng-------------------------------------------
function banhthuong()
	if(GetLevel() < 90) then
		Talk(1, "", "<color=yellow>��ng c�p 90 m�i c� th� t�ng b�nh.")
return end
	local nBCT1 = GetItemCount(159,5)
	local nTotal = nBCT1
	if(nTotal < 1) then
		Talk(1,"","C�n c� <color=red>1 <color> <color=yellow>B�nh Ch�ng Th��ng <color> c�c h� kh�ng mang theo r�i!")
	return end
	AddOwnExp(5000000)
        AddItem(0,5,148,0,0,0,0,0)
        nTotal = 1;
	for i=1,3 do
		if(nTotal > 0 and nBCT1 > 0) then
		DelItem(159,5)
		nTotal = nTotal - 1
		nBCT1 = nBCT1 - 1
                end
        end
            Talk(1,"","<color=yellow>C�m �n l�ng t�t c�a ng��i! Ta c� m�n qu� nh� t�ng l�i ng��i xin h�y nh�n cho.")
end

------------------------------------------------B�nh Ch�ng H�o H�n-------------------------------------------
function banhhaohan()
	if(GetLevel() < 90) then
		Talk(1, "", "<color=yellow>��ng c�p 90 m�i c� th� t�ng b�nh.")
return end
	local nBHH1 = GetItemCount(158,5)
	local nTotal = nBHH1
	if(nTotal < 1) then
		Talk(1,"","C�n c� <color=red>1 <color> <color=yellow>B�nh Ch�ng H�o H�n <color> c�c h� kh�ng mang theo r�i!")
	return end
	AddOwnExp(10000000)
        AddItem(0,5,147,0,0,0,0,0)
        nTotal = 1;
	for i=1,3 do
		if(nTotal > 0 and nBHH1 > 0) then
		DelItem(158,5)
		nTotal = nTotal - 1
		nBHH1 = nBHH1 - 1
                end
        end
            Talk(1,"","<color=yellow>C�m �n l�ng t�t c�a ng��i! Ta c� m�n qu� nh� t�ng l�i ng��i xin h�y nh�n cho.")
end

------------------------------------------------B�nh Ch�ng Th��ng H�n-------------------------------------------
function banhthuonghan()
	if(GetLevel() < 120) then
		Talk(1, "", "<color=yellow>��ng c�p 120 m�i c� th� t�ng b�nh.")
return end
	local nBTH1 = GetItemCount(157,5)
	local nTotal = nBTH1
	if(nTotal < 1) then
		Talk(1,"","C�n c� <color=red>1 <color> <color=yellow>B�nh Ch�ng Th��ng H�n <color> c�c h� kh�ng mang theo r�i!")
	return end
	AddOwnExp(15000000)
        AddItem(0,5,149,0,0,0,0,0)
        nTotal = 1;
	for i=1,3 do
		if(nTotal > 0 and nBTH1 > 0) then
		DelItem(157,5)
		nTotal = nTotal - 1
		nBTH1 = nBTH1 - 1
                end
        end
            Talk(1,"","<color=yellow>C�m �n l�ng t�t c�a ng��i! Ta c� m�n qu� nh� t�ng l�i ng��i xin h�y nh�n cho.")
end

------------------------------------------------***END***-------------------------------------------
------------------------------------------------***END***-------------------------------------------
function no()
end;
