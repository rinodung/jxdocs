
-- ThongHonPro
-- npc Thong HOn

-------------------------------------------------Script*By* ThongHOnPro-----------------------------------------
---------------------------------------------------Ban Ngua--------------------------------------------
--Include("\\script\\header\\thonghon.lua");

function main()
dofile("script/global/npcchucnang/thonghonpro.lua")
THONGHON()
end
--------------------------------------------------XEP LOAI NGUA------------------------------------------------
function THONGHON()
	--Say("Xin ch�o ��i hi�p <color=wood>"..GetName().."<color>....!  \n��i Hi�p c�n mua Ng�a <bclr=blue>VIP <bclr>ph�i kh�ng?\nXin m�i ��i hi�p ch�n ng�a c�n mua d��i ��y..!",4,
		--		"Ng�a VIP-- lo�i 1/nguavip1",
			--	"Ng�a VIP-- lo�i 2/nguavip2",
				--"Ng�a Ho�ng Kim/nguahk",
				 Talk(1,"no","Xin ch�o <bclr=blue>"..GetName().."<bclr>...! \n<color=red>C�c H� C�n G� C� Li�n H� Ta Nh�..!<color>\nYahoo: <color=yellow>kid_chiyeumotnguoi<color>\nSkype: <color=green>thonghon565<color>\nFacebook:<color=green> fb.com/thong.hon")
				--"Ta Ch� Ti�n ���ng Gh� Qua Th�i./no") 
			   
				         
end


function no()
end