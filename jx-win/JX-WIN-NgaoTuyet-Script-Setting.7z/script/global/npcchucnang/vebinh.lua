
-- Ken Nguyen
-- npc Ve binh thanh mon
function main(NpcIndex)
	local TALK_MORE = "T�n g�u/tangau";
	local END_TALK = "R�i kh�i/no";
	Say(10833,2,
		TALK_MORE,
		END_TALK)
end;

function tangau()
end;

function no()
end;
