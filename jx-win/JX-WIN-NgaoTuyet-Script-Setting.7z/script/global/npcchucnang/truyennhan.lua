---Script by Ken Nguyen
--Vo lam truyen nhan

function main(NpcIndex)
	local END_TALK = "K�t th�c ��i tho�i/no";
	Say2(11312,2,1,"",
		"Minh nguy�t tr�n/minhnguyet",
		END_TALK)
end

function minhnguyet()
	if GetLevel() >= 10 then
		NewWorld(523,1592,3280)
	end
end

function no()
end;
