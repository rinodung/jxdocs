
-- Ken Nguyen
-- npc Su gia lien dau

Include("\\script\\header\\taskid.lua");
Include("\\script\\header\\testgame.lua");
Include("\\script\\header\\nhanhotro.lua");
---Include("\\script\\header\\ngua.lua");--
--Include("\\script\\header\\phiphong.lua");
Include("\\script\\header\\skill150.lua");
Include("\\script\\header\\trangbi.lua");
Include("\\script\\item\\\\tools\\tool0059.lua");
Include("\\script\\header\\monphaiheader.lua");
Include("\\script\\header\\chuyensinh.lua");
Include("\\script\\global\\npcchucnang\\phantang.lua");--cong tiem nang

function main(NpcIndex)
	Say2("Xin ch�o ��i hi�p <color=wood>"..GetName().."<color>....!\n��i Hi�p mu�n <bclr=blue>Chuy�n Sinh <bclr>��ng kh�ng?\nXin m�i ��i hi�p ch�n ch�c n�ng d��i ��y..! ",2,1,"",
		"Ta mu�n chuy�n Sinh/chuyensinh",
		"��ng/no")
end

function no()
end

function chuyensinh()
---SkillHS() - do add skill hoa son . roi game
ChuyenSinh()
end