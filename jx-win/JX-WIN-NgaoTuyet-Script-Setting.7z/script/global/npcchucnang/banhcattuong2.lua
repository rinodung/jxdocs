--Script By CaRot.
--T�ng B�nh.

function main()
--dofile("script/global/npcchucnang/banhcattuong.lua")
ActiveTB()
end
--function ActiveTB()
	--Talk(1,"","<color=violet>Hi�n T�i Event ch�a Ho�t ��ng!")
--end
------------------------------------------------B�nh C�t T��ng-----------------------------------------
function ActiveTB()
	Say2("<color=yellow>T�t nh�t t�i r�i ng��i t�nh t�ng ta l� v�t g� ��y?",9,1,"",
        "T�ng b�nh ch�ng H�t d�./banhhatde",
        "T�ng b�nh ch�ng Th�t heo./banhthitheo",
        "T�ng b�nh ch�ng Th�p c�m B�ch Qu�./banhthapcambq",
        "T�ng b�nh ch�ng Th�p c�m Th��ng h�n./banhthapcamth",
	"K�t th�c ��i tho�i/no")
end
------------------------------------------------B�nh H�t D�-------------------------------------------
function banhhatde()
	if(GetLevel() < 80) then
		Talk(1, "", "<color=yellow>��ng c�p 80 m�i c� th� t�ng b�nh.")
return end
	local nBHD1 = GetItemCount(31,5)
	local nTotal = nBHD1
	if(nTotal < 1) then
		Talk(1,"","C�n c� <color=red>1 <color> <color=yellow>B�nh H�t D� <color> c�c h� kh�ng mang theo r�i!")
	return end
	AddOwnExp(1500000)
        nTotal = 1;
	for i=1,3 do
		if(nTotal > 0 and nBHD1 > 0) then
		DelItem(31,5)
		nTotal = nTotal - 1
		nBHD1 = nBHD1 - 1
                end
        end
                Talk(1,"","<color=yellow>C�m �n l�ng t�t c�a ng��i!Ta c� m�n qu� nh� <color><color=red>1.500.000 <color><color=yellow>Exp xin h�y nh�n cho.")
end

------------------------------------------------B�nh Th�t Heo-------------------------------------------
function banhthitheo()
	if(GetLevel() < 80) then
		Talk(1, "", "<color=yellow>��ng c�p 80 m�i c� th� t�ng b�nh.")
return end
	local nBTH1 = GetItemCount(32,5)
	local nTotal = nBTH1
	if(nTotal < 1) then
		Talk(1,"","C�n c� <color=red>1 <color> <color=yellow>B�nh Th�t Heo <color> c�c h� kh�ng mang theo r�i!")
	return end
	AddOwnExp(1500000)
        nTotal = 1;
	for i=1,3 do
		if(nTotal > 0 and nBTH1 > 0) then
		DelItem(32,5)
		nTotal = nTotal - 1
		nBTH1 = nBTH1 - 1
                end
        end
                Talk(1,"","<color=yellow>C�m �n l�ng t�t c�a ng��i!Ta c� m�n qu� nh� <color><color=red>1.500.000 <color><color=yellow>Exp xin h�y nh�n cho.")
end

------------------------------------------------B�nh Th�t B�-------------------------------------------
function banhthitbo()
	if(GetLevel() < 80) then
		Talk(1, "", "<color=yellow>��ng c�p 80 m�i c� th� t�ng b�nh.")
return end
	local nBTB1 = GetItemCount(178,5)
	local nTotal = nBTB1
	if(nTotal < 1) then
		Talk(1,"","C�n c� <color=red>1 <color> <color=yellow>B�nh Th�t B� <color> c�c h� kh�ng mang theo r�i!")
	return end
	AddOwnExp(1500000)
        nTotal = 1;
	for i=1,3 do
		if(nTotal > 0 and nBTB1 > 0) then
		DelItem(178,5)
		nTotal = nTotal - 1
		nBTB1 = nBTB1 - 1
                end
        end
                Talk(1,"","<color=yellow>C�m �n l�ng t�t c�a ng��i!Ta c� m�n qu� nh� <color><color=red>1.500.000 <color><color=yellow>Exp xin h�y nh�n cho.")
end

------------------------------------------------B�nh Th�p C�m-------------------------------------------
function banhthapcam()
	if(GetLevel() < 80) then
		Talk(1, "", "<color=yellow>��ng c�p 80 m�i c� th� t�ng b�nh.")
return end
	local nBTC1 = GetItemCount(179,5)
	local nTotal = nBTC1
	if(nTotal < 1) then
		Talk(1,"","C�n c� <color=red>1 <color> <color=yellow>B�nh Th�p C�m <color> c�c h� kh�ng mang theo r�i!")
	return end
	AddOwnExp(1500000)
        nTotal = 1;
	for i=1,3 do
		if(nTotal > 0 and nBTC1 > 0) then
		DelItem(179,5)
		nTotal = nTotal - 1
		nBTC1 = nBTC1 - 1
                end
        end
                Talk(1,"","<color=yellow>C�m �n l�ng t�t c�a ng��i!Ta c� m�n qu� nh� <color><color=red>1.500.000 <color><color=yellow>Exp xin h�y nh�n cho.")
end
------------------------------------------------B�nh Th�p C�m M�t Ong-------------------------------------------
function banhthapcammo()
	if(GetLevel() < 80) then
		Talk(1, "", "<color=yellow>��ng c�p 80 m�i c� th� t�ng b�nh.")
return end
	local nBTC1 = GetItemCount(180,5)
	local nTotal = nBTC1
	if(nTotal < 1) then
		Talk(1,"","C�n c� <color=red>1 <color> <color=yellow>B�nh Th�p C�m M�t Ong <color> c�c h� kh�ng mang theo r�i!")
	return end
	AddOwnExp(2000000)
        nTotal = 1;
	for i=1,3 do
		if(nTotal > 0 and nBTC1 > 0) then
		DelItem(180,5)
		nTotal = nTotal - 1
		nBTC1 = nBTC1 - 1
                end
        end
                Talk(1,"","<color=yellow>C�m �n l�ng t�t c�a ng��i!Ta c� m�n qu� nh� <color><color=red>2.000.000 <color><color=yellow>Exp xin h�y nh�n cho.")
end
------------------------------------------------B�nh Th�p C�m B�c C�u-------------------------------------------
function banhthapcambc()
	if(GetLevel() < 80) then
		Talk(1, "", "<color=yellow>��ng c�p 80 m�i c� th� t�ng b�nh.")
return end
	local nBTC1 = GetItemCount(181,5)
	local nTotal = nBTC1
	if(nTotal < 1) then
		Talk(1,"","C�n c� <color=red>1 <color> <color=yellow>B�nh Th�p C�m B�c B�u <color> c�c h� kh�ng mang theo r�i!")
	return end
	AddOwnExp(2000000)
        nTotal = 1;
	for i=1,3 do
		if(nTotal > 0 and nBTC1 > 0) then
		DelItem(181,5)
		nTotal = nTotal - 1
		nBTC1 = nBTC1 - 1
                end
        end
                Talk(1,"","<color=yellow>C�m �n l�ng t�t c�a ng��i!Ta c� m�n qu� nh� <color><color=red>2.000.000 <color><color=yellow>Exp xin h�y nh�n cho.")
end
------------------------------------------------B�nh Th�p C�m B�ch qu�-------------------------------------------
function banhthapcambq()
	if(GetLevel() < 80) then
		Talk(1, "", "<color=yellow>��ng c�p 80 m�i c� th� t�ng b�nh.")
return end
	local nBTC1 = GetItemCount(35,5)
	local nTotal = nBTC1
	if(nTotal < 1) then
		Talk(1,"","C�n c� <color=red>1 <color> <color=yellow>B�nh Th�p C�m B�ch Qu� <color> c�c h� kh�ng mang theo r�i!")
	return end
	AddOwnExp(2000000)
        nTotal = 1;
	for i=1,3 do
		if(nTotal > 0 and nBTC1 > 0) then
		DelItem(35,5)
		nTotal = nTotal - 1
		nBTC1 = nBTC1 - 1
                end
        end
                Talk(1,"","<color=yellow>C�m �n l�ng t�t c�a ng��i!Ta c� m�n qu� nh� <color><color=red>2.000.000 <color><color=yellow>Exp xin h�y nh�n cho.")
end
------------------------------------------------B�nh Th�p C�m Th��ng h�n-------------------------------------------
function banhthapcamth()
	if(GetLevel() < 80) then
		Talk(1, "", "<color=yellow>��ng c�p 80 m�i c� th� t�ng b�nh.")
return end
	local nBTC1 = GetItemCount(36,5)
	local nTotal = nBTC1
	if(nTotal < 1) then
		Talk(1,"","C�n c� <color=red>1 <color> <color=yellow>B�nh Th�p C�m Th��ng h�n <color> c�c h� kh�ng mang theo r�i!")
	return end
	AddOwnExp(2000000)
        nTotal = 1;
	for i=1,3 do
		if(nTotal > 0 and nBTC1 > 0) then
		DelItem(36,5)
		nTotal = nTotal - 1
		nBTC1 = nBTC1 - 1
                end
        end
                Talk(1,"","<color=yellow>C�m �n l�ng t�t c�a ng��i!Ta c� m�n qu� nh� <color><color=red>2.000.000 <color><color=yellow>Exp xin h�y nh�n cho.")
end

function banh01()
	local nTD = GetItemCount(21,3);
	if(nTD < 5) then
		Talk(1,"","Tr�n ng��i c�c h� kh�ng c� ��<color=red> 5 Ti�n ��ng.")
	return end
	DelItem(21,3,5)
	AddItem(0,5,29,0,0,5,0,0);
	Talk(1,"","B�n �� nh�n ���c <color=violet>1 Phi�u D� �o�n.")
end;
------------------------------------------------***END***-------------------------------------------
------------------------------------------------***END***-------------------------------------------
function no()
end;
