---Script by Carot
Include("\\script\\header\\taskid.lua");
Include("\\script\\header\\time.lua");
Include("\\script\\header\\tongkim.lua");
Include("\\script\\library\\worldlibrary.lua");
function main(NpcIndex)
dofile("script/global/npcchucnang/cthanhquan.lua")
ActiveCT()
end

function ActiveCT()
	Say("<bclr=white><color=red>Tr�n chi�n �ang di�n ra quy�t li�t. T��ng qu�n h�y mau d�n qu�n ra tr�n d�p lo�n !",4,
        "Gia Nh�p Phe C�ng Th�nh./gianhapcong",
        "Gia Nh�p Phe Th� Th�nh./gianhapthu",
        "T�m Hi�u C�ng Th�nh Chi�n./timhieu",
        "Th�i!Ta ch�a �� tu�i./no")
end

function gianhapcong()
	local TAB_CHIENTRUONG = {
			"Ng�i y�n ! �ang �i ��n Chi�n Tr��ng...",
		}
	if GetCash() >= 1 then
		NewWorld(221,1899,3583)
		SetFightState(0);
	        LeaveTeam()	--roi nhom, giai tan nhom 
	        SetRevPos(1,221) -- set phuc sinh ngay diem bao danh
	        SetTempRevPos(221,1899*32,3583*32) --set ve thanh duong suc ngay doanh trai.
	        SetCurCamp(chinhphai) --set phe phai'
	        SetRankEx(350) --phong danh hieu binh si~
	        SetPunish(1)	--bat tinh nang chet khong mat' gi
	        SetPKMode(1,1)--ep kieu chien dau
            end
		Msg2Player(TAB_CHIENTRUONG[0])
		Pay(10000)
end

function gianhapthu()
	local TAB_CHIENTRUONG = {
			"Ng�i y�n ! �ang �i ��n Chi�n Tr��ng...",
		}
	if GetCash() >= 1 then
		NewWorld(221,1524,3241)
		SetFightState(0); 
	        LeaveTeam()	--roi nhom, giai tan nhom
	        SetRevPos(2,325)
	        SetTempRevPos(221,1524*32,3241*32)
	        SetCurCamp(taphai)
	        SetRankEx(355)
	        SetPunish(1)
	        SetPKMode(1,1)
	    end
		Msg2Player(TAB_CHIENTRUONG[0])
		Pay(10000)
end

function timhieu()
	Talk(5,"",12252,12259,12260,12261,12262)
end;

function no()
end;
