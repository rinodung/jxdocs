--Include("\\script\\header\\taskid.lua");
--Script By*Carot. Ng�i sao may m�n
function main(nNpcIdx)
		if (GetLevel() < 150) then
			Talk(1,"","<color=yellow>��ng c�p 150 tr� l�n m�i h�i ���c Sao May M�n.")
		return end
	
		local nTime = GetRestTime();
		local nShowTime = floor(nTime/18);
	if (nTime > 0) then
		if(nShowTime <= 0) then
		nShowTime = 1
		end
		Msg2Player("<color=green>Sau "..nShowTime.." gi�y m�i h�i ti�p ���c.")
	return end
	SetTimer(180,1)
	local id = 0;
	id = ItemSetAdd(0,5,145,0,0,5,RANDOM(1,10),0)
        SetItemDate(id,10080) -- 7 ng�y
	AddItemID(id);
	AddNews("<color=green>"..GetName().."<color> �� h�i ���c Sao May M�n.");
end
