--Script By CaRot.
--T�ng B�nh.

function main()
dofile("script/global/npcchucnang/tinhnghiagiangho.lua")
ActiveTNGH()
end
------------------------------------------------T��ng ��i-----------------------------------------
function ActiveTNGH()
Talk(1,"","<bclr=blue>           Ch�o m�ng <color=yellow>"..GetName().."<color> �� gia nh�p  <bclr> <enter><enter><color=red>                 [V� L�m Truy�n K�]                                  <color=yellow>[T�nh Ngh�a Giang H�]<color> <enter><enter>         <bclr=blue>Ch�c <color=yellow>"..GetName().."<color> m�t ng�y m�i vui v�.")
end
