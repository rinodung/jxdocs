--Author: By Carot.
--Date: 30/1/2015
-- Script Uy Thac--Nh�n Exp tr�n m�ng v� r�i m�ng.
Include("\\script\\library\\worldlibrary.lua")
Include("\\script\\global\\serverlib.lua")
Include("\\script\\header\\tasklist.lua")

----------------------------------
-- H�m ch�nh
----------------------------------
Include("\\script\\library\\worldlibrary.lua");
Include("\\script\\header\\taskid.lua");
Include("\\dulieu\\giaodich.lua");
KETTHUC ="Tho�t/no"
function main()
dofile("script/global/npcchucnang/bachthulam.lua")
	Say2("<color=yellow>B�ch Thu L�m:<color> Hoan ngh�nh <color=pink>"..GetName().." <color>��n v�i th� gi�i ki�m hi�p, h�nh t�u giang h� c� nhi�u gian nan nh�ng c�ng kh�ng �t ni�m vui",7,1,"",
	"S� ki�n t�t nguy�n ��n/nguyendan",
	"��u gi�. /daugia",
	"Nh�n th��ng ho�t ��ng/thuonghd",
	KETTHUC)
end
------------------He thong dau gia by Han May Luon -------------------
function daugia()
if CheckName(1) >= 1 then
local a = MaxMin(0,1000,3,1) -- gia ban nho nhat
local b = MaxMin(a,1000,3,1) -- gia ban nho thu hai
local c = MaxMin(0,1000,6,2) -- gia mua lon nhat
local d = MaxMin(0,c,6,2) -- gia mua lon thu hai
Say2("Gi� B�n ti�n ��ng:<enter>"..a.." V     "..CheckNum(a,1,2).." T�  <enter>"..b.." V      "..CheckNum(b,1,2).." T� <enter>Gi� Mua ti�n ��ng: <enter>"..c.." V     "..CheckNum(c,2,2).." T� <enter>"..d.." V     "..CheckNum(d,2,2).." T� ",7,1,"",
	"B�n ��ng./giaodich",
	"Mua ��ng./giaodich",
	"Chuy�n ti�n (v�n l��ng) l�n ��u gi�./giaodich",
	"Chuy�n ti�n ��ng l�n ��u gi�./giaodich",
--	"L�m m�i ��u gi�./lammoi",
	"Ki�m tra th�ng tin c� nh�n./dulieu",
	"Kh�ng./no")
else
Say2("�� tham gia ��u gi� c�n ��ng k�, ph� k�ch ho�t l� 100 v�n l��ng.<enter> ��ng k� 1 l�n s� s� d�ng m�i m�i. ",2,1,"",
"��ng k�. /yes",
"Kh�ng./no")
end
end
function dulieu()
Say2("<color=green>"..GetName().." <color> c� "..CheckName(4).." v�n - "..CheckName(7).." ti�n ��ng tr�n ��u gi�.<enter>�ang Mua "..CheckName(5).." T� gi� "..CheckName(6).." v�n.<enter>�ang b�n "..CheckName(2).." T� gi� "..CheckName(3).." v�n. ",3,1,"",
	"R�t ti�n ��ng./laytien",
	"R�t ti�n v�n./laytien",
	"Tho�t/no")
end
function laytien(nsel)
local nGD = CheckName(3) + CheckName(6)
if nGD == 0 then
	if nsel == 0 then
		Say2("Hi�n t�i b�n c� <color=green>"..CheckName(7).." <color>ti�n ��ng tr�n ��u gi�",2,1,"",
			"Nh�p s� l��ng. /rutTD",
			"�� ta suy ngh� l�i. /no")
			end
	if nsel == 1 then
		Say2("Hi�n t�i b�n c� <color=green>"..CheckName(4).." <color>v�n l��ng tr�n ��u gi�.<enter><color=pink>Khi r�t ti�n �� tr�nh b� m�t ti�n h�y c�t h�t ti�n trong h�nh trang. ",2,1,"",
			"Nh�p s� l��ng. /rutTV",
			"�� ta suy ngh� l�i. /no")
			end
else
Say2("�ang giao d�ch tr�n ��u gi� <enter>Gi� b�n:<color=red> "..CheckName(3).."<color><enter>Gi� mua: <color=yellow>"..CheckName(6).." <color>v. <enter>Ng��i c� mu�n thay ��i giao d�ch kh�ng",2,1,"",
	"H�y giao d�ch/huygd",
	"Kh�ng/no")
end
end
function rutTD()
Input("SoTD");
end
function SoTD(num)
local nTD = CheckName(7)
local nTT = CheckName(1)
if (num == 0 or num > nTD) then
Msg2Player("ch�a nh�p s� ti�n ��ng ho�c ti�n ��ng kh�ng ��. ")
end
if (num > 0 or num <= nTD) then
GIAO_DICH[nTT][7] = GIAO_DICH[nTT][7] - num
giaodich = TaoBang(GIAO_DICH,"GIAO_DICH","")
SaveData("dulieu/giaodich.lua",giaodich)
NhanTD(num)
end
end
function rutTV()
local nTien = GetCash()
if nTien > 0 then
Msg2Player("H�y c�t h�t ti�n trong h�nh nang m�i c� th� ti�n h�nh r�t ti�n. ")
else
Input("SoTV");
end
end
function SoTV(num)
local nTV = CheckName(4)
local nTT = CheckName(1)
if (num == 0 or num > nTV) then
Msg2Player("ch�a nh�p s� ti�n ��ng ho�c ti�n kh�ng ��. ")
end
if (num > 0 or num <= nTV) then
	if num > 200000 then
Msg2Player("M�i l�n r�t ti�n kh�ng v��t qu� 200.000 v�n l��ng")
elseif num <= 200000 then
Earn(num*10000)
GIAO_DICH[nTT][4] = GIAO_DICH[nTT][4] - num
giaodich = TaoBang(GIAO_DICH,"GIAO_DICH","")
SaveData("dulieu/giaodich.lua",giaodich)
Msg2Player("B�n v�a nh�n <color=yellow>"..num.." <color>v�n tr�n h� th�ng ��u gi�.")
end
end
end

function giaodich(nsel)
local a = MaxMin(0,1000,3,1) -- gia ban nho nhat
local b = CheckNum(a,1,2) -- so luong ban theo gia nho nhat
local c = MaxMin(0,1000,6,2) -- gia mua lon nhat
local d = CheckNum(c,2,2) -- so luong mua theo gia lon nhat
local nGD = CheckName(3) + CheckName(6)
if nGD == 0 then
	if nsel == 0 then
		Say2("Gi� mua ��ng tr�n ��u gi�:<enter><color=yellow>"..c.."<color> v�n - <color=red>"..d.." <color>T� ",3,1,"",
			"Nh�p gi� b�n./nhapban",
			"Tho�t/no")
		end
	if nsel == 1 then
		Say2("Gi� b�n ��ng tr�n ��u gi�:<enter><color=yellow>"..a.."<color> v�n - <color=red>"..b.." <color>T� ",3,1,"",
			"Nh�p gi� mua./nhapmua",
			"Tho�t/no")
		end
	if nsel == 2 then
	Input("chuyentienvan");
	end
	if nsel == 3 then
	Input("chuyentiendong");
	end
else
Say2("�ang giao d�ch tr�n ��u gi� <enter>Gi� b�n:<color=red> "..CheckName(3).."<color><enter>Gi� mua: <color=yellow>"..CheckName(6).." <color>v. <enter>Ng��i c� mu�n thay ��i giao d�ch kh�ng",2,1,"",
	"H�y giao d�ch/huygd",
	"Kh�ng/no")
end
end
function huygd()
local nTT = CheckName(1)
GIAO_DICH[nTT][2] =0
GIAO_DICH[nTT][3] =0
GIAO_DICH[nTT][5] =0
GIAO_DICH[nTT][6] =0
giaodich = TaoBang(GIAO_DICH,"GIAO_DICH","")
SaveData("dulieu/giaodich.lua",giaodich)
Msg2Player("H�y b� giao d�ch tr�n ��u gi� th�nh c�ng. C� th� giao d�ch l�i.")
end

function chuyentienvan(num)
local nTien = GetCash()
local nSL = floor(nTien/10000)
if ( num == 0 or num > nSL) then
Msg2Player("ch�a nh�p s� ti�n ho�c ti�n trong t�i kh�ng ��. ")
end
if ( num > 0 and num <=  nSL) then
local nTT = CheckName(1)
GIAO_DICH[nTT][4] = GIAO_DICH[nTT][4] + nSL
Pay(nSL*10000)
giaodich = TaoBang(GIAO_DICH,"GIAO_DICH","")
SaveData("dulieu/giaodich.lua",giaodich)		
Msg2Player("B�n v�a chuy�n th�nh c�ng <color=yellow>"..num.."<color> v�n l��ng l�n h� th�ng ��u gi�. ")
end
end
function chuyentiendong(num)
local nSL = GetItemCount(21,3)
if ( num == 0 or num > nSL) then
Msg2Player("ch�a nh�p s� ti�n ��ng ho�c ti�n ��ng trong t�i kh�ng ��. ")
end
if ( num > 0 and num <=  nSL) then
for i =1,num do	
DelItem(21,3)
end
local nTT = CheckName(1)
GIAO_DICH[nTT][7] = GIAO_DICH[nTT][7] + num
giaodich = TaoBang(GIAO_DICH,"GIAO_DICH","")
SaveData("dulieu/giaodich.lua",giaodich)	
Msg2Player("B�n v�a chuy�n th�nh c�ng <color=yellow>"..num.."<color> ti�n ��ng l�n h� th�ng ��u gi�. ")
end
end
-- ban tien dong
function nhapban()
Input("giaban");
end
function giaban(num)
if (num == 0 or num > 999)then
Msg2Player("Gi� giao d�ch t� 1 ��n 999 v�n. ")
end
if(num > 0 and num <= 999)then
local nTD = CheckName(7)
local nTB = nTD*num
	SetTask(TASK_GIAODICH,num)
Say2("H� th�ng : Gi� b�n ��ng c�a b�n l� "..num.." v�n. <enter>S� ti�n ��ng tr�n ��u gi� c�a b�n "..nTD..". <enter>B�n h�t ���c "..nTB.." v�n l��ng",2,1,"",
	"Nh�p S� Ti�n ��ng/soban",
	"Thoat/no")
end
end
function soban()
	Input("giaodichban");
end
function giaodichban(num)
if (num == 0 ) then
SetTask(TASK_GIAODICH,0)
Msg2Player("Ch�a nh�p s� l��ng Ti�n ��ng ")
end
if (num > 0 )then
local k = CheckName(1)
local a = GetTask(TASK_GIAODICH)
local nSL = GIAO_DICH[k][7]
	if num > nSL then
		Msg2Player("S� l��ng ti�n ��ng kh�ng ��")
	end
	if num <= nSL then
		GIAO_DICH[k][2] = num
		GIAO_DICH[k][3] = a
		giaodich = TaoBang(GIAO_DICH,"GIAO_DICH","")
		SaveData("dulieu/giaodich.lua",giaodich)
Msg2Player("B�n v�a b�n "..num.." ti�n ��ng gi� "..a.." v�n l��ng v�o ��u gi�.")
for n =1,getn(GIAO_DICH) do
Reset_Daugia()
	end
end
end
end
-- mua tien dong
function nhapmua()
Input("giamua");
end
function giamua(num)
if( num == 0 or num > 999) then
Msg2Player("Gi� giao d�ch t� 1 ��n 999 v�n. ")
end
if (num > 0 and num <= 999) then
local nTV = CheckName(4)
local nTM = floor(nTV/num)
SetTask(TASK_GIAODICH,num)
Say2("H� th�ng : Gi� mua ��ng c�a b�n l� "..num.." v�n. <enter>B�n c� "..nTV.." v�n l��ng tr�n ��u gi�. <enter>C� th� mua t�i �a "..nTM.." ti�n ��ng.",2,1,"",
	"Nh�p S� Ti�n ��ng/somua",
	"Thoat/no")
end
end
function somua()
Input("giaodichmua");
end
function giaodichmua(num)
local a = GetTask(TASK_GIAODICH) -- gia mua 
local nTien = CheckName(4)
local nMua = a*num
	if nTien < nMua  then
		Msg2Player("S� l��ng ti�n kh�ng ��")
	end
	if nTien >= nMua then
		local i = CheckName(1)
		GIAO_DICH[i][6] = a
		GIAO_DICH[i][5] = num
		giaodich = TaoBang(GIAO_DICH,"GIAO_DICH","")
		SaveData("dulieu/giaodich.lua",giaodich)		
Msg2Player("B�n v�a mua "..num.." ti�n ��ng gi� "..a.." v�n l��ng tr�n ��u gi�.")	
for n =1,getn(GIAO_DICH) do
Reset_Daugia()
	end
end
end


--------------------------------------

-- dang ky
function yes()
if GetCash() >= 1000000 then
GIAO_DICH[getn(GIAO_DICH)+1] = {GetName(),0,0,0,0,0,0} 
----{GetName() ,0,        0,         0,         0,		0,			0} 
--- ( Name -   TD ban - Gia ban TD -Tien DG - TD mua -Gia mua TD - TDong GD)
giaodich = TaoBang(GIAO_DICH,"GIAO_DICH","")
SaveData("dulieu/giaodich.lua",giaodich)
Pay(1000000)
Msg2Player("��ng k� ��u gi� th�nh c�ng")
else
Msg2Player("Ph� ��ng k� l� 100 v�n. B�n kh�ng c� �� ti�n. ")
end
end
------------------------------------
-- Cac cong thuc tinh trong GD --
			----------
function Reset_Daugia() -- ham reset dau gia( thuc hien cac giao dich tren dau gia)
local a = MaxMin(0,1000,3,1) -- gia ban nho nhat 3
local b = MaxMin(0,1000,6,2) -- gia mua lon nhat 6
local c = CheckNum(a,1,3)
local d = CheckNum(b,2,3)
if b >= a then -- khi gia mua lon hon gia ban thuc hien giao dich theo gia ban nho nhat
local SoBan = GIAO_DICH[c][2] -- so tien dong ban
local SoMua = GIAO_DICH[d][5] -- so tien dong mua
	if SoBan > SoMua then
	----- thang mua
		GIAO_DICH[d][4] = GIAO_DICH[d][4] - a*SoMua
		GIAO_DICH[d][7] = GIAO_DICH[d][7] + SoMua
		GIAO_DICH[d][5] = 0
		GIAO_DICH[d][6] = 0
	----- thang ban	
		GIAO_DICH[c][4] = GIAO_DICH[c][4] + a*SoMua
		GIAO_DICH[c][7] = GIAO_DICH[c][7] - SoMua
		GIAO_DICH[c][2] = GIAO_DICH[c][2] - SoMua
	end
	if SoBan < SoMua then
	----- thang mua
		GIAO_DICH[d][4] = GIAO_DICH[d][4] - a*SoBan
		GIAO_DICH[d][7] = GIAO_DICH[d][7] + SoBan
		GIAO_DICH[d][5] = GIAO_DICH[d][5] - SoBan
	----- thang ban	
		GIAO_DICH[c][4] = GIAO_DICH[c][4] + a*SoBan
		GIAO_DICH[c][7] = GIAO_DICH[c][7] - SoBan
		GIAO_DICH[c][2] = 0
		GIAO_DICH[c][3] = 0
	end
	if SoBan == SoMua then
	----- thang mua
		GIAO_DICH[d][4] = GIAO_DICH[d][4] - a*SoBan
		GIAO_DICH[d][7] = GIAO_DICH[d][7] + SoBan
		GIAO_DICH[d][5] = 0
		GIAO_DICH[d][6] = 0
	----- thang ban	
		GIAO_DICH[c][4] = GIAO_DICH[c][4] + a*SoBan
		GIAO_DICH[c][7] = GIAO_DICH[c][7] - SoBan
		GIAO_DICH[c][2] = 0
		GIAO_DICH[c][3] = 0
	end
giaodich = TaoBang(GIAO_DICH,"GIAO_DICH","")
SaveData("dulieu/giaodich.lua",giaodich)			
end
if b < a then -- gia mua nho hon gia ban giu nguyen giao dich
end
end
function CheckName(number)
local b = 0
for i = 1,getn(GIAO_DICH) do
if GIAO_DICH[i][1] == GetName() then
a = GIAO_DICH[i][number]
b = i
end
end
if number == 1 then
return b -- thu tu cua thang A trong bang GD
end
if number > 1 then
return a -- Chi so cac cot cua thang A
end
end

function MaxMin(nMin,nMax,a,b)
--local nMax = 1000
--local nMin = 0
-- gia ban tu 1 den 999
-- a =3 gia ban, a = 6 gia mua
-- b = 1 nho nhat b = 2 lon nhat
if b == 1 then -- gia nho nhat trong khoang nMin, nMax
	for i = 1,getn(GIAO_DICH) do
		if GIAO_DICH[i][a] > nMin and GIAO_DICH[i][a] < nMax then	
			nMax = GIAO_DICH[i][a]
		end
	end
if nMax == 1000 then 
return 0 -- khong co GD nao tren dau gia
else
return nMax -- gia nho nhat
end
end
if b == 2 then -- gia lon nhat trong khoang nMin, nMax
	for i = 1,getn(GIAO_DICH) do
		if GIAO_DICH[i][a] > nMin and GIAO_DICH[i][a] < nMax then	
			nMin = GIAO_DICH[i][a]
		end
	end
return nMin -- gia lon nhat ( neu = 0 la ko co GD nao
end
end
function CheckGD(a,b)
local nTT = 0
for i =1,getn(GIAO_DICH) do
	if a == GIAO_DICH[i][b] then
		nTT = i
	end
return nTT
end
end
		
function CheckNum(a,b,c)
-- a: gia TD mua( b = 1) hoac ban ( b = 2)
-- c: So TD tuong ung cua a ( c=1) hoac tong so TD voi gia a ( c =2) hoac thu tu cua a trong bang ( c=3)
local nMua = 0
local nTong = 0
local d = b*3
for i =1,getn(GIAO_DICH) do
if a == GIAO_DICH[i][d] then
	nMua = GIAO_DICH[i][d-1]
	nTong = nTong +GIAO_DICH[i][d-1]
	nTab = i
	end
end
if c == 1 then
return nMua
end
if c == 2 then
return nTong
end
if c == 3 then
return nTab
end
end
function NhanTD(a)
	if a <= 50 then
	AddItem(0,3,21,0,0,5,a,0)
		end
	if a > 50 then
		local nSoLan = floor(a/50)
		local nSoLe = a - nSoLan*50
		if nSoLe == 0 then
		for i =1,nSoLan do
			AddItem(0,3,21,0,0,5,50,0)
			end
		end
		if nSoLe > 0 then
		for i =1,nSoLan do
			AddItem(0,3,21,0,0,5,50,0)
			end
		AddItem(0,3,21,0,0,5,nSoLe,0)
			end
		end
Msg2Player("B�n nh�n t� h� th�ng ��u gi� <color=yellow>"..a.." <color>ti�n ��ng. ")		
end
----------------------------------

-------------- END ---------------------------
function no()
end