---Script by Carot
--Th�n T�i

function main(NpcIndex)
dofile("script/global/npcchucnang/thantai.lua")
ActiveTT()
end

function ActiveTT()
	Say("<color=yellow>Ng��i c� �� c� b� <color> <color=green> Ph�c , L�c , Th� <color> <color=yellow> r�i �!",3,
        "Ta �� c� ��./doithuong",
        "T�m hi�u ho�t ��ng./timhieu",
        "Th�i!Ta ch�a ��./no")
end
--------------------------------------------------***��i V�t Ph�m***-------------------------------------
function doithuong()
	local nVP1 = GetItemCount(1703,3)
	local nVP2 = GetItemCount(1704,3)
	local nVP3 = GetItemCount(1705,3)
	local nTotal = nVP1 + nVP2 + nVP3
	if(nTotal < 3) then
		Talk(1,"","C�n �� b� <color=yellow>Ph�c , L�c , Th�<color>. Ng��i kh�ng mang �� r�i!")
	return end
        AddItem(0,5,143,0,0,0,0,0)
	nTotal = 3;
		for i=1,3 do
			if(nTotal > 0 and nVP1 > 0) then
			DelItem(1703,3)
			nTotal = nTotal - 1
			nVP1 = nVP1 - 1
			end
		end
		for i=1,3 do
			if(nTotal > 0 and nVP2 > 0) then
			DelItem(1704,3)
			nTotal = nTotal - 1
			nVP2 = nVP2 - 1
			end
		end
		for i=1,3 do
			if(nTotal > 0 and nVP3 > 0) then
			DelItem(1705,3)
			nTotal = nTotal - 1
			nVP3 = nVP3 - 1
			end
             end
                        Talk(1,"","<color=yellow> ��y l� <color> <color=red>Truy�n T�ng Ph�<color> <color=yellow> h�y nh�n l�y.")
end

--------------------------------------------------T�m Hi�u---------------------------------------	
function timhieu()
	Talk(1,"","Ki�m �� 3 ch� <color=red> Ph�c , L�c , Th� <color> <color=yellow>Th�n T�i <color>s� t�ng b�n <color=green>Truy�n T�ng Ph� Ho�t ��ng Xu�n<color> gi�p b�n nhanh ch�ng v�o khu v�c vui Xu�n!")
end;

--------------------------------------------------***END***---------------------------------------
 --------------------------------------------------***END***-------------------------------------
function no()
end;
