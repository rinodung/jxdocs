-- Ken Nguyen
-- npc Hang rong
--Include("\\script\\library\\worldlibrary.lua");
--Include("\\script\\header\\taskid.lua");
function main(NpcIndex)
	local NOT_TRADE = "K�t th�c ��i tho�i/no";
	Say2(10093,1,1,"",
		NOT_TRADE)
end;

function no()
end;
