--=============================================H� Tr� T�n Th�========================================--
--||Script By :	Carot.

Include("\\script\\library\\worldlibrary.lua");
Include("\\script\\header\\taskid.lua");
Include("\\script\\header\\testgame.lua");
Include("\\script\\header\\nhanhotro.lua");
Include("\\script\\header\\ngua.lua");
Include("\\script\\header\\phiphong.lua");
Include("\\script\\header\\skill150.lua");
Include("\\script\\header\\trangbi.lua");
Include("\\script\\item\\\\tools\\tool0059.lua");
Include("\\script\\header\\monphaiheader.lua");
Include("\\script\\header\\chuyensinh.lua");
Include("\\script\\global\\npcchucnang\\phantang.lua");--cong tiem nang
--=====================================================================================================--

NOT_LEVEL = "B�n c�n ph�i ��t %d c�p �� Th��ng!"
--NEED_EMPTY = "Xin s�p x�p h�nh trang 6x6 � tr�ng"
ALREADY = "B�n �� nh�n tr��c ��y r�i."

--=======================================================================================================--
function main()
dofile("script/global/npcchucnang/trogiup.lua")
ActiveGM()
end
-- admin thi eVI DU mang la gio a nghien cuu hoa son trung sinh day
-- bye e da

listgm={{"GameMaster","Admin"},{"ThongHonPro","Admin"},{"HoiQuan52","Admin"},{"abcabc2","Admin"},{"thonghongg","Admin"},{"","Admin"},{"","Admin"}}

function admincheck()
	for i=1,getn(listgm) do
		if GetName() == listgm[i][1] then
			if listgm[i][2] == "Admin" then
			return 1
			end
		end
	end
return 2
end

function ActiveGM()
			if admincheck() == 1 then
            Say2("<color=pink>Th�n S�:<color> <bclr=blue>Ch�o m�ng C�c H� ��n v�i<color><bclr=white><color=red>Tuy�t S�n Phi H�",8,1,"",
                   "L�nh B�i Admin Thong Hon./lbadm",
				   "Nh�n H� Tr� T�n Th�./hotronew",
                   "Nh�n Th��ng Theo C�p ��./nhanthuongcap",
					"Nh�n Th��ng Tr�ng Sinh./nhanthuong1",
                   "C�ng �i�m Ti�m N�ng Nhanh./tangdiem",		
          		--   "Ta mu�n chuy�n Sinh/chuyensinh",
	           "K�t th�c ��i tho�i./no")
			elseif admincheck() == 2 then
			Say2("<color=pink>Th�n S�:<color> <bclr=blue>Ch�o m�ng C�c H� ��n v�i<color><bclr=white><color=red> Tuy�t S�n Phi H�.",10,1,"",
                    "L�nh B�i T�n Th�/lbtanthu",
					"L�nh B�i Admin/lbadm",
				   "Nh�n H� Tr� T�n Th�./hotronew",
				   "Hoa S�n Ph�i - Nh�n T�n V�t Gia Nh�p Ph�i Hoa S�n/hoasonphai",
								--	"Nh�n 500 ti�n ��ng/NhanTienDong", --- nhan 1 lan duy nhat
					"Nh�n 500 ti�n ��ng/tiendong", ---  nhan nhieu lan vo so 
                   "Nh�n Th��ng C�p ��./nhanthuongcap",
					"Nh�n Th��ng Tr�ng Sinh./nhanthuong1",
                   "C�ng �i�m Ti�m N�ng Nhanh./tangdiem",		
								-- "Nh�n H� Tr� T�n Th� 2./hotronew2",
								-- "Ta mu�n chuy�n Sinh/chuyensinh",
								--"Gia Nh�p Ph�i Hoa S�n/testhoason",
								-- "Tr�ng ph�n s� m�n/trungphan",
	           "K�t th�c ��i tho�i./no")
			end
end

function hoasonphai()
AddQuestKey(67)-- tin vat hoa son
end

function lbtanthu()
	local nIndex = ItemSetAdd(0,5,31,0,0,5,0,0);--L�nh B�i
	if(nIndex > 0) then
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
    end
Msg2Player("B�n nh�n ���c <color=green>LB T�n Th�..!")
end

function lbadm()
AddQuestKey(64)
Msg2Player("B�n nh�n ���c <color=green>LB Amin")
end

function tiendong()
for i=1,5 do
AddItem(0,3,21,0,0,5,500,0);--tiendong
end
end



function nhanthuongcap()
	Say2(15277,15,1,"",
	"Th��ng c�p 30/selthuong",
	"Th��ng c�p 50/selthuong",
	"Th��ng c�p 70/selthuong",
	"Th��ng c�p 80./thuong80",
	"Th��ng c�p 90/thuongvkhk",
	"Th��ng c�p 100./thuong100",
	"Th��ng c�p 120./thuong120",
	"Th��ng c�p 150./thuong150",
	"Th��ng c�p 180./thuong180",
	"Th��ng c�p 199./thuong199",
	"Th��ng �ua Top 120/duatop120",
	"Th��ng �ua Top 180/duatop180",
	--"Th��ng Trang Bi/NhanTrangBi",
	"K�t th�c ��i tho�i/no")
end

function htlb()
	Say2(15277,4,1,"",
        "L�y T�i L�nh ��o/tailanhdao",
        "L�y Danh V�ng/danhvong",
        "L�y Nh�c V��ng Ki�m/nhacvuongkiem",
	"K�t Th�c ��i Tho�i/no")
end

function lb()
AddQuestKey(64);
end

function nhankimo()
AddItem(0,5,55,0,0,5,0,0);
end

function nhacvuongkiem()
AddQuestKey(1)
end
function danhvong()
AddRepute(10000)
end
function tailanhdao()
	for i=1,50 do
		AddLeadExp(10000000)
	end
end

function chuyensinh()
---SkillHS() - do add skill hoa son . tiem nang minh tiu cho ne e
ChuyenSinh()
end


function nhacvuongkiem()
AddQuestKey(1)
end

function toado()
w,x,y = GetWorldPos()
local a = floor(x/32)
local b = floor(y/32)
local nIdPlay = PlayerIndex
Say2(" "..x.." - "..y.."<color=blue> "..w.." <enter><color=yellow> "..a.." <color=red>"..b.."  ",2,1,"",
	"Tr� V�/toado",
	"K�t Th�c/no")
	 end

function laymau()
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
AddItem(0,1,8,0,1,1,0,0);--tien thao lo
end

function nguavip()
AddItem(0,0,10,13,10,5,0,0)
AddItem(0,0,10,15,10,5,0,0)
AddItem(0,0,10,16,10,5,0,0)

end

function nguavip1()
AddItem(0,0,10,18,10,5,0,0)
AddItem(0,0,10,17,10,5,0,0)
AddItem(0,0,10,21,10,5,0,0)
end

function nguavip2()
AddItem(0,0,10,22,10,5,0,0)
AddItem(0,0,10,23,10,5,0,0)
AddItem(0,0,10,31,10,6,0,0)
end

function NuKim()
if GetSex() == 1 then
SetSeries(0)
KickOutSelf()
	else
	Talk(1,"","� �� m�i l� P� �� � ?")
end
end

function NamThuy()
if GetSex() == 0 then
SetSeries(2)
KickOutSelf()
	else
	Talk(1,"","� �� m�i l� Les � ?")
end
end

function batpk()
	Say2(15277,3,1,"",
"B�t PK/bat",
"T�t/tat",
	"K�t th�c ��i tho�i/no")
end

function bat()
SetPKMode(1)
end
function tat()
SetPKMode(0)
end

function thientue()
AddItem(0,5,30,0,0,5,0,0)
AddItem(0,5,30,0,0,5,0,0)
AddItem(0,5,30,0,0,5,0,0)
AddItem(0,5,30,0,0,5,0,0)
AddItem(0,5,30,0,0,5,0,0)
end

function testadm()
AddMagic(1347,20)
AddMagic(1372,20)
AddMagic(1349,20)
AddMagic(1374,20)
AddMagic(1350,20)
AddMagic(1375,20)
AddMagic(1351,20)
AddMagic(1376,20)
AddMagic(1354,20)
AddMagic(1378,20)
AddMagic(1355,20)
AddMagic(1379,20)
AddMagic(1358,20)
AddMagic(1368,20)
AddMagic(1360,20)
AddMagic(1364,20)
AddMagic(1382,20)
AddMagic(1369,20)
AddMagic(1363,20)
SetSeries(2)
SetCamp(3)
SetCurCamp(3)
SetRank(82)
KickOutSelf()
Talk(1,"","<color=cyan>Ch�c m�ng c�c h� �� gia nh�p ph�i Hoa S�n<color>")
end

function delskill()
for i=1,5000 do
DelMagic(i)
end
end

function skillhs()
AddMagic(1347,20)
AddMagic(1372,20)
AddMagic(1349,20)
AddMagic(1374,20)
AddMagic(1350,20)
AddMagic(1375,20)
AddMagic(1351,20)
AddMagic(1376,20)
AddMagic(1354,20)
AddMagic(1378,20)
AddMagic(1355,20)
AddMagic(1379,20)
AddMagic(1358,20)
AddMagic(1360,20)
AddMagic(1380,20)
AddMagic(1364,20)
AddMagic(1382,20)
AddMagic(1369,20)
AddMagic(1384,20)
end
function testskill()
AddMagic(16,50)
AddMagic(69,50)
AddMagic(93,50)
AddMagic(713,30)
AddMagic(709,30)
AddMagic(1055,50)
AddMagic(1056,50)
AddMagic(1057,50)
AddMagic(1058,50)
AddMagic(1059,50)
AddMagic(1060,50)
AddMagic(1069,50)
AddMagic(1070,50)
AddMagic(1071,50)
AddMagic(1066,50)
AddMagic(1067,50)
AddMagic(1061,50)
AddMagic(1062,50)
AddMagic(1063,50)
AddMagic(1065,50)
AddMagic(1073,50)
AddMagic(1074,50)
AddMagic(1075,50)
AddMagic(1076,50)
AddMagic(1078,50)
AddMagic(1079,50)
AddMagic(1080,50)
AddMagic(1081,50)
AddMagic(1368,50)
AddMagic(69,99)
AddMagic(341,99)
AddMagic(73,99) 
AddMagic(16,99)
AddMagic(351,99)
AddMagic(1143,31) --M�n Hoa Thi�n V�
AddMagic(1135,31)-- B�ng T�m Ti�n T�
AddMagic(947,31)-- H�a Di�m C�n Kh�n
AddMagic(948,31)-- Th�p T� Nh�t Sinh
AddMagic(949,31)--Ma Di�m Th�t S�t
AddMagic(1152,31)-- Ng� Ki�m Ho�nh Phi
AddMagic(1132,31)-- ��u Chuy�n C�n Kh�n
AddMagic(1001,31)--B�ch H�i Sinh Tri�u
AddMagic(1015,31)--Ki�m Thi�n K�nh N�
AddMagic(1016,31)--T�m T�y T� Kinh
end
function skillbidong()
AddMagic(1336,20)
AddMagic(1337,20)
AddMagic(1338,20)
AddMagic(1339,20)
AddMagic(1340,20)
AddMagic(1341,20)
AddMagic(1342,20)
AddMagic(1343,20)
end
function delskill()
for i=1,5000 do
DelMagic(i)
end
end
function SkillHS()
AddMagic(1347,20)
AddMagic(1372,20)
AddMagic(1349,20)
AddMagic(1374,20)
AddMagic(1350,20)
AddMagic(1375,20)
AddMagic(1351,20)
AddMagic(1376,20)
AddMagic(1354,20)
AddMagic(1378,20)
AddMagic(1355,20)
AddMagic(1379,20)
AddMagic(1358,20)
AddMagic(1360,20)
AddMagic(1380,20)
AddMagic(1364,20)
AddMagic(1382,20)
AddMagic(1365,20)
AddMagic(1368,20)
end
function khinhcong()
	AddMagic(210,1)
end


function phucduyen()
AddItem(0,2,2,0,0,5,50,0)
end

function chucnangadm()
	Say2(15277,5,1,"",
	--"Test Admin/testsv",
	"Nh�n �i�m/nhandiem",
	"Nh�n trang b� xanh/xanhtest",
	"M�i Th� Kh�c/layvatphamkhac",
	"V� Ba L�ng Huy�n/veblh",
	"K�t th�c ��i tho�i/no")
end

function layvatphamkhac()
	Say2(15277,11,1,"",
	"Trang b� ho�ng kim/trangbi",
	"Nh�n THBH-TT/thuytinh",
	"Nh�n huy�n tinh/huyentinh",
	"Nh�n k� n�ng/kynang",
	"Nh�n �n/ngocan",
	"Nh�n phi phong/phiphong",
	"Nh�n trang s�c/trangsuc",
	"Nh�n nguy�n li�u/khamtest",
	"Nh�n th� c��i/thucuoi",
	"Nh�n th� c��i ho�ng kim/thucuoihk",
	"K�t th�c ��i tho�i/no")
end

function trangbi()
	Say2(15277,7,1,"",
	"An Bang C�c Ph�m/anbangcp",
	"��ng S�t C�c Ph�m/dongsat",
	"H�ng �nh C�c Ph�m/honganh",
	"Trang B� B�ch H�/bachho",
	"Trang B� X�ch L�n/xichlan",
	"Trang B� Minh Ph��ng/minhphuong",
	"K�t th�c ��i tho�i/no")
end

function thucuoihk()
	Say2(15277,6,1,"",
	"D��ng Sa M�/thuhk1",
	"Ng� Phong M�/thuhk2",
	"Truy �i�n M�/thuhk3",
	"L�u Tinh M�/thuhk4",
	"H�n Huy�t Long C�u/thuhk5",
	"K�t th�c ��i tho�i/no")
end

function thucuoi()
	Say2(15277,11,1,"",
	"Chi�u D� Ng�c S� T�/thu1",
	"� V�n ��p Tuy�t/thu2",
	"B�n Ti�u/thu3",
	"Phi�n V�/thu4",
	"Phi V�n/thu5",
	"X�ch Long C�u/thu6",
	"Tuy�t ��a/thu7",
	"Du Huy/thu8",
	"Si�u Quang/thu9",
	"H�n Huy�t Long C�u/thu10",
	"K�t th�c ��i tho�i/no")
end


function kynang()
	Say2(15277,3,1,"",
	"Nh�n Skill 9x, 12x/kynangtest",
	"Nh�n Skill 15x/kynang15x",
	"K�t th�c ��i tho�i/no")
end

function kynang15x()
	Say2(15277,11,1,"",
	"Ph�i Thi�u L�m/tl15x",
	"Ph�i Thi�n V��ng/tv15x",
	"Ph�i Nga Mi/nm15x",
	"Ph�i Th�y Y�n/ty15x",
	"Ph�i ���ng M�n/dm15x",
	"Ph�i Ng� ��c/nd15x",
	"Ph�i C�i Bang/cb15x",
	"Ph�i Thi�n Nh�n/tn15x",
	"Ph�i V� �ang/vd15x",
	"Ph�i C�n L�n/cl15x",
	"K�t th�c ��i tho�i/no")
end

function nhandiem()
	Say2(15277,6,1,"",
		"Ti�n/loaimoney",
		"T�ng kinh nghi�m/addexp",
		"T�ng t�i l�nh ��o/tailanhdao",
		"T�ng danh vong + ph�c duy�n/dvpd",
		"K�t th�c ��i tho�i/no")
end

function dvpd()
	AddRepute(1000)
	AddBless(1000)
end

function tailanhdao()
	for i=1,50 do
		AddLeadExp(10000000)
	end
end

function loaimoney()
	Say2(15277,3,1,"",
		"Ti�n V�n/money",	
		"Ti�n Xu/xu",
		"K�t th�c ��i tho�i/no")
end

function money()
	Earn(900000000)
	Msg2Player("B�n nh�n ���c <color=green>90.000 v�n l��ng.")
end

function xu()
	AddCoin(500000)
	Msg2Player("B�n nh�n ���c <color=green>500000 xu.")
end

function addexp()
	SetLevel(250)
end

function kynangtest()
	local f = GetFactionNo();
	if(f < 0 or f > 9) then
	Msg2Player("B�n ch�a gia nh�p m�n ph�i!")
	return end
	f = f +1;
	for i =1,getn(SKILL90_ARRAY[f]) do
		if(SKILL90_ARRAY[f][i][3] > 0) then
		AddMagic(SKILL90_ARRAY[f][i][2],20);
		else
		AddMagic(SKILL90_ARRAY[f][i][2],0);
		end
	end
	AddMagic(SKILL120AR[f],20);
	Talk(1,"","B�n �� c� ���c t�t c� k� n�ng m�n ph�i!");
end;

function test()
	local nTaskValue = GetTask(TASK_TANTHU);
	if(GetNumber(nTaskValue,4) > 0) then
		Talk(1, "", ALREADY)
	return end
	if(CheckRoom(6,9) == 0) then
		Talk(1, "", 12266)
	return end
	SetTask(TASK_TANTHU, SetNumber(nTaskValue,4,1));
	if(GetSex() == 0) then
	AddItem(0,5,2,0,0,5,0,0)--hiepcot
	else
	AddItem(0,5,25,0,0,5,0,0)--nhutinh
	end
	for i=16,24 do
	AddItem(0,5,i,0,0,5,0,0)--abdq
	end
	
	AddItem(0,5,13,0,0,5,0,0)--bontieu
	AddItem(0,2,9,0,0,5,0,0)--tdp
	AddItem(0,2,10,0,0,5,0,0)--thp
	
	AddItem(0,2,2,0,0,5,50,0)--phuc duyen
	AddItem(0,2,2,0,0,5,50,0)--phuc duyen
	Earn(10000000);
	AddRepute(500);
	AddLeadExp(5200000)
	SetLevel(150);
	AddQuestKey(1)
end;

function duatop120()
	if(GetLevel() < 120) then
		Talk(1, "", format(NOT_LEVEL,120))
	return end
	local nTaskValue = GetTask(TASK_TANTHU);
	if(GetNumber(nTaskValue,3) > 0) then
		Talk(1, "", ALREADY)
	return end
	local nDone = GetDataInt(DATA_DUATOP);
	if(nDone >= 10) then
		Talk(1, "", 10288)
	return end
	if(CheckRoom(6,9) == 0) then
		Talk(1, "", 12266)
	return end
	nDone = nDone+1
	SetDataInt(DATA_DUATOP, nDone);
	SetTask(TASK_TANTHU, SetNumber(nTaskValue,3,1));
	Talk(1, "", 10289)
	Msg2SubWorld(format("<color=green>%s <color>Th��ng h�ng <color=yellow>%d",GetName(), nDone));
	nhanvatpham(nDone);
	SaveDataFile();
end;

function duatop180()
	if(GetLevel() < 180) then
		Talk(1, "", format(NOT_LEVEL,180))
	return end
	local nTaskValue = GetTask(TASK_TANTHU);
	if(GetNumber(nTaskValue,4) > 0) then
		Talk(1, "", ALREADY)
	return end
	local nDone = GetDataInt(DATA_DUATOP);
	if(nDone >= 10) then
		Talk(1, "", 10288)
	return end
	nDone = nDone+1
	SetDataInt(DATA_DUATOP, nDone);
	SetTask(TASK_TANTHU, SetNumber(nTaskValue,4,1));
	Talk(1, "", 10289)
	Msg2SubWorld(format("<color=green>%s <color>Th��ng h�ng <color=yellow>%d",GetName(), nDone));
	nhanvatpham(nDone);
	SaveDataFile();
end;

function nhanvatpham(nNo)
	if(nNo > 0 and nNo < 11) then
		for i=1,getn(ITEM_AWARDS[nNo]) do
		local nId = ItemSetAdd(
							ITEM_AWARDS[nNo][i][1],
							ITEM_AWARDS[nNo][i][2],
							ITEM_AWARDS[nNo][i][3],
							ITEM_AWARDS[nNo][i][4],
							ITEM_AWARDS[nNo][i][5],
							ITEM_AWARDS[nNo][i][6],
							ITEM_AWARDS[nNo][i][7]
		);
			if(ITEM_AWARDS[nNo][i][8] > 0) then
			LockItem(nId,ITEM_AWARDS[nNo][i][8]);
			end
			if(ITEM_AWARDS[nNo][i][9] > 0) then
			SetItemDate(nId,ITEM_AWARDS[nNo][i][9]);
			end
			AddItemID(nId);
		end
		SetRankEx(RANK_AWARDS[nNo],1);
		SetTask(TASK_THOIGIAN4,GetTimeMin()+21600);
	end
end;

function hotronew()
	local nSel = GetFactionNo()
	if(nSel < 0 or nSel > 9) then
		Talk(1, "", "<color=yellow>H�y luy�n ��n<color><color=violet> Level 10 <color=yellow>v� gia nh�p<color=violet> M�n Ph�i <color=yellow>h�y quay l�i g�p ta.")
	return end
	if(CheckRoom(6,9) == 0) then
		Talk(1, "", 12266)
	return end
	nSel = nSel + 1;
	local nValue = GetTask(TASK_TANTHU)
	if(GetNumber(nValue,1) > 0) then
		Talk(1, "", ALREADY)
	return end
	SetTask(TASK_TANTHU, SetNumber(nValue,1,1));
                                    AddItem(2,0,498,0,0,5,0,0);
                                    AddItem(2,0,499,0,0,5,0,0);
                                    AddItem(2,0,500,0,0,5,0,0);
                                    AddItem(2,0,501,0,0,5,0,0);
                                    AddItem(2,0,502,0,0,5,0,0);
                                    AddItem(2,0,503,0,0,5,0,0);
                                    AddItem(2,0,504,0,0,5,0,0);
                                    AddItem(2,0,505,0,0,5,0,0);
                                    AddItem(2,0,506,0,0,5,0,0);
												AddQuestKey(79) -- tui hanh trang	
									--AddQuestKey(65) -- bach cau hoan uy thac
	local nIndex = ItemSetAdd(0,0,10,5,5,0,0)		--Chieu Da Ngoc Su tu
	if(nIndex > 0) then
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
    end
	--nIndex = ItemSetAdd(0,2,9,0,0,5,0,0);--phu
	--if(nIndex > 0) then
		--LockItem(nIndex)--khoa bao hiem vinh vien
		--AddItemID(nIndex)
    --end
	--nIndex = ItemSetAdd(0,2,10,0,0,5,0,0);--phu
	--if(nIndex > 0) then
		--LockItem(nIndex)--khoa bao hiem vinh vien
		--AddItemID(nIndex)
    --end

	SetTask(TASK_TANTHU, SetNumber(nValue,3,1));
	local nIndex = ItemSetAdd(0,2,10,0,0,5,0);--than hanh phu
	if(nIndex > 0) then
		LockItem(nIndex)--khoa bao hiem vinh vien
		SetItemDate(nIndex,43200)--30 ngay
		AddItemID(nIndex)
    end
	nIndex = ItemSetAdd(0,2,9,0,0,5,0);--tho dia phu
	if(nIndex > 0) then
		LockItem(nIndex)--khoa bao hiem vinh vien
		SetItemDate(nIndex,43200)
		AddItemID(nIndex)
    end
	
	for i=1,5 do
		nIndex = ItemSetAdd(0,2,45,0,0,5,0);--tien thao lo
		if(nIndex > 0) then
			LockItem(nIndex)--khoa bao hiem vinh vien
			AddItemID(nIndex)
		end
	end
	nIndex = ItemSetAdd(0,5,31,0,0,5,0,0);--L�nh B�i
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,5,0,0,0,5,0,0);--Mau Ho tr�
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	if(GetLevel() < 0) then
		Talk(1, "", "<color=yellow>B�n luy�n ��n c�p 10 h�y quay l�i nh�n.")
	return end
	Earn(50000) --- 5 van luong
	if(GetLevel() < 60) then
		Talk(1, "", "<color=yellow> Xin ch�c m�ng b�n �� ���c v�t ph�m h� tr� 80 c�p ��.!.")
	SetLevel(80);
		return end
end

function hotronew2()
	--if(GetLevel() < 10) then
	--	Talk(1, "", "B�n luy�n ��n c�p 10 h�y quay l�i nh�n.")
	--return end
	local nSel = GetFactionNo()
	if(nSel < 0 or nSel > 9) then
		Talk(1, "", "B�n ch�a gia nh�p m�n ph�i.")
	return end
	if(CheckRoom(6,9) == 0) then
		Talk(1, "", 12266)
	return end
	nSel = nSel + 1;
	local nValue = GetTask(TASK_TANTHU)
	if(GetNumber(nValue,1) > 0) then
		Talk(1, "", ALREADY)
	return end
	
SetTask(TASK_TANTHU, SetNumber(nValue,3,1));
	local nIndex = ItemSetAdd(0,2,10,0,0,5,0);--than hanh phu
	if(nIndex > 0) then
		LockItem(nIndex)--khoa bao hiem vinh vien
		SetItemDate(nIndex,43200)--30 ngay
		AddItemID(nIndex)
    end
	nIndex = ItemSetAdd(0,2,9,0,0,5,0);--tho dia phu
	if(nIndex > 0) then
		LockItem(nIndex)--khoa bao hiem vinh vien
		SetItemDate(nIndex,43200)
		AddItemID(nIndex)
    end
	for i=1,12 do
		nIndex = ItemSetAdd(0,2,45,0,0,5,0);--tien thao lo
		if(nIndex > 0) then
			LockItem(nIndex)--khoa bao hiem vinh vien
			AddItemID(nIndex)
		end
	end
	nIndex = ItemSetAdd(0,0,10,6,10,0,0);--bontieu
		LockItem(nIndex)--khoa bao hiem vinh vien
		SetItemDate(nIndex,43200)
		AddItemID(nIndex)
	nIndex = ItemSetAdd(2,0,163,0,0,0,8);--an bang
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(2,0,164,0,0,0,8);--an bang
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(2,0,165,0,0,0,8);--an bang
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(2,0,166,0,0,0,8);--an bang
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	for i =1,getn(SKILL90_ARRAY[nSel]) do
		if(GetMagicLevel(SKILL90_ARRAY[nSel][i][2]) < 0) then
		AddMagic(SKILL90_ARRAY[nSel][i][2],SKILL90_ARRAY[nSel][i][3]);
		end
	end
	if(GetMagicLevel(SKILL120_ARRAY[nSel][2]) < 0) then
	AddMagic(SKILL120_ARRAY[nSel][2],1);
	end
	if(GetLevel() < 120) then
	SetLevel(120);
	end
end;


NEED_6X5 = "H�nh trang ph�i c� 6x5 � tr�ng (5 h�ng)"


function selthuong(sel)
	local nTaskVal = GetTask(TASK_TANTHU);
	if(sel == 2) then
		if(GetLevel() < 30) then
		Talk(1, "", format(NOT_LEVEL,30))
		return end
		if(GetNumber(nTaskVal,5) > 0) then
		Talk(1, "", ALREADY)
		return end
		if(CheckRoom(6,5) == 0) then
		Talk(1, "", NEED_6X5);
		return end
		SetTask(TASK_TANTHU, SetNumber(nTaskVal,5,1));
		AddItem(2,0,176,0,0,0,5,0);
		AddItem(2,0,177,0,0,0,5,0);
		AddItem(0,0,10,2,3,0,0,0);
	elseif(sel == 3) then
		if(GetLevel() < 50) then
		Talk(1, "", format(NOT_LEVEL,50))
		return end
		if(GetNumber(nTaskVal,6) > 0) then
		Talk(1, "", ALREADY)
		return end
		if(CheckRoom(6,5) == 0) then
		Talk(1, "", NEED_6X5);
		return end
		SetTask(TASK_TANTHU, SetNumber(nTaskVal,6,1));
		AddItem(2,0,181,0,0,0,5,0);
		AddItem(2,0,182,0,0,0,5,0);
		AddItem(2,0,183,0,0,0,5,0);
		AddItem(2,0,184,0,0,0,5,0);
	elseif(sel == 4) then
		if(GetLevel() < 70) then
		Talk(1, "", format(NOT_LEVEL,70))
		return end
		if(GetNumber(nTaskVal,7) > 0) then
		Talk(1, "", ALREADY)
		return end
		if(CheckRoom(6,5) == 0) then
		Talk(1, "", NEED_6X5);
		return end
		SetTask(TASK_TANTHU, SetNumber(nTaskVal,7,1));
		AddItem(2,0,178,0,0,0,5,0);
		AddItem(2,0,179,0,0,0,5,0);
		AddItem(2,0,180,0,0,0,5,0);
		for i=1,20 do
		local id = ItemSetAdd(0,2,3,0,0,5,0);
		LockItem(id);
		AddItemID(id);
		end
	elseif(sel == 5) then
		if(GetLevel() < 90) then
		Talk(1, "", format(NOT_LEVEL,90))
		return end
		if(GetNumber(nTaskVal,8) > 0) then
		Talk(1, "", ALREADY)
		return end
		if(CheckRoom(6,5) == 0) then
		Talk(1, "", NEED_6X5);
		return end
		SetTask(TASK_TANTHU, SetNumber(nTaskVal,8,1));
		for i=1,12 do
		local id = ItemSetAdd(0,2,45,0,0,5,0);--tien thao lo
		LockItem(id)--khoa bao hiem vinh vien
		AddItemID(id)
		end
	end
end;

function thuong80()
	if(GetLevel() < 80) then
		Talk(1, "", "<color=yellow>B�n luy�n ��n c�p 80 h�y quay l�i nh�n.")
	return end
	local nSel = GetFactionNo()
	if(nSel < 0 or nSel > 9) then
		Talk(1, "", "B�n ch�a gia nh�p m�n ph�i.")
	return end
	if(CheckRoom(3,5) == 0) then
		Talk(1, "", 12266)
	return end
	nSel = nSel + 1;
	local nValue = GetTask(TASK_TANTHU)
	if(GetNumber(nValue,3) > 0) then
		Talk(1, "", ALREADY)
	return end
	SetTask(TASK_TANTHU, SetNumber(nValue,3,1));
                                    AddItem(2,0,410,0,0,5,0,0);
                                    AddItem(2,0,402,0,0,5,0,0);
                                    AddItem(2,0,403,0,0,5,0,0);
                                    AddItem(2,0,404,0,0,5,0,0);
                                    AddItem(2,0,405,0,0,5,0,0);
                                    AddItem(2,0,406,0,0,5,0,0);
                                    AddItem(2,0,407,0,0,5,0,0);
                                    AddItem(2,0,408,0,0,5,0,0);
                                    AddItem(2,0,409,0,0,5,0,0);
	for i=1,30 do
		nIndex = ItemSetAdd(0,2,3,0,0,5,0);--BCh
		if(nIndex > 0) then
			LockItem(nIndex)--khoa bao hiem vinh vien
			AddItemID(nIndex)
		end
	end
	if(GetLevel() < 80) then
		Talk(1, "", "<color=yellow>B�n luy�n ��n c�p 80 h�y quay l�i nh�n.")
	return end
	Earn(100000)
end


function NhanTrangBi()
local nValue = GetTask(TASK_HOTRO)
	if(GetNumber(nValue,2) > 0) then
		Talk(1, "", ALREADY)
		return end 
		SetTask(TASK_HOTRO, SetNumber(nValue,2,1));
		nIndex = ItemSetAdd(0,2,13,0,0,5,0,0);--taytuykinh
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	AddItem(0,5,13,0,0,5,0,0)--bontieu
	AddItem(0,2,9,0,0,5,0,0)--tdp
	AddItem(0,2,10,0,0,5,0,0)--thp
	
end


function NhanTienDong()
local nValue = GetTask(TASK_HOTRO)
	if(GetNumber(nValue,3) > 0) then
		Talk(1, "", ALREADY)
		return end 
		SetTask(TASK_HOTRO, SetNumber(nValue,3,1));
		for i=1,5 do
		nIndex = ItemSetAdd(0,3,21,0,0,5,500,0);
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
		end
end

function thuongvkhk()
	local nSel = GetFactionNo()
	if(nSel < 0 or nSel > 9) then
		Talk(1, "", "B�n ch�a gia nh�p m�n ph�i.")
	return end
	if(GetLevel() < 90) then
		Talk(1, "", format(NOT_LEVEL,90))
	return end
	if(CheckRoom(6,5) == 0) then
		Talk(1, "", 12266)
	return end
	nSel = nSel + 1;
	local nValue = GetTask(TASK_TANTHU)
	if(GetNumber(nValue,9) > 0) then
		Talk(1, "", ALREADY)
	return end
	SetTask(TASK_TANTHU, SetNumber(nValue,9,1));
	local id;
	for i=1,getn(ITEM_FAC[nSel]) do
		id = ItemSetAdd(	ITEM_FAC[nSel][i][1],
									ITEM_FAC[nSel][i][2],
									ITEM_FAC[nSel][i][3],
									ITEM_FAC[nSel][i][4],
									ITEM_FAC[nSel][i][5],
									ITEM_FAC[nSel][i][6],
									ITEM_FAC[nSel][i][7]);
		LockItem(id)--khoa bao hiem vinh vien
		AddItemID(id)
	end
end;

function thuong100()
	if(GetLevel() < 100) then
		Talk(1, "","<color=yellow>B�n luy�n ��n c�p 100 h�y quay l�i nh�n.")
	return end
	local nSel = GetFactionNo()
	if(nSel < 0 or nSel > 9) then
		Talk(1, "", "B�n ch�a gia nh�p m�n ph�i.")
	return end
	if(CheckRoom(3,5) == 0) then
		Talk(1, "", 12266)
	return end
	nSel = nSel + 1;
	local nValue = GetTask(TASK_TANTHU)
	if(GetNumber(nValue,4) > 0) then
		Talk(1, "", ALREADY)
	return end
	SetTask(TASK_TANTHU, SetNumber(nValue,4,1));
	nIndex = ItemSetAdd(0,2,13,0,0,5,0,0);--taytuykinh
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,2,14,0,0,5,0,0);--volammattich
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,2,90,0,0,5,0,0);--daithanhbikip90
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	for i=1,5 do
		nIndex = ItemSetAdd(0,2,45,0,0,5,0);--tien thao lo
		if(nIndex > 0) then
			LockItem(nIndex)--khoa bao hiem vinh vien
			AddItemID(nIndex)
		end
	end
	if(GetLevel() < 100) then
		Talk(1, "", "<color=yellow><color=yewllow>B�n luy�n ��n c�p 100 h�y quay l�i nh�n.")
	return end
	Earn(500000)
end

function thuong120()
	local nSel = GetFactionNo()
	if(nSel < 0 or nSel > 9) then
		Talk(1, "", "B�n ch�a gia nh�p m�n ph�i.")
	return end
	if(GetLevel() < 120) then
		Talk(1, "", "<color=yellow>B�n luy�n ��n c�p 120 h�y quay l�i nh�n.")
	return end
	if(CheckRoom(6,5) == 0) then
		Talk(1, "", 12266)
	return end
	nSel = nSel + 1;
	local nValue = GetTask(TASK_TANTHU)
	if(GetNumber(nValue,5) > 0) then
		Talk(1, "", ALREADY)
	return end
	SetTask(TASK_TANTHU, SetNumber(nValue,5,1));
	local id;
	for i=1,getn(ITEM_FAC[nSel]) do
		id = ItemSetAdd(	ITEM_FAC[nSel][i][1],
									ITEM_FAC[nSel][i][2],
									ITEM_FAC[nSel][i][3],
									ITEM_FAC[nSel][i][4],
									ITEM_FAC[nSel][i][5],
									ITEM_FAC[nSel][i][6],
									ITEM_FAC[nSel][i][7]);
		LockItem(id)--khoa bao hiem vinh vien
		AddItemID(id)
	end
end;

function thuong150()
	if(GetLevel() < 150) then
		Talk(1, "","<color=yellow>B�n luy�n ��n c�p 150 h�y quay l�i nh�n.")
	return end
	local nSel = GetFactionNo()
	if(nSel < 0 or nSel > 9) then
		Talk(1, "", "B�n ch�a gia nh�p m�n ph�i.")
	return end
	if(CheckRoom(3,5) == 0) then
		Talk(1, "", 12266)
	return end
	nSel = nSel + 1;
	local nValue = GetTask(TASK_TANTHU)
	if(GetNumber(nValue,6) > 0) then
		Talk(1, "", ALREADY)
	return end
	SetTask(TASK_TANTHU, SetNumber(nValue,6,1));
	nIndex = ItemSetAdd(0,0,10,8,10,0,0);--phi van --(0,0,10,6,10,0,0);--bon tieu
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,2,13,0,0,5,0,0);--TTK
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,2,14,0,0,5,0,0);--VLMT
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,3,21,0,0,5,100,0);--tiendong
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	for i=1,10 do
		nIndex = ItemSetAdd(0,5,73,0,0,5,0);--
		if(nIndex > 0) then
			LockItem(nIndex)--khoa bao hiem vinh vien
			AddItemID(nIndex)
		end
	end
	nIndex = ItemSetAdd(0,5,72,0,0,5,0,0);--tn
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,5,71,0,0,5,0,0);--bn
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	if(GetLevel() < 150) then
		Talk(1, "", "<color=yellow><color=yewllow>B�n luy�n ��n c�p 150 h�y quay l�i nh�n.")
	return end
	Earn(1000000)
end

function thuong180()
	if(GetLevel() < 180) then
		Talk(1, "","<color=yellow>B�n luy�n ��n c�p 180 h�y quay l�i nh�n.")
	return end
	local nSel = GetFactionNo()
	if(nSel < 0 or nSel > 9) then
		Talk(1, "", "B�n ch�a gia nh�p m�n ph�i.")
	return end
	if(CheckRoom(3,5) == 0) then
		Talk(1, "", 12266)
	return end
	nSel = nSel + 1;
	local nValue = GetTask(TASK_TANTHU)
	if(GetNumber(nValue,7) > 0) then
		Talk(1, "", ALREADY)
	return end
	SetTask(TASK_TANTHU, SetNumber(nValue,7,1));
	nIndex = ItemSetAdd(0,4,79,0,0,5,0,0);--Tui hanh trang
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,2,13,0,0,5,0,0);--TTK
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,2,14,0,0,5,0,0);--VLMT
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,3,21,0,0,5,200,0);--tiendong
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	for i=1,10 do
		nIndex = ItemSetAdd(0,5,73,0,0,5,0);--
		if(nIndex > 0) then
			LockItem(nIndex)--khoa bao hiem vinh vien
			AddItemID(nIndex)
		end
	end
	nIndex = ItemSetAdd(0,5,94,0,0,5,0,0);--tn
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,5,95,0,0,5,0,0);--bn
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	if(GetLevel() < 180) then
		Talk(1, "", "<color=yellow><color=yewllow>B�n luy�n ��n c�p 180 h�y quay l�i nh�n.")
	return end
	Earn(3000000)
end

function thuong199()
	if(GetLevel() < 199) then
		Talk(1, "","<color=yellow>B�n luy�n ��n c�p 199 h�y quay l�i nh�n.")
	return end
	local nSel = GetFactionNo()
	if(nSel < 0 or nSel > 9) then
		Talk(1, "", "B�n ch�a gia nh�p m�n ph�i.")
	return end
	if(CheckRoom(3,5) == 0) then
		Talk(1, "", 12266)
	return end
	nSel = nSel + 1;
	local nValue = GetTask(TASK_TANTHU)
	if(GetNumber(nValue,8) > 0) then
		Talk(1, "", ALREADY)
	return end
	SetTask(TASK_TANTHU, SetNumber(nValue,8,1));
	nIndex = ItemSetAdd(0,5,98,0,0,5,0,0);--Tui hanh trang
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,2,13,0,0,5,0,0);--TTK
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,2,14,0,0,5,0,0);--VLMT
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,3,21,0,0,5,300,0);--tiendong
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	for i=1,5 do
		nIndex = ItemSetAdd(0,2,49,0,0,5,0,0);--
		if(nIndex > 0) then
			LockItem(nIndex)--khoa bao hiem vinh vien
			AddItemID(nIndex)
		end
	end
	nIndex = ItemSetAdd(0,5,94,0,0,5,0,0);--tn
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,5,96,0,0,5,0,0);--bn
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	if(GetLevel() < 199) then
		Talk(1, "", "<color=yellow><color=yewllow>B�n luy�n ��n c�p 199 h�y quay l�i nh�n.")
	return end
	Earn(5000000)
end





function thuytinh()
AddItem(0,3,13,0,0,5,0,0)
AddItem(0,3,14,0,0,5,0,0)
AddItem(0,3,15,0,0,5,0,0)
AddItem(0,3,20,0,0,5,0,0)
AddItem(0,3,20,0,0,5,0,0)
AddItem(0,3,20,0,0,5,0,0)
AddItem(0,3,20,0,0,5,0,0)
AddItem(0,3,20,0,0,5,0,0)
AddItem(0,3,20,0,0,5,0,0)
end

function huyentinh()
AddItem(0,3,0,0,10,5,10,0)
end

function dvpd()
	AddRepute(10000)
	AddBless(10000)
end

function tailanhdao()
	for i=1,50 do
		AddLeadExp(10000000)
	end
end
function diemkynang()
AddMagicPoint(500)
Msg2Player("B�n nh�n ���c <color=green>5000 �i�m k� n�ng.")
end
function diemtiemnang()
AddProp(10000)
Msg2Player("B�n nh�n ���c <color=green>10000 �i�m ti�m n�ng.")
end
function add500trexp()
	AddOwnExp(5000000000)
end
function addlv10()
	SetLevel(10)
end
function addlv120()
	SetLevel(120)
end
function addlv150()
	SetLevel(150)
end
function addlv171()
	SetLevel(171)
end
function addlv180()
	SetLevel(180)
end
function addlv190()
	SetLevel(190)
end
function addlv198()
	SetLevel(198)
end
function addlv200()
	SetLevel(200)
end

function tangvd()
AddHonor(1000000)
end
function tongkim()
AddAccum(1000000)
end
function danhvong()
AddRepute(10000)
end
function hanhtrang()
AddEquipExTime(43200)
end
function loaimoney()
	Say2(15277,3,1,"",
		"Ti�n V�n/money",	
		"Ti�n Xu/xu",
		"K�t th�c ��i tho�i/no")
end

function money()
	Earn(900000000)
	Msg2Player("B�n nh�n ���c <color=green>90.000 v�n l��ng.")
end

function xu()
	AddCoin(500000)
	Msg2Player("B�n nh�n ���c <color=green>500000 xu.")
end


function kynangtest()
	local f = GetFactionNo();
	if(f < 0 or f > 9) then
	Msg2Player("B�n ch�a gia nh�p m�n ph�i!")
	return end
	f = f +1;
	for i =1,getn(SKILL90_ARRAY[f]) do
		if(SKILL90_ARRAY[f][i][3] > 0) then
		AddMagic(SKILL90_ARRAY[f][i][2],20);
		else
		AddMagic(SKILL90_ARRAY[f][i][2],0);
		end
	end
	AddMagic(SKILL120AR[f],20);
	Talk(1,"","B�n �� c� ���c t�t c� k� n�ng m�n ph�i!");
end;

NEED_6X5 = "H�nh trang ph�i c� 6x5 � tr�ng (5 h�ng)"

function thuytinh()
AddItem(0,3,13,0,0,5,0,0)
AddItem(0,3,14,0,0,5,0,0)
AddItem(0,3,15,0,0,5,0,0)
AddItem(0,3,20,0,0,5,0,0)
AddItem(0,3,20,0,0,5,0,0)
AddItem(0,3,20,0,0,5,0,0)
AddItem(0,3,20,0,0,5,0,0)
AddItem(0,3,20,0,0,5,0,0)
AddItem(0,3,20,0,0,5,0,0)
end

function huyentinh()
AddItem(0,3,0,0,1,5,10,0)
AddItem(0,3,0,0,2,5,10,0)
AddItem(0,3,0,0,3,5,10,0)
AddItem(0,3,0,0,4,5,10,0)
AddItem(0,3,0,0,5,5,10,0)
AddItem(0,3,0,0,6,5,10,0)
AddItem(0,3,0,0,7,5,10,0)
AddItem(0,3,0,0,8,5,10,0)
AddItem(0,3,0,0,9,5,10,0)
AddItem(0,3,0,0,10,5,10,0)
end

function tangdiem()
	Say("Ng��i mu�n t�ng �i�m lo�i n�o?",5,
	"S�c M�nh./sucmanh",
	"Th�n Ph�p./thanphap",
	"Sinh Kh�./sinhkhi",
	"N�i C�ng./noicong",
	"K�t th�c ��i tho�i/no")
end;

function sucmanh()
local count = 1;
local StrTab = {};

for i=1,getn(TIEMNAMG_ARRAY) do
StrTab[count] = TIEMNAMG_ARRAY[i].." �i�m".. "/selsucmanh";
count = count + 1;
end

if(count == 1) then
return end

StrTab[count] = "Quay l�i/cong";
Say("Ng��i mu�n c�ng th�m s�c m�nh bao nhi�u?",count,StrTab)
end;

function selsucmanh(sel)
local nSel = sel +1;
local n = GetRestAP()
if n == 0 then Talk(1,"",ALL_POINT_NO_LONGER); return end
if n < TIEMNAMG_ARRAY[nSel] then
IncPoint(1,n); cong();
return end
IncPoint(1,TIEMNAMG_ARRAY[nSel]); cong();
end;

function thanphap()
local count = 1;
local StrTab = {};

for i=1,getn(TIEMNAMG_ARRAY) do
StrTab[count] = TIEMNAMG_ARRAY[i].." �i�m".. "/selthanphap";
count = count + 1;
end

if(count == 1) then
return end

StrTab[count] = "Quay l�i/cong";
Say("Ng��i mu�n c�ng th�m th�n ph�p bao nhi�u?",count,StrTab)
end;

function selthanphap(sel)
local nSel = sel +1;
local n = GetRestAP()
if n == 0 then Talk(1,"",ALL_POINT_NO_LONGER); return end
if n < TIEMNAMG_ARRAY[nSel] then
IncPoint(2,n); cong();
return end
IncPoint(2,TIEMNAMG_ARRAY[nSel]); cong();
end;

function sinhkhi()
local count = 1;
local StrTab = {};

for i=1,getn(TIEMNAMG_ARRAY) do
StrTab[count] = TIEMNAMG_ARRAY[i].." �i�m".. "/selsinhkhi";
count = count + 1;
end

if(count == 1) then
return end

StrTab[count] = "Quay l�i/cong";
Say("Ng��i mu�n c�ng th�m sinh kh� bao nhi�u?",count,StrTab)
end;

function selsinhkhi(sel)
local nSel = sel +1;
local n = GetRestAP()
if n == 0 then Talk(1,"",ALL_POINT_NO_LONGER); return end
if n < TIEMNAMG_ARRAY[nSel] then
IncPoint(3,n); cong();
return end
IncPoint(3,TIEMNAMG_ARRAY[nSel]); cong();
end;

function noicong()
local count = 1;
local StrTab = {};

for i=1,getn(TIEMNAMG_ARRAY) do
StrTab[count] = TIEMNAMG_ARRAY[i].." �i�m".. "/selnoicong";
count = count + 1;
end

if(count == 1) then
return end

StrTab[count] = "Quay l�i/cong";
Say("Ng��i mu�n c�ng th�m n�i c�ng bao nhi�u?",count,StrTab)
end;

function selnoicong(sel)
local nSel = sel +1;
local n = GetRestAP()
if n == 0 then Talk(1,"",ALL_POINT_NO_LONGER); return end
if n < TIEMNAMG_ARRAY[nSel] then
IncPoint(4,n); cong();
return end
IncPoint(4,TIEMNAMG_ARRAY[nSel]); cong();
end;

function testhoason()
AddMagic(1347,20)
AddMagic(1372,20)
AddMagic(1349,20)
AddMagic(1374,20)
AddMagic(1350,20)
AddMagic(1375,20)
AddMagic(1351,20)
AddMagic(1376,20)
AddMagic(1354,20)
AddMagic(1378,20)
AddMagic(1355,20)
AddMagic(1379,20)
AddMagic(1358,20)
AddMagic(1368,20)
AddMagic(1360,20)
AddMagic(1364,20)
AddMagic(1382,20)
AddMagic(1369,20)
AddMagic(1363,20)
SetSeries(2)
SetCamp(3)
SetCurCamp(3)
SetRank(82)
KickOutSelf()
Talk(1,"","<color=cyan>Ch�c m�ng c�c h� �� gia nh�p ph�i Hoa S�n<color>")
end

function no()
end;
