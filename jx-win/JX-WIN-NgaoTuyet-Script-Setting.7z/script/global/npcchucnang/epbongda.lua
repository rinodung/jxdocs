-- Script by Carot
-- �p B�ng Da
--=======================================================================================================--
function main()
	Talk(1,"","<color=violet>Hi�n T�i Event ch�a Ho�t ��ng!")
end
NEED_ROOM_EMPTY = "Qu� kh�ch h�y s�p x�p l�i h�nh trang."
NOT_TRADE = "��ng/no";
function main1()
	Say2("<color=red>Ti�u Th�n T�i :<color> L�u l�m m�i c� ng��i nh� ta l�m b�ng <enter><enter>Ch�t d�o + Ru�t Cao Su = <color=violet>B�ng Da<color><enter><enter>Ch�t D�o + Ru�t Cao Su + V� B�ng Ho�ng Kim = <color=violet>B�ng Ho�ng Kim <color><enter><enter>Ch�t D�o + Ru�t Cao Su + V� B�ng B�c Kim = <color=violet>B�ng B�ch Kim<color>",11,5,"",
        "Nh� �p b�ng Da./epbong",
        "Nh� �p b�ng Ho�ng Kim./epbong",
        "Nh� �p b�ng B�ch Kim./epbong",
	"K�t th�c ��i tho�i/no")

function epbong(sel)
	local deo  = 	GetItemCount(33,5)
	local ruot  = 	GetItemCount(34,5)
	local vohk  = 	GetItemCount(35,5)
	local vobk  = 	GetItemCount(36,5)
	local bongda =	        GetItemCount(37,5)
	local bonghk = 	GetItemCount(38,5)
	local bongbk = 	GetItemCount(39,5)
        local succ = 0;
	n = sel + 1
	if(n == 1) then
   	    if(deo >= 1 and ruot >=1 ) then
		   succ = 1;
		   Input("bongda")
		   Msg2Player(EPBONG)
	    end
	    if(succ == 0) then
		   Talk(1,"","Ng��i kh�ng c� mang theo <color=green>Ch�t D�o<color> Ho�c<color=green> Ru�t Cao Su <color>r�i.")
	    end
	elseif(n == 2) then
	    if(deo >= 1 and ruot >=1 and vohk >=1 ) then
		   succ = 1;
		   Input("bonghk")
		   Msg2Player(EPBONG)
	    end
	    if(succ == 0) then
		   Talk(1,"","Ng��i kh�ng c� mang theo<color=green>Ch�t D�o <color>Ho�c<color=green> Ru�t Cao Su<color> Ho�c<color=green> V� B�ng Ho�ng Kim <color>r�i.")
	    end	
        elseif(n == 3) then
	    if(deo >= 1 and ruot >=1 and vobk >=1 ) then
		   succ = 1;
		   Input("bongbk")
		   Msg2Player(EPBONG)
	    end
	    if(succ == 0) then
		 Talk(1,"","Ng��i kh�ng c� mang theo<color=green>Ch�t D�o <color>Ho�c<color=green> Ru�t Cao Su<color> Ho�c<color=green> V� B�ng B�ch Kim <color>r�i.")
            end   
        end
    end
end

function bongda(num)
	local deo   = 	GetItemCount(33,5)
	local ruot   = 	GetItemCount(34,5)
	local bongda       = 	37
	if(num < 1 or num > 100) then
        Talk(1,"","S� L��ng T�i �a l� <color=red>100 c�i")
        return end
	if(ruot >= num and deo >= num ) then
          AddItem(0,5,bongda,0,0,5,num,0)
               DelItem(33,5,num)
               DelItem(34,5,num)
		Talk(1,"","Ch�c M�ng �� Nh�n ���c<color=green> "..(num).." <color>B�ng Da.")
        else
 		Talk(1,"","Ng��i Thi�u <color=green>"..(num-ruot).." Ru�t Cao Su<color> ho�c <color=green>"..(num-deo).." Ch�t D�o <color> r�i.")
         end
end
function bonghk(num)
	local deo   = 	GetItemCount(33,5)
	local ruot   = 	GetItemCount(34,5)
	local vohk   = 	GetItemCount(35,5)
	local bonghk       = 	38
	if(num < 1 or num > 50) then
        Talk(1,"","S� L��ng T�i �a l� <color=red>50 c�i")
        return end
	if(deo >= num and ruot >= num and vohk >= num ) then
          AddItem(0,5,bonghk,0,0,5,num,0)
               DelItem(33,5,num)
               DelItem(34,5,num)
               DelItem(35,5,num)
		Talk(1,"","Ch�c M�ng �� Nh�n ���c<color=green> "..(num).." <color> B�ng Ho�ng Kim.")
        else
 		Talk(1,"","Ng��i Thi�u <color=green>"..(num-ruot).." Ru�t Cao Su<color> ho�c <color=green>"..(num-deo).." Ch�t D�o <color>ho�c <color=green>"..(num-vohk).." V� B�ng Ho�ng Kim <color> r�i.")
        end
end

function bongbk(num)

	local deo   = 	GetItemCount(33,5)
	local ruot   = 	GetItemCount(34,5)
	local vobk   = 	GetItemCount(36,5)
	local bongbk       = 	39
	if(num < 1 or num > 50) then
        Talk(1,"","S� L��ng T�i �a l� <color=red>50 c�i")
        return end
	if(deo >= num and ruot >= num and vobk >= num ) then
          AddItem(0,5,bongbk,0,0,5,num,0)
               DelItem(33,5,num)
               DelItem(34,5,num)
               DelItem(36,5,num)
		Talk(1,"","Ch�c M�ng �� Nh�n ���c<color=green> "..(num).." <color> B�ng B�ch Kim.")
        else
 		Talk(1,"","Ng��i Thi�u <color=green>"..(num-ruot).." Ru�t Cao Su<color> ho�c <color=green>"..(num-deo).." Ch�t D�o <color>ho�c <color=green>"..(num-vohk).." V� B�ng B�ch Kim <color> r�i.")
        end
end


function noinput()
	FreezeItem(GetTaskTemp(ITEMINDEX),0)
end;

--======================================================================================================--
function no()
end
