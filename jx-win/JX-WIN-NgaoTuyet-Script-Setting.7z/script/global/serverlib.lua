Include("\\script\\global\\tasklist.lua");
Include("\\script\\global\\map_helper.lua");
-------------------------------------------------------------------

STATUSBOX 	 = 0
ITEMBOX 	 = 1
TEAMBOX		 = 2
DSCRIBEBOX	 = 3
NOTEBOX		 = 4
FRIENDBOX	 = 5
SKILLBOX	 = 6
TONGMANAGER	 = 7
ESCBOX		 = 8
CREATPASSBOX = 9
CHANGEPASSBOX = 10
UNLOCKPASSBOX = 11
OPENTREMBLE	 = 12

function OpenStatusBox()
	PlayerAction(STATUSBOX, 0)
end

function OpenItemBox()
	PlayerAction(ITEMBOX, 0)
end

function OpenTeamBox()
	PlayerAction(TEAMBOX, 0)
end

function OpenDescribeBox()
	PlayerAction(DSCRIBEBOX, 0)
end

function OpenNoteBox()
	PlayerAction(NOTEBOX, 0)
end

function OpenFriendBox()
	PlayerAction(FRIENDBOX, 0)
end

function OpenSkillBox()
	PlayerAction(SKILLBOX, 0)
end

function OpenTongManagerBox()
	PlayerAction(TONGMANAGER, 0)
end

function OpenESCBox()
	PlayerAction(ESCBOX, 0)
end

function OpenCreatPassBox()
	PlayerAction(CREATPASSBOX, 0)
end

function OpenChangePass()
	PlayerAction(CHANGEPASSBOX, 0)
end

function OpenUnlockPass()
	PlayerAction(UNLOCKPASSBOX, 0)
end

function OpenTrembleItem()
	PlayerAction(OPENTREMBLE, 0)
end

function CloseStatusBox()
	PlayerAction(STATUSBOX, 1)
end

function CloseItemBox()
	PlayerAction(ITEMBOX, 1)
end

function CloseTeamBox()
	PlayerAction(TEAMBOX, 1)
end

function CloseDescribeBox()
	PlayerAction(DSCRIBEBOX, 1)
end

function CloseNoteBox()
	PlayerAction(NOTEBOX, 1)
end

function CloseFriendBox()
	PlayerAction(FRIENDBOX, 1)
end

function CloseSkillBox()
	PlayerAction(SKILLBOX, 1)
end

function CloseTongManagerBox()
	PlayerAction(TONGMANAGER, 1)
end

function CloseESCBox()
	PlayerAction(ESCBOX, 1)
end

function CloseCreatPassBox()
	PlayerAction(CREATPASSBOX, 1)
end

function CloseChangePass()
	PlayerAction(CHANGEPASSBOX, 1)
end

function CloseUnlockPass()
	PlayerAction(UNLOCKPASSBOX, 1)
end

function CloseTrembleItem()
	PlayerAction(OPENTREMBLE, 1)
end
-------------------------------------------------------------------
GENRE		= 0
DETAIL		= 1
PARTICULAR	= 2
LEVEL		= 3
SERIES		= 4
IDX_OP1		= 5
IDX_OP2		= 6
IDX_OP3		= 7
IDX_OP4		= 8
IDX_OP5		= 9
IDX_OP6		= 10
VALUE_OP1	= 11
VALUE_OP2	= 12
VALUE_OP3	= 13
VALUE_OP4	= 14
VALUE_OP5	= 15
VALUE_OP6	= 16
BIND		= 17
NAME		= 18
ID			= 19
COLOR		= 20
CANSELL		= 21
CANTRADE	= 22
CANDROP		= 23
WIDTH		= 24
HEIGHT		= 25
MAXUSE		= 26
PURPLEITEM	= 27
HELMTYPE	= 28
ARMORTYPE	= 29
WEAPONTYPE	= 30
TASKEVENT	= 31
MAXTASKEVENT = 32
STACKNUM	= 33
ITEMBROKEN	= 34
ITEMDUR		= 35

POSEQUIP	= 1
POSTREMBLE	= 2

CHANGELEVEL	 = 1
CHANGESERIES = 2
CHANGEOPTION = 3
SETTIME = 4
SETBINDITEM = 5
SETCANSELL = 6
SETCANTRADE = 7
SETCANDROP = 8
SETMAXUSE = 9
SETPURPLE = 10
SETHELM = 11
SETARMOR = 12
SETWEAPON = 13
SETSTACKNUM	= 14
ADDSTACKNUM	= 15
SETBROKEN	= 16
SETMAXDUR	= 17


UN_BIND_VALUE_LOCK = 24
BIND_VALUE_LOCK = 1
BIND_VALUE_LOCK_LIMIT = 2
--===================================

function GetIndexEquipItem(nSocket)	
	GetIdItem(POSEQUIP, nSocket)
end

function GetIndexTrembleItem(nSocket)	
	GetIdItem(POSTREMBLE, nSocket)
end

function RemoveItem(nIndex)						-- Xoa vat pham theo index
	DelItemIdx(nIndex)
end

function GetGenreItem(nIndex)					-- Lay Genre vat pham
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, GENRE)
end

function GetDetailItem(nIndex)					-- Lay DetailType vat pham
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, DETAIL)
end

function GetParticularItem(nIndex)				-- Lay Particular vat pham
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, PARTICULAR)
end

function GetLevelItem(nIndex)					-- Lay cap do vat pham
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, LEVEL)
end

function GetSeriesItem(nIndex)					-- Lay ngu hanh vat pham
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, SERIES)
end

function GetOp1Item(nIndex)						-- Lay ID Option 1
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, IDX_OP1)
end

function GetOp2Item(nIndex)						-- Lay ID Option 2
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, IDX_OP2)			
end

function GetOp3Item(nIndex)						-- Lay ID Option 3
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, IDX_OP3)
end

function GetOp4Item(nIndex)						-- Lay ID Option 4
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, IDX_OP4)
end

function GetOp5Item(nIndex)						-- Lay ID Option 5
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, IDX_OP5)
end

function GetOp6Item(nIndex)						-- Lay ID Option 6
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, IDX_OP6)
end

function GetVOp1Item(nIndex)				 	-- Lay gia tri option 1
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, VALUE_OP1)
end

function GetVOp2Item(nIndex)					-- Lay gia tri option 2
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, VALUE_OP2)
end

function GetVOp3Item(nIndex)					-- Lay gia tri option 3
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, VALUE_OP3)
end

function GetVOp4Item(nIndex)					-- Lay gia tri option 4
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, VALUE_OP4)
end

function GetVOp5Item(nIndex)					-- Lay gia tri option 5
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, VALUE_OP5)
end

function GetVOp6Item(nIndex)					-- Lay gia tri option 6
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, VALUE_OP6)
end

function GetNameItem(nIndex)					-- Lay gia tri option 6
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, NAME)
end

function GetBindItem(nIndex)					-- Lay trang thai dinh vat pham
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, BIND)
end

function GetNameItem(nIndex)					-- Lay ten vat pham
	if(nIndex == nil) then
		return ""
	end
	return GetInfoItem(nIndex, NAME)
end

function GetIDItem(nIndex)
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, ID)
end

function GetColorItem(nIndex)
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, COLOR)
end

function GetWidthItem(nIndex)
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, WIDTH)
end

function GetHeightItem(nIndex)
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, HEIGHT)
end

function GetMaxNumberUse(nIndex)
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, MAXUSE)
end

function GetPurpleItem(nIndex)
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, PURPLEITEM)
end

function GetHelmItem(nIndex)
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, HELMTYPE)
end

function GetArmorItem(nIndex)
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, ARMORTYPE)
end

function GetWeaponItem(nIndex)
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, WEAPONTYPE)
end

function GetTaskEvent(nIndex)
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, TASKEVENT)
end

function GetMaxTaskEvent(nIndex)
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, MAXTASKEVENT)
end

function GetStackNum(nIndex)
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, STACKNUM)
end

function GetItemBroken(nIndex)
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, ITEMBROKEN)
end

function GetDur(nIndex)
	if(nIndex == nil) then
		return 0
	end
	return GetInfoItem(nIndex, MAXDUR)
end

function SetColorItem(nIndex)
	if(nIndex == nil) then
		return 0
	end
szName = GetNameItem(nIndex)
nColor = GetColorItem(nIndex)
if (szName ~= "") then
	if (nColor == 1) then
	return "<color=Blue>"..szName.." <color>"
	elseif (nColor == 4) then
	return "<color=Purple>"..szName.." <color>"
	elseif (nColor == 3) then
	return "<color=HYellow>"..szName.." <color>"
	elseif (nColor == 2) then
	return "<color=Red>"..szName.." <color>"	
	elseif (nColor == 5) then
	return "<color=Earth>"..szName.." <color>"	
	else
	return "<color=White>"..szName.." <color>"
	end
else
return ""
end
end

--=========================================== HAM THAY DOI THONG TIN VAT PHAM ==========================
function SetLevelItem(nIndex, nLevel)
	ChangeInfoItem(CHANGELEVEL, nIndex, nLevel)
end

function SetSeriesItem(nIndex, nSeries)
	ChangeInfoItem(CHANGESERIES, nIndex, nSeries)
end

function ChangeSpiritItem(nIndex)
	ChangeInfoItem(CHANGEOPTION, nIndex)
end

function SetTime(nIndex, nYear, nMonth, nDay, nHour, nMin)
	ChangeInfoItem(SETTIME, nIndex, nYear, nMonth, nDay, nHour, nMin)
end

function AddTime(nIndex, nValue)
local TabDayPerMonth = {
{1,31},{2,28},{3,31},{4,30},
{5,31},{6,30},{7,31},{8,31},
{9,30},{10,31},{11,30},{12,31},
}
	local nMin = tonumber(date("%M"))
	local nHour = tonumber(date("%H"))
	local nDay = tonumber(date("%d"))
	local nMonth = tonumber(date("%m"))
	local nYear = tonumber(date("%y")) + 2000
	nDayAdd = nDay + nValue
	if (nDayAdd > TabDayPerMonth[nMonth][2]) then
		nDayAdd = nDayAdd - TabDayPerMonth[nMonth][2]
		nMonth = nMonth + 1	
		if (nMonth >= 13) then
			nMonth = nMonth - 12
			nYear = nYear + 1
		end
		ChangeInfoItem(SETTIME, nIndex, nYear, nMonth, nDayAdd, nHour, nMin)
	else
		ChangeInfoItem(SETTIME, nIndex, nYear, nMonth, nDayAdd, nHour, nMin)
	end
end

function SetBindItem(nIndex, nValue)
	ChangeInfoItem(SETBINDITEM, nIndex, nValue)
end
-----------------------------------------------------------
function CopyItem(nIndexOld, nIndexNew)
	ChangeInfoItem(COPYITEM, nIndexOld, nIndexNew)
end
-----------------------------------------------------------
--===================================================
function BindItem(nIndex)
	ChangeInfoItem(SETBINDITEM, nIndex, BIND_VALUE_LOCK)
end

function BindItemLimit(nIndex)
	ChangeInfoItem(SETBINDITEM, nIndex, BIND_VALUE_LOCK_LIMIT)
end

function UnBindItem(nIndex)
	ChangeInfoItem(SETBINDITEM, nIndex, UN_BIND_VALUE_LOCK)
end

function SetCanSell(nIndex, nValue)
	ChangeInfoItem(SETCANSELL, nIndex, nValue)
end

function SetCanTrade(nIndex, nValue)
	ChangeInfoItem(SETCANTRADE, nIndex, nValue)
end

function SetCanDrop(nIndex, nValue)
	ChangeInfoItem(SETCANDROP, nIndex, nValue)
end

function SetMaxNumberUse(nIndex, nValue)
	ChangeInfoItem(SETMAXUSE, nIndex, nValue)
end

function SetPurpleItem(nIndex, nValue)
	ChangeInfoItem(SETPURPLE, nIndex, nValue)
end

function SetHelmItem(nIndex, nValue)
	ChangeInfoItem(SETHELM, nIndex, nValue)
end

function SetArmorItem(nIndex, nValue)
	ChangeInfoItem(SETARMOR, nIndex, nValue)
end

function SetWeaponItem(nIndex, nValue)
	ChangeInfoItem(SETWEAPON, nIndex, nValue)
end

function ReturnHelm(nIndex)
	ChangeInfoItem(SETHELM, nIndex, 0)
end

function ReturnArmor(nIndex)
	ChangeInfoItem(SETARMOR, nIndex, 0)
end

function ReturnWeapon(nIndex)
	ChangeInfoItem(SETWEAPON, nIndex, 0)
end

function SetStackNum(nIndex, nValue)
	ChangeInfoItem(SETSTACKNUM, nIndex, nValue)
end

function AddStackNum(nIndex, nValue)
	ChangeInfoItem(ADDSTACKNUM, nIndex, nValue)
end

function SetItemBroken(nIndex, nValue)
	ChangeInfoItem(SETBROKEN, nIndex, nValue)
end

function SetDur(nIndex, nValue)
	ChangeInfoItem(SETMAXDUR, nIndex, nValue)
end

function SetHeightItem(nIndex, nValue)
	ChangeInfoItem(SETHEIGHT, nIndex, nValue)
end

function GetFactionNumber()
	if GetFaction() == "shaolin" then
	return 1
	elseif GetFaction() == "tianwang" then
	return 2
	elseif GetFaction() == "tangmen" then
	return 3
	elseif GetFaction() == "wudu" then
	return 4
	elseif GetFaction() == "emei" then
	return 5
	elseif GetFaction() == "cuiyan" then
	return 6
	elseif GetFaction() == "gaibang" then
	return 7
	elseif GetFaction() == "tianren" then
	return 8
	elseif GetFaction() == "wudang" then
	return 9
	elseif GetFaction() == "kunlun" then
	return 10
	else
	return 0
	end
end;

function updatengay()
ngay_thang_nam = tonumber(date("%d%m%y")) -- ngay,thang,nam
if (GetTask(TaskNgayThangNam) ~= ngay_thang_nam) then
SetTask(TaskNumCNHK,0)
SetTask(TaskNumSatThu,0)
SetTask(TaskNumQuaHH,0)
SetTask(TaskNumAHL,0)
SetTask(TaskNumMut,0)
SetTask(TaskNumTCC,0)
end
end

function updateThang()
	local nNgay = tonumber(date("%d"))
	local nThang = tonumber(date("%m"))
	local nThang_Nam = tonumber(date("%m%y"))
	if(GetTask(T_LuuNgay) == 30 or GetTask(T_LuuNgay) == 31) and (nThang == 2) then
		SetTask(T_LuuNgay, 28)
	end
	if(GetTask(T_LuuNgay) == 31) and (nThang == 4 or nThang == 6 or nThang == 9 or nThang == 11) then
		SetTask(T_LuuNgay, 30)
	end
end


function GetParam(strParam, index)
	nLastBegin = 1
	for i=1, index - 1 do
		nBegin = strfind(strParam, ",", nLastBegin) or strfind(strParam, "/", nLastBegin)
		nLastBegin = nBegin + 1
	end;
	num = 1
	strnum = strsub(strParam, nLastBegin)
	nEnd = strfind(strnum, ",") or strfind(strnum, "/")
	if nEnd == nil then 
		return strnum
	end
	str1 = strsub(strnum,1,nEnd -1);
	return str1
end;

function DelItemGive(nIndexString, nGiveNum, bSkipItem)
local nIndexObj = 0
local nIndexItem = 0
if (bSkipItem > 0) then
for i = 1,nGiveNum do
	nIndex = tonumber(GetParam(nIndexString, i))
	if (GetGenreItem(nIndex) == 0) then
		nIndexItem = nIndex
	end
end
end

for i = 1,nGiveNum do
	nIndexObj = tonumber(GetParam(nIndexString, i))
	if (bSkipItem > 0) then
		if (nIndexObj ~= nIndexItem) then
			DelItemIdx(nIndexObj)
		end
	else
		DelItemIdx(nIndexObj)
	end
end
end

function MsgEx(sMessage,sMsgType)
	if (sMsgType==0 or sMsgType==nil) then
		Msg2Player(sMessage);
	else
		Talk(sMsgType,"",sMessage);
	end
end;

function GenNPCEx(nLevel, nMap, nX, nY, Width,Height, NpcNum, NpcFrom, NpcTo,nDeathScript,nCurCamp)
    worldindex = SubWorldID2Idx(nMap)
    	posx = nX*8*32
    	posy = nY*16*32
if (Width <= 0 or Height <=0 or NpcNum <=0 or NpcFrom <=0  or NpcTo <=0) then
return
end;

if (x == nil) then 
return
end;

PerWidth = Width/sqrt(NpcNum);
PerHeight = Height / sqrt(NpcNum);

for i = 1, NpcNum do 
	Npctemp = random(NpcFrom, NpcTo);
	NpcIndex = AddNpc(Npctemp, nLevel, worldindex, (x - Width/2) +  mod(i, sqrt(NpcNum)) * PerWidth, (y - Height/2) + i/sqrt(NpcNum) * PerHeight);
	if(nDeathScript~=nil) then
    		SetNpcScript(NpcIndex, nDeathScript);
	end	
	if(nCurCamp~=nil) then
		SetNpcCurCamp(NpcIndex, nCurCamp);
	end	
end;
end;

function GO(id)
	map=LoadData("Settings/WayPoint.txt")
	MoveNPC(map[id][3],map[id][4],map[id][5],1,1,100,1);
	Msg2Player("�i ��n "..map[id][2].." n�o...");
end

function MoveNPC(nMap,nX,nY,nOffsetX,nOffsetY,nPrice,nFightState,nTermini)
	if (nOffsetX==nil) then nOffsetX=0 end
	if (nOffsetY==nil) then nOffsetY=0 end	
   	posx = floor((nX+nOffsetX/10)*8)
		posy = floor((nY+nOffsetY/10)*16)
   		if (GetCash() >= nPrice) then
			Pay(nPrice)
			NewWorld(nMap, posx, posy);
			SetFightState(nFightState);
    		Msg2Player("Ng�i y�n! Ch�ng ta �i "..GetMapName(nMap).." !")
			if(nTermini~=nil) then
    			AddTermini(nTermini);
   			end	
		
		else
			Msg2Player("Kh�ng �� "..nPrice.." l��ng kh�ng th� kh�i h�nh!")
		end
end;

function MoveNPC32(nMap,nPosX,nPosY,nPrice,nFightState,nTermini)
   	if (GetCash() >= nPrice) then
		Pay(nPrice)
		NewWorld(nMap, nPosX + random(-2,2), nPosY + random(-2,2));
		SetFightState(nFightState);
    	Msg2Player("Ng�i y�n! Ch�ng ta �i "..GetMapName(nMap).." !")
		if(nTermini~=nil) then
    		AddTermini(nTermini);
   		end	
	else
		Msg2Player("Kh�ng �� "..nPrice.." l��ng kh�ng th� kh�i h�nh! ")
	end
end;

-- Ham ghi lai log
function logRead(logName,readType,numLine)
local log_filename = Log[logName][1]
local fs_log = openfile(log_filename, "r");
if ( readType == "line" ) then 
	if( numLine ~= nil ) and ( numLine >= 1 ) then 
		for i=1,numLine do 
			str = read(fs_log,"*line")
			Msg2Player(str)
		end;
	else 
		str = read(fs_log,"*all")
		Msg2Player(str)
	end;
elseif ( readType == "all" ) then 
	str = read(fs_log,"*all")
	Msg2Player(str)
else 
	str = read(fs_log,"*all")
	Msg2Player(str)
end;
closefile(fs_log);
end;

function returnLines(fileStream)
 flag = 1
 count = 1
while flag == 1 do
 _s = strfind(fileStream,"\n")
 count = count + 1
 if ( _s == 0 ) or ( _s == nil ) then 
 flag = 0
 end;
end;
end;
IsFile = function(s,b)
if b then
        print ( s, " does not exist." )
    else
        print ( s, " does exist." )
    end 
end
function LoadData(szFileName)
local Data_Table = openfile(szFileName, "r");
str_data_table = read(Data_Table,"*all")
local tab_data_table = split(str_data_table,"\n")
data_count = getn(tab_data_table) -1
dt_table1 = {}
dt_table2 = {}
for i=1,data_count do
dt_table1[i] =  split(tab_data_table[i],"\t")
dt_table2[i] =  dt_table1[i]
end;
closefile(Data_Table);
return dt_table2
end;
-- Ham xoa task

function ClearTask(idtask,tyle)
if ( tyle == 0 or tyle == nil ) then
	SetTask(idtask,0)
elseif tyle == 1 then
	SetTaskTemp(idtask,tyle*0)
end
end;

function Save_LogSV(logs)
local svlog = openfile("Server_Log.txt", "a");
write(svlog, date("%y-%m-%d_%H:%M:%S").."\t"..logs.."\n");
closefile(svlog);
end;

function HandLog(links,logs)
local svlog = openfile(links, "a");
write(svlog, date("%y-%m-%d_%H:%M:%S").."\t"..logs.."\n");
closefile(svlog);
end;

function OnExit()
end;

function Exit()
end;

function no()
end;

function out()
end

function OnCancel()
end

function CWriteLog(data)
local IPData2 = openfile("Logs/"..date("20%y-%m-%d")..".txt", "a");
write(IPData2, date("20%y-%m-%d_%H:%M:%S").."\t"..tostring(data).."\n");
closefile(IPData2);
end;

function IPWrite()
local IPData = openfile("Data/IP.txt", "a");
write(IPData, date("%y-%m-%d_%H:%M:%S").."\t["..GetInfo().."]\t["..GetPlayerName().."]\n");
closefile(IPData);
end;

function SaveItem(chuviet)
local IPData1 = openfile("Data/ItemGet.txt", "a");
write(IPData1, date("%y-%m-%d_%H:%M:%S").."\t"..chuviet.."\n");
closefile(IPData1);
end;

function SaveInfo(chuviet1)
local IPData2 = openfile("Data/other.txt", "a");
write(IPData2, date("%y-%m-%d_%H:%M:%S").."\t"..chuviet1.."\n");
closefile(IPData2);
end;

--H�m t�nh th�i gian
function ComputeTime()
	 return tonumber((((date("%m")-1)*30+date("%d")-1)*24+date("%H"))*60+date("%M"))
end

function LoadTabel(tbtable,strchat)
	FuncstrBasic={}
	nSc = getn(tbtable);
	for i=1,nSc do
	FuncstrBasic[i] = tbtable[i][1]..tbtable[i][2]
	end;
Say(strchat,nSc,FuncstrBasic)
end;

function SaveData(file, string) 
file_op = openfile( file, "w+" )  --- a+ la vit them hem xoa file dau -- w+ -- la che do doc ghi xoa file dau  
    write(file_op,string) 
    closefile(file_op)  
end
function TaoBang(tTable, sTableName, sTab)
    sTab = sTab or "";  
    sTmp = ""  
    sTmp = sTmp..sTab..sTableName.."={"  
 
    local tStart = 0  
    for key, value in tTable do  
  
        if tStart == 1 then  
            sTmp = sTmp..",\r\n"  
 
        else  
            sTmp = sTmp.."\r\n"  
            tStart = 1  
        end  
        local sKey = (type(key) == "string") and format("[%q]",key) or format("[%d]",key);  
        if(type(value) == "table") then  
            sTmp = sTmp..TaoBang(value, sKey, sTab.."\t");  
        else  
            local sValue = (type(value) == "string") and format("%q",value) or tostring(value);  
            sTmp = sTmp..sTab.."\t"..sKey.." = "..sValue 
        end  
 
    end 
    sTmp = sTmp.."\r\n"..sTab.."}"  
    return sTmp
  
end  


function LuuBang(file, string)
local f,e = openfile( file, "w+" )
if f then
    write(f,string)
    closefile(f)
    return 1
else
    local _,_,path = strfind(file, "(.+[/_\\]).+$") 
    if path ~= nil then execute("mkdir ".."\""..gsub(path, "/", "\\").."\"") end
    f,e = openfile( file, "w+" )
    if f then
        write(f,string) 
        closefile(f)
        return 2
    else
        return 0
        end
    end
end
function LoadExp()
local exp_table = openfile("Settings/Player/level_exp.txt","r");
exp_data = read(exp_table,"*all")
local split_tab = split(exp_data,"\n")
exp_sl = getn(split_tab) - 1
level_exp = {}
level_exp_chinh = {}
for i=2,exp_sl do
level_exp=split(split_tab[i],"\t")
level_exp_chinh[i]=level_exp[2]
end;
closefile(exp_table)
return level_exp_chinh
end;

function TimKiem(tenbang,tukhoa)
	if getn(tenbang) == 0 then
		return nil
	end
	for i= 1,getn(tenbang) do
		for k = 1,getn(tenbang[i]) do
			if tenbang[i][k] == tukhoa then
				return 1
			end
		end
	end
end

function AddNpc32Ex(nId, nLevel, nMap, nPosX, nPosY, nScript, nCurCamp)
	nScript = nScript or ""
	nCurCamp = nCurCamp or 6
	local 	Series = random(0,4)
	local	idnpc1 = tonumber(GetParam(nId,1))
	local	idnpc2 = tonumber(GetParam(nId,2))
	local	npcid = random(idnpc1,idnpc2)
    local	mapindex = SubWorldID2Idx(nMap)
    local	npclvl = nLevel
	local	nNpcId = AddNpc(npcid,npclvl,mapindex,nPosX,nPosY);
   	SetNpcScript(nNpcId, nScript);
	SetNpcSeries(nNpcId,Series)
   	SetNpcCurCamp(nNpcId, nCurCamp);
	return nNpcId
end;

function AddNpcs(nId,nLevel, nMap,nX,nY,nOffsetX,nOffsetY,nScript,nCurCamp,nNameDesc)
	nOffsetX = nOffsetX or 0
	nOffsetY = nOffsetY or 0
	nScript = nScript or ""
	nCurCamp = nCurCamp or 6
	local 	Series = random(0,4)
    local	mapindex = SubWorldID2Idx(nMap)
	local	npcid = nId
    local	npclvl = nLevel
    local	posx = floor((nX+nOffsetX/10)*8*32)
    local	posy = floor((nY+nOffsetY/10)*16*32)
	local	nNpcId = AddNpc(npcid,npclvl,mapindex,posx,posy);
   	SetNpcScript(nNpcId, nScript);
	if (nCurCamp ~= 6) then	
		SetNpcSeries(nNpcId,Series)
	end
   	SetNpcCurCamp(nNpcId, nCurCamp);
	if (nNameDesc ~= nil) then	
		SetNpcDesc(nNpcId,nNameDesc)
	end
	return nNpcId
end;

function AddNpc32(nId, nLevel, nMap, nPosX, nPosY, nScript, nCurCamp)
	nScript = nScript or ""
	nCurCamp = nCurCamp or 6
	local 	Series = random(0,4)
    local	mapindex = SubWorldID2Idx(nMap)
	local	npcid = nId
    local	npclvl = nLevel
	local	nNpcId = AddNpc(npcid,npclvl,mapindex,nPosX,nPosY);
   	SetNpcScript(nNpcId, nScript);
	if (nCurCamp ~= 6) then
	SetNpcSeries(nNpcId,Series)
	end
   	SetNpcCurCamp(nNpcId, nCurCamp);
	return nNpcId
end;

function AddNpc32Boss(nId, nLevel, nMap, nPosX, nPosY, nScript, nBoss)
	nScript = nScript or ""
	nBoss = nBoss or 2
	local 	Series = random(0,4)
    local	mapindex = SubWorldID2Idx(nMap)
	local	npcid = nId
    local	npclvl = nLevel
	local	nNpcId = AddNpc(npcid,npclvl,mapindex,nPosX,nPosY);
   	SetNpcScript(nNpcId, nScript);
	IsBoss(nNpcId,nBoss)
   	SetNpcCurCamp(nNpcId, 5);
	return nNpcId
end;

function AddNpcBossEx(nId,nLevel, nMap,nX,nY,nOffsetX,nOffsetY,nScript,nCurCamp,nBossId)
    local	mapindex = SubWorldID2Idx(nMap)
	local	npcid = nId
    local	npclvl = nLevel
    local	posx = floor((nX+nOffsetX/10)*8*32)
    local	posy = floor((nY+nOffsetY/10)*16*32)
	local	nNpcId = AddNpc(npcid,npclvl,mapindex,posx,posy)
	nScript = nScript or ""
	nCurCamp = nCurCamp or 5
	nBossId = nBossId or 0
    SetNpcScript(nNpcId, nScript)
	SetNpcCurCamp(nNpcId, nCurCamp)
	IsBoss(nNpcId,nBossId)
	return nNpcId
end;


function AddNPCEx(nId,nLevel, nMap,nX,nY,nOffsetX,nOffsetY,nScript,nCurCamp,nSer,nName)
	if (nOffsetX==nil) then nOffsetX = 0 end
	if (nOffsetY==nil) then nOffsetY = 0 end	
    	mapindex = SubWorldID2Idx(nMap)
		npcid = nId
    	npclvl = nLevel
    	posx = floor((nX+nOffsetX/10)*8*32)
    	posy = floor((nY+nOffsetY/10)*16*32)
	nNpcId = AddNpc(npcid,npclvl,mapindex,posx,posy,1, "Da tau", 1);
	if(nScript~=nil) then
    		SetNpcScript(nNpcId, nScript);
    	end	
	if(nCurCamp~=nil) then	
		SetNpcCurCamp(nNpcId, nCurCamp);
	end	
	if(nName~=nil)then
		SetNpcName(nNpcId,nName);
	end
	if(nSer~=nil)then
		SetNpcSeries(nNpcId,nSer);
	end;
	return nNpcId
end;

function SayEx(strSay)
	local strMsg,strSel = "","";
	local strNum = getn(strSay);
	if strNum < 2 then
		return
	end;
	if strNum > 2 then
		for i=2,strNum - 1 do
			strSel = strSel..format("%q", strSay[i])..",";
		end;
		strSel = strSel..format("%q", strSay[strNum]);
		strMsg = "Say("..format("%q", strSay[1])..","..(strNum - 1)..","..strSel..");";
	elseif strNum == 2 then
		strSel = format("%q", strSay[strNum]);
		strMsg = "Say("..format("%q", strSay[1])..",1"..","..strSel..");";
	end;
	dostring(strMsg);
end;
----------------------------------------------------------------------------------------Notify Function-----------------------------------------------------------------------------------------------------------------------------------------------------------------
function replace(str,pattern,s)
	local startS,endS = strfind(str,pattern)
	while(startS) do
		str = strsub(str,1,startS-1)..s..strsub(str,endS+1,strlen(str))
		startS,endS = strfind(str,pattern)
	end
	return str
end

function split(str,splitor)
	if(splitor==nil) then
		splitor=","
	end
	local strArray={}
	local strStart=1
	local splitorLen = strlen(splitor)
	local index=strfind(str,splitor,strStart)
	if(index==nil) then
		strArray[1]=str
		return strArray
	end
	local i=1
	while index do
		strArray[i]=strsub(str,strStart,index-1)
		i=i+1
		strStart=index+splitorLen
		index = strfind(str,splitor,strStart)
	end
	strArray[i]=strsub(str,strStart,strlen(str))
	return strArray
end

function join(arr,insertor)
	local maxItem = getn(arr)
	if(maxItem ==0) then
		return nil
	end
	if(insertor==nil) then
		insertor=","
	end
	local str=""
	for i=1,maxItem-1 do
		if(not arr[i]) then 
			str= str..insertor
		else
			str = str..tostring(arr[i])..insertor
		end
	end
	if(arr[maxItem]) then 
		str = str..tostring(arr[maxItem])
	end
	return str
end

function trim(str)
	local start,last = strfind(str,"%S+.*%S+")
	print(tostring(start).."|"..tostring(last))
	if(start==nil or last==nil) then
		return str
	end
	return strsub(str,start,last)
end

function SaveLog(file,_name,types)
	local types = types or "w+"
	local _name = _name or "NULL"
	local fs_log = openfile(file, types);
	write(fs_log, _name.."\n");
	closefile(fs_log);
end;

function SaveLogA(file,_name,types)
	local types = types or "a+"
	local _name = _name or "NULL"
	local fs_log = openfile(file, types);
	write(fs_log, _name.."\n");
	closefile(fs_log);
end;

function ReadLog(file)
	local F_Tong = openfile(file, "r");
	if F_Tong == nil then
		return 0
	end
	local str_data = read(F_Tong,"*all")
	local tab_data = split(str_data,"\n")
	local DataCount = getn(tab_data) - 1
	local id_data = {}
	local id_data_temp = {}
	for i=1,DataCount do
		id_data[i] =  split(tab_data[i],"\t")
		id_data_temp[i] = id_data[i]
	end;
	closefile(F_Tong);
	return id_data_temp
end

--=========================================================
