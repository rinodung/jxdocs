-- Script Boss Ho�ng Kim
Include("\\Script\\header\\bosstieuhk.lua")
ITEMLIST = {5,2,13,0,1,3,1,13,1,1}
MONEY = 100000
function DropRate(NpcIndex)
local ser = GetNpcSer(NpcIndex);
local pluck = GetLucky(); --may man cua nguoi choi
local maxlev = random(7,10);
if(RANDOM(200) <= pluck) then
maxlev = 10
end
----------------Boss Ho�ng Kim-----------------------------------------------------------
local nSel = 0;
local nPos = 1;
local dropnum;
dropnum = 500; --S� L��ng c�c �� r�t.
for i=1,dropnum do
	nSel = RANDOM(350);
	if(nSel == 299) then
		DropNpcItem(NpcIndex, 0, 4,RANDOM(3,30),0,0,5,0,0) --bk 9x random
	elseif(nSel == 300) then
		DropNpcItem(NpcIndex, 0, 4,RANDOM(1,10),5,10,0,0) --Huy�n tinh
	elseif(nSel == 405) then
		DropNpcItem(NpcIndex, 0, 5,5,0,0,5,0,0) --Ng� S�c B�o Ng�c trung.
	elseif(nSel == 412) then
		DropNpcItem(NpcIndex, 0, 5,32,0,0,5,0,0) --M�u Xu.
	elseif(nSel == 417) then
		DropNpcItem(NpcIndex, 0, 4,65,0,0,5,0,0) --B�ch C�u Ho�n U� Th�c.
	elseif(nSel == 413) then
		DropNpcItem(NpcIndex, 0, 2,6,0,0,5,0,0) --Ng� S�c B�o Ng�c ti�u.
	elseif(nSel == 411) then
		DropNpcItem(NpcIndex, 0, 2,48,0,0,5,0,0) --Qu� Hoa T�u.
	elseif(nSel == 410) then
		DropNpcItem(NpcIndex, 0, 2,93,0,0,5,0,0) --T�i H�nh Trang(30 day).
	elseif(nSel == 409) then
		DropNpcItem(NpcIndex, 0, 2,90,0,0,5,0,0) --��i Th�nh BK.90.
	elseif(nSel == 408) then
		DropNpcItem(NpcIndex, 0, 2,91,0,0,5,0,0) --��i Th�nh BK.120.
	elseif(nSel == 407) then
		DropNpcItem(NpcIndex, 0, 2,92,0,0,5,0,0) --��i Th�nh BK.150.
	elseif(nSel == 406) then
		DropNpcItem(NpcIndex, 0, 2,89,0,0,5,0,0) --BK.150.
	elseif(nSel == 405) then
		DropNpcItem(NpcIndex, 0, 2,59,0,0,5,0,0) --BK.120.
	elseif(nSel == 404) then
		DropNpcItem(NpcIndex, 0, 2,13,0,0,5,0,0) --VLMT.
	elseif(nSel == 402) then
		DropNpcItem(NpcIndex, 0, 2,14,0,0,5,0,0) --TTK.
	elseif(nSel == 303) then
		DropNpcItem(NpcIndex, 0, 2,82,0,0,5,0,0) --Nh�c V��ng Ki�m.
	elseif(nSel == 304) then
		DropNpcItem(NpcIndex, 0, 5,30,0,0,5,0,0) --H�t Thi�n Tu�.
	elseif(nSel == 403) then
	        DropNpcMoney(NpcIndex,MONEY)
	elseif(nSel == 600)  then
	else
		--bluedetail = RANDOM(9);
		--blueparti = RANDOM(ITEMLIST[bluedetail+1]);
		DropNpcItem(NpcIndex,RANDOM(9,10),bluedetail,blueparti,RANDOM(9,10),ser,pluck,
		RANDOM(5,maxlev),RANDOM(5,maxlev),RANDOM(3,maxlev),RANDOM(maxlev),RANDOM(maxlev),RANDOM(maxlev));
                end
        end
end;
