-- Script H�t
--By Ca Rot.

ITEMLIST = {5,2,13,0,1,3,1,13,1,1}
MONEY = 100000
function DropRate(NpcIndex)
local ser = GetNpcSer(NpcIndex);
local pluck = GetLucky(); --may man cua nguoi choi
local maxlev = random(7,10);
if(RANDOM(200) <= pluck) then
maxlev = 10
end
----------------Boss Ho�ng Kim-----------------------------------------------------------
local nSel = 0;
local nPos = 1;
local dropnum;
dropnum = 500; --S� L��ng c�c �� r�t.
for i=1,dropnum do
	nSel = RANDOM(350);
	if(nSel == 299) then
		DropNpcItem(NpcIndex, 0, 5,RANDOM(0,93),0,0,5,0,0) --event item
	elseif(nSel == 300) then
	        DropNpcMoney(NpcIndex,MONEY)
	elseif(nSel == 600)  then
	else
		--bluedetail = RANDOM(9);
		--blueparti = RANDOM(ITEMLIST[bluedetail+1]);
		DropNpcItem(NpcIndex,RANDOM(9,10),bluedetail,blueparti,RANDOM(9,10),ser,pluck,
		RANDOM(5,maxlev),RANDOM(5,maxlev),RANDOM(3,maxlev),RANDOM(maxlev),RANDOM(maxlev),RANDOM(maxlev));
                end
        end
end;
