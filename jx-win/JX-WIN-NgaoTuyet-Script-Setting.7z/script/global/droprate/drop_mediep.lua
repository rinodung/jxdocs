-- Script By Carot
--Nh� � ,C�t T��ng.

ITEMLIST = {5,2,13,0,1,3,1,13,1,1}
MONEY = 100000
function DropRate(NpcIndex)
local ser = GetNpcSer(NpcIndex);
local pluck = GetLucky(); --may man cua nguoi choi
local maxlev = random(7,10);
if(RANDOM(200) <= pluck) then
maxlev = 10
end
----------------Boss Ho�ng Kim-----------------------------------------------------------
local nSel = 0;
local nPos = 1;
local dropnum;
dropnum = 500; --S� L��ng c�c �� r�t.
for i=1,dropnum do
	nSel = RANDOM(500);
	if(nSel == 299) then
		DropNpcItem(NpcIndex, 0, 3,RANDOM(1416,1417),0,0,5,0,0) --Ch�a kho�
	elseif(nSel == 350) then
		DropNpcItem(NpcIndex, 0, 5,RANDOM(155,156),0,0,5,0,0) --H�t HK
	elseif(nSel == 500) then
		DropNpcItem(NpcIndex, 0, 3,RANDOM(1703,1705),0,0,5,0,0) --Event Phuc l�c th�
	elseif(nSel == 498) then
		DropNpcItem(NpcIndex, 0, 5,135,0,0,5,5,0) --Socola lo�i 1.
	elseif(nSel == 497) then
		DropNpcItem(NpcIndex, 0, 5,143,0,0,5,0,0) --Truy�n t�ng ph�
	elseif(nSel == 408) then
		DropNpcItem(NpcIndex, 0, 5,150,0,0,5,0,0) --T�i NL b�nh.
	elseif(nSel == 496) then
	        DropNpcMoney(NpcIndex,MONEY)
	elseif(nSel == 500)  then
	else
		DropNpcItem(NpcIndex,RANDOM(499,500),bluedetail,blueparti,RANDOM(9,10),ser,pluck,
		RANDOM(5,maxlev),RANDOM(5,maxlev),RANDOM(3,maxlev),RANDOM(maxlev),RANDOM(maxlev),RANDOM(maxlev));
                end
        end
end;
