--Drop NV 15x.

ITEMLIST = {5,2,13,0,1,3,1,13,1,1}
MONEY = 10000
function DropRate(NpcIndex)
local ser = GetNpcSer(NpcIndex);
local pluck = GetLucky(); --may man cua nguoi choi
local nSel = random(0,10);
local maxlev = random(9,10);
if(RANDOM(200) <= pluck) then
maxlev = 10
end
----------------Boss Ho�ng Kim-----------------------------------------------------------
local nSel = 0;
local nPos = 1;
local dropnum;
dropnum = 10; --S� L��ng c�c �� r�t.
for i=1,dropnum do
		maxlv = 10;
                nSel = random(0,10);
	        if(nSel < 5) then
	        DropNpcMoney(NpcIndex,MONEY)
	elseif(nSel == 4) then
		DropNpcItem(NpcIndex, 0, 5,169,0,0,5,0,0)
	elseif(nSel == 6) then
		SetItemPickDel(nItemIdx,1)
		DropNpcItem(NpcIndex, 0, 5,RANDOM(169,169),0,0,5,0,0) --event item
		DropNpcItem(NpcIndex, 0, 5,169,0,0,5,0,0)
		DropNpcItem(NpcIndex,RANDOM(9,10),bluedetail,blueparti,RANDOM(9,10),ser,pluck,
		RANDOM(5,maxlev),RANDOM(5,maxlev),RANDOM(3,maxlev),RANDOM(maxlev),RANDOM(maxlev),RANDOM(maxlev));
                end
        end
end
