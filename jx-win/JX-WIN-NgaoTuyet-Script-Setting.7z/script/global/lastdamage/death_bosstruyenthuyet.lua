--Boss Tieu Hoang Kim
Include("\\script\\header\\exp_head.lua")

function LastDamage(NpcIndex)
end;
NPCLIFE = 10000000
NPCEXP = 99999999
--khi hoi sinh
function Revive(NpcIndex)
		SetBoss(NpcIndex,2) --M�u boss
		SetNpcLife(NpcIndex, NPCLIFE);--M�u.
		SetNpcExp(NpcIndex, NPCEXP*EXP_RATE*2);--kinh nghiem
		SetNpcReplenish(NpcIndex,1);--phuc hoi sinh luc	
		SetNpcSpeed(NpcIndex, 10);--toc do di chuyen tang len
                SetNpcDmgRet(NpcIndex, 0)	--Ph�n damage %
		SetNpcDmgEx(NpcIndex,nSTVL, nDoc, nBang, nHoa, nLoi ,0);--
		SetNpcDmgEx(NpcIndex,nSTVL, nDoc, nBang, nHoa, nLoi ,1);--
		SetNpcResist(NpcIndex, 75, 75, 75, 75, 75);--khang' cac loai
end;

--Khi chet
function DeathSelf(NpcIndex)
	DelNpc(NpcIndex)
end;
