--Sccript By CaRot.
--Boss M� �i�p.


Include("\\script\\header\\exp_head.lua")

function LastDamage(NpcIndex)
end;
NPCLIFE = 1000000
NPCEXP = 10000000
--khi hoi sinh
function Revive(NpcIndex)
		local Series = GetNpcSer(NpcIndex);--
	local nSTVL, nDoc, nBang, nHoa, nLoi = 0,0,0,0,0;
	if(Series==0) then	--KIM
	        SetNpcSkill(NpcIndex, 321, 20, 1);
                SetNpcSkill(NpcIndex, 322, 20, 2);
                SetNpcSkill(NpcIndex, 325, 20, 3);
                SetNpcSkill(NpcIndex, 318, 20, 4);
                nSTVL = 500;
	elseif(Series==1) then	--MOC
                SetNpcSkill(NpcIndex, 351, 20, 1);
                SetNpcSkill(NpcIndex, 353, 20, 2);
                SetNpcSkill(NpcIndex, 54, 20, 3);
                SetNpcSkill(NpcIndex, 341, 20, 4);
		nDoc = 500;
	elseif(Series==2) then	--THUY
		SetNpcSkill(NpcIndex, 111, 20, 1);
                SetNpcSkill(NpcIndex, 105, 20, 2);
                SetNpcSkill(NpcIndex, 337, 20, 3);
                SetNpcSkill(NpcIndex, 380, 20, 4);
		nBang = 1000; 
	elseif(Series==3) then	--HOA
                SetNpcSkill(NpcIndex, 362, 20, 1);
                SetNpcSkill(NpcIndex, 138, 20, 2);
                SetNpcSkill(NpcIndex, 125, 20, 3);
                SetNpcSkill(NpcIndex, 128, 20, 4);
		nHoa = 500;
	elseif(Series==4) then	--THO
                SetNpcSkill(NpcIndex, 372, 20, 1);
                SetNpcSkill(NpcIndex, 375, 20, 2);
                SetNpcSkill(NpcIndex, 365, 20, 3);
                SetNpcSkill(NpcIndex, 368, 20, 4);
		nLoi = 500;
	else					--KHONG CO HE, truong hop nay la add sai hay sao do
                SetNpcSkill(NpcIndex, 362, 20, 1);
                SetNpcSkill(NpcIndex, 138, 20, 2);
                SetNpcSkill(NpcIndex, 125, 20, 3);
                SetNpcSkill(NpcIndex, 128, 20, 4);
                nSTVL = 500;
	end
		SetNpcExp(NpcIndex, NPCEXP*EXP_RATE*2);--kinh nghiem
		SetNpcReplenish(NpcIndex,1);--phuc hoi sinh luc	
		SetNpcSpeed(NpcIndex, 10);--toc do di chuyen tang len
                SetNpcDmgRet(NpcIndex, 0)	--Ph�n damage %
		SetNpcDmgEx(NpcIndex,nSTVL, nDoc, nBang, nHoa, nLoi ,0);--
		SetNpcDmgEx(NpcIndex,nSTVL, nDoc, nBang, nHoa, nLoi ,1);--
		SetNpcResist(NpcIndex, 75, 75, 75, 75, 75);--khang' cac loai
end;

--Khi chet
function DeathSelf(NpcIndex)
	DelNpc(NpcIndex)
end;
