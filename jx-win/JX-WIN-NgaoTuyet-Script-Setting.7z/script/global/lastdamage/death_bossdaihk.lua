--Boss Tieu Hoang Kim
Include("\\script\\header\\exp_head.lua")

function LastDamage(NpcIndex)
end;
NPCLIFE = 10000000
NPCEXP = 99999999
--khi hoi sinh
function Revive(NpcIndex)
		local Series = GetNpcSer(NpcIndex);--
	local nSTVL, nDoc, nBang, nHoa, nLoi = 0,0,0,0,0;
	if(Series==0) then	--KIM
		SetNpcSkill(NpcIndex, 1363, 20, 1);
                SetNpcSkill(NpcIndex, 1081, 20, 2);
                SetNpcSkill(NpcIndex, 1062, 20, 3);
                SetNpcSkill(NpcIndex, 1076, 20, 4);
                nSTVL = 8000;
	elseif(Series==1) then	--MOC
                SetNpcSkill(NpcIndex, 1067, 20, 1);
                SetNpcSkill(NpcIndex, 1066, 20, 2);
                SetNpcSkill(NpcIndex, 1069, 20, 3);
                SetNpcSkill(NpcIndex, 1070, 20, 4);
		nDoc = 5000;
	elseif(Series==2) then	--THUY
		SetNpcSkill(NpcIndex, 1061, 20, 1);
                SetNpcSkill(NpcIndex, 1062, 20, 2);
                SetNpcSkill(NpcIndex, 1063, 20, 3);
                SetNpcSkill(NpcIndex, 1065, 20, 4);
		nBang = 8000; 
	elseif(Series==3) then	--HOA
                SetNpcSkill(NpcIndex, 1073, 20, 1);
                SetNpcSkill(NpcIndex, 1074, 20, 2);
                SetNpcSkill(NpcIndex, 1075, 20, 3);
                SetNpcSkill(NpcIndex, 1076, 20, 4);
		nHoa = 8000;
	elseif(Series==4) then	--THO
                SetNpcSkill(NpcIndex, 1078, 20, 1);
                SetNpcSkill(NpcIndex, 1079, 20, 2);
                SetNpcSkill(NpcIndex, 1080, 20, 3);
                SetNpcSkill(NpcIndex, 1081, 20, 4);
		nLoi = 8000;
	else					--KHONG CO HE, truong hop nay la add sai hay sao do
	        SetNpcSkill(NpcIndex, 1055, 20, 1);
                SetNpcSkill(NpcIndex, 1057, 20, 2);
                SetNpcSkill(NpcIndex, 1058, 20, 3);
                SetNpcSkill(NpcIndex, 1060, 20, 4);
                nSTVL = 10000;
	end
		SetNpcExp(NpcIndex, NPCEXP*EXP_RATE*2);--kinh nghiem
		SetNpcReplenish(NpcIndex,1);--phuc hoi sinh luc	
		SetNpcSpeed(NpcIndex, 10);--toc do di chuyen tang len
                SetNpcDmgRet(NpcIndex, 0)	--Ph�n damage %
		SetNpcDmgEx(NpcIndex,nSTVL, nDoc, nBang, nHoa, nLoi ,0);--
		SetNpcDmgEx(NpcIndex,nSTVL, nDoc, nBang, nHoa, nLoi ,1);--
		SetNpcResist(NpcIndex, 75, 75, 75, 75, 75);--khang' cac loai
end;

--Khi chet
function DeathSelf(NpcIndex)
	DelNpc(NpcIndex)
end;
